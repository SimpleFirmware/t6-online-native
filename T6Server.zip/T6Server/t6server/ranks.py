"""Ranks and MMR (Elo) maths.

The launcher shows a rank name next to every player and passes a rank number to the game
("rank1=" / "rank2=" in the start command). The original server's rank table is not public,
so this one simply uses Tekken 6's rank ladder and moves one step per 25 MMR around 500.
"""

RANK_NAMES = [
    "Beginner",
    "9th Kyu", "8th Kyu", "7th Kyu", "6th Kyu", "5th Kyu",
    "4th Kyu", "3rd Kyu", "2nd Kyu", "1st Kyu",
    "1st Dan", "2nd Dan", "3rd Dan",
    "Initiate", "Mentor", "Expert", "Master", "Grand Master",
    "Brawler", "Marauder", "Fighter", "Vanguard", "Warrior", "Vindicator",
    "Juggernaut", "Usurper", "Vanquisher", "Destroyer", "Savior", "Overlord",
    "Genbu", "Byakko", "Seiryu", "Suzaku",
    "Mighty Ruler", "Revered Ruler", "Divine Ruler", "Eternal Ruler",
    "Fujin", "Raijin", "Yaksa", "Ryujin", "Emperor", "Tekken Lord", "Tekken God",
]

START_ELO = 500
DEFAULT_RANK = 15          # what the launcher assumes before the server says otherwise
K_FACTOR = 32


def rank_for(elo: int) -> int:
    """Rank index (0..len-1) for an MMR value: 500 -> 15 "Expert", +-25 MMR per step."""
    return max(0, min(len(RANK_NAMES) - 1, DEFAULT_RANK + int((elo - START_ELO) / 25)))


def rank_name(elo: int) -> str:
    return RANK_NAMES[rank_for(elo)]


def expected_score(elo: int, opponent_elo: int) -> float:
    return 1.0 / (1.0 + 10 ** ((opponent_elo - elo) / 400.0))


def elo_changes(elo_a: int, elo_b: int, score_a: float, quit_by: str | None = None) -> tuple[int, int]:
    """MMR change for players A and B. score_a: 1 A won, 0 B won, 0.5 draw.

    quit_by="a"/"b": that player left the fight. They lose double ("double loss" in the
    launcher's message); the other gains the normal amount.
    """
    delta_a = round(K_FACTOR * (score_a - expected_score(elo_a, elo_b)))
    delta_b = round(K_FACTOR * ((1 - score_a) - expected_score(elo_b, elo_a)))
    if quit_by == "a":
        delta_a *= 2
    elif quit_by == "b":
        delta_b *= 2
    # Never below 0 MMR.
    delta_a = max(delta_a, -elo_a)
    delta_b = max(delta_b, -elo_b)
    return delta_a, delta_b
