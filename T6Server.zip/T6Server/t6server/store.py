"""Everything the server keeps on disk, in one SQLite file.

Tables
    accounts   name, password hash (scrypt), saved launcher settings, region
    ratings    MMR per account *and character* (the launcher says "The MMR is per character")
    sessions   login tokens the launcher stores and sends back with "auth"
    games      every finished fight, for the history and the leaderboard
    blocks     "never match me with this player again"

Players are identified by a *key*: "a:<account id>" for accounts, "g:<client id>" for guests
(client_id is a random UUID the launcher creates on first start).
"""

import hashlib
import hmac
import json
import secrets
import sqlite3
import time

from . import ranks

SESSION_DAYS = 90

SCHEMA = """
CREATE TABLE IF NOT EXISTS accounts (
    id        INTEGER PRIMARY KEY,
    name      TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password  TEXT NOT NULL,
    created   REAL NOT NULL,
    region    TEXT NOT NULL DEFAULT '',
    settings  TEXT NOT NULL DEFAULT '{}',
    admin     INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS ratings (
    account_id INTEGER NOT NULL,
    char       INTEGER NOT NULL,
    elo        INTEGER NOT NULL,
    games      INTEGER NOT NULL DEFAULT 0,
    wins       INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (account_id, char)
);
CREATE TABLE IF NOT EXISTS sessions (
    token      TEXT PRIMARY KEY,
    account_id INTEGER NOT NULL,
    created    REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS games (
    id        INTEGER PRIMARY KEY,
    ts        REAL NOT NULL,
    ranked    INTEGER NOT NULL,
    p1_key    TEXT NOT NULL, p1_name TEXT NOT NULL, p1_char INTEGER NOT NULL,
    p2_key    TEXT NOT NULL, p2_name TEXT NOT NULL, p2_char INTEGER NOT NULL,
    winner    INTEGER NOT NULL,          -- 0 draw, 1 / 2 side that won
    p1_delta  INTEGER NOT NULL DEFAULT 0,
    p2_delta  INTEGER NOT NULL DEFAULT 0,
    how       TEXT NOT NULL DEFAULT ''   -- '', 'forfeit', 'disconnect'
);
CREATE INDEX IF NOT EXISTS games_p1 ON games(p1_name COLLATE NOCASE);
CREATE INDEX IF NOT EXISTS games_p2 ON games(p2_name COLLATE NOCASE);
CREATE TABLE IF NOT EXISTS blocks (
    id          INTEGER PRIMARY KEY,
    owner       TEXT NOT NULL,
    target      TEXT NOT NULL,
    target_name TEXT NOT NULL,
    UNIQUE (owner, target)
);
"""


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)
    return f"scrypt${salt.hex()}${digest.hex()}"


def check_password(password: str, stored: str) -> bool:
    try:
        scheme, salt_hex, digest_hex = stored.split("$")
    except ValueError:
        return False
    if scheme != "scrypt":
        return False
    digest = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt_hex), n=2**14, r=8, p=1)
    return hmac.compare_digest(digest.hex(), digest_hex)


class Store:
    def __init__(self, path: str):
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        self.db.executescript(SCHEMA)
        self.db.commit()

    def close(self):
        self.db.close()

    # ---- accounts -------------------------------------------------------------------------

    def account_by_name(self, name: str):
        return self.db.execute("SELECT * FROM accounts WHERE name = ?", (name,)).fetchone()

    def account(self, account_id: int):
        return self.db.execute("SELECT * FROM accounts WHERE id = ?", (account_id,)).fetchone()

    def register(self, name: str, password: str) -> int | None:
        """New account id, or None if the name is taken."""
        try:
            cur = self.db.execute(
                "INSERT INTO accounts (name, password, created) VALUES (?, ?, ?)",
                (name, hash_password(password), time.time()))
        except sqlite3.IntegrityError:
            return None
        self.db.commit()
        return cur.lastrowid

    def login(self, name: str, password: str):
        row = self.account_by_name(name)
        if row is not None and check_password(password, row["password"]):
            return row
        return None

    def set_region(self, account_id: int, region: str):
        self.db.execute("UPDATE accounts SET region = ? WHERE id = ?", (region, account_id))
        self.db.commit()

    def save_settings(self, account_id: int, settings: dict):
        self.db.execute("UPDATE accounts SET settings = ? WHERE id = ?",
                        (json.dumps(settings), account_id))
        self.db.commit()

    def settings(self, account_id: int) -> dict:
        row = self.account(account_id)
        try:
            return json.loads(row["settings"]) if row else {}
        except ValueError:
            return {}

    # ---- sessions -------------------------------------------------------------------------

    def create_session(self, account_id: int) -> str:
        token = secrets.token_urlsafe(32)
        self.db.execute("INSERT INTO sessions VALUES (?, ?, ?)", (token, account_id, time.time()))
        self.db.commit()
        return token

    def session_account(self, token: str):
        row = self.db.execute("SELECT * FROM sessions WHERE token = ?", (token,)).fetchone()
        if row is None:
            return None
        if time.time() - row["created"] > SESSION_DAYS * 86400:
            self.delete_session(token)
            return None
        return self.account(row["account_id"])

    def delete_session(self, token: str):
        self.db.execute("DELETE FROM sessions WHERE token = ?", (token,))
        self.db.commit()

    # ---- ratings --------------------------------------------------------------------------

    def rating(self, account_id: int, char: int) -> dict:
        row = self.db.execute("SELECT elo, games, wins FROM ratings WHERE account_id = ? AND char = ?",
                              (account_id, char)).fetchone()
        if row is None:
            return {"elo": ranks.START_ELO, "games": 0, "wins": 0}
        return dict(row)

    def ratings(self, account_id: int) -> dict:
        rows = self.db.execute("SELECT char, elo, games, wins FROM ratings WHERE account_id = ?",
                               (account_id,))
        return {str(r["char"]): {"elo": r["elo"], "games": r["games"], "wins": r["wins"]} for r in rows}

    def totals(self, account_id: int) -> tuple[int, int]:
        row = self.db.execute("SELECT COALESCE(SUM(games),0) g, COALESCE(SUM(wins),0) w FROM ratings "
                              "WHERE account_id = ?", (account_id,)).fetchone()
        return row["g"], row["w"]

    def apply_rating(self, account_id: int, char: int, delta: int, won: bool):
        r = self.rating(account_id, char)
        self.db.execute(
            "INSERT INTO ratings (account_id, char, elo, games, wins) VALUES (?, ?, ?, ?, ?) "
            "ON CONFLICT (account_id, char) DO UPDATE SET elo = excluded.elo, games = excluded.games, "
            "wins = excluded.wins",
            (account_id, char, max(0, r["elo"] + delta), r["games"] + 1, r["wins"] + (1 if won else 0)))
        self.db.commit()

    # ---- games, history, leaderboard ------------------------------------------------------

    def record_game(self, *, ranked, p1, p2, winner, p1_delta=0, p2_delta=0, how=""):
        """p1/p2: (key, name, char)."""
        self.db.execute(
            "INSERT INTO games (ts, ranked, p1_key, p1_name, p1_char, p2_key, p2_name, p2_char, "
            "winner, p1_delta, p2_delta, how) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (time.time(), int(ranked), *p1, *p2, winner, p1_delta, p2_delta, how))
        self.db.commit()

    def history(self, name: str, limit: int = 30) -> list[dict]:
        rows = self.db.execute(
            "SELECT * FROM games WHERE p1_name = ? COLLATE NOCASE OR p2_name = ? COLLATE NOCASE "
            "ORDER BY ts DESC LIMIT ?", (name, name, limit))
        out = []
        for r in rows:
            mine = 1 if r["p1_name"].lower() == name.lower() else 2
            other = 2 if mine == 1 else 1
            out.append({
                "when": int(r["ts"]),
                "opponent": r[f"p{other}_name"],
                "char": r[f"p{mine}_char"],
                "opp_char": r[f"p{other}_char"],
                "result": "draw" if r["winner"] == 0 else ("win" if r["winner"] == mine else "loss"),
                "ranked": bool(r["ranked"]),
                "elo_delta": r[f"p{mine}_delta"],
                "how": r["how"],
            })
        return out

    def leaderboard(self, region: str = "", limit: int = 100) -> list[dict]:
        """Accounts by the MMR of their best character (only characters with ranked games)."""
        sql = ("SELECT a.id, a.name, a.region, r.char, MAX(r.elo) AS elo, r.games, r.wins "
               "FROM ratings r JOIN accounts a ON a.id = r.account_id WHERE r.games > 0 ")
        args: list = []
        if region:
            sql += "AND a.region = ? "
            args.append(region)
        sql += "GROUP BY a.id ORDER BY elo DESC, a.name LIMIT ?"
        args.append(limit)
        out = []
        for place, r in enumerate(self.db.execute(sql, args), start=1):
            out.append({"place": place, "id": r["id"], "name": r["name"], "region": r["region"],
                        "char": r["char"], "elo": r["elo"], "games": r["games"], "wins": r["wins"],
                        "rank": ranks.rank_for(r["elo"]), "rank_name": ranks.rank_name(r["elo"])})
        return out

    # ---- blocks ---------------------------------------------------------------------------

    def add_block(self, owner: str, target: str, target_name: str):
        self.db.execute("INSERT OR IGNORE INTO blocks (owner, target, target_name) VALUES (?, ?, ?)",
                        (owner, target, target_name))
        self.db.commit()

    def remove_block(self, owner: str, block_id: int):
        self.db.execute("DELETE FROM blocks WHERE owner = ? AND id = ?", (owner, block_id))
        self.db.commit()

    def blocks(self, owner: str) -> list[dict]:
        rows = self.db.execute("SELECT id, target_name FROM blocks WHERE owner = ? ORDER BY id", (owner,))
        return [{"id": r["id"], "name": r["target_name"]} for r in rows]

    def blocked_either_way(self, a: str, b: str) -> bool:
        row = self.db.execute(
            "SELECT 1 FROM blocks WHERE (owner = ? AND target = ?) OR (owner = ? AND target = ?)",
            (a, b, b, a)).fetchone()
        return row is not None
