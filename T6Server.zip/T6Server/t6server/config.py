"""Server settings (all can be set on the command line, see __main__.py)."""

from dataclasses import dataclass, field


@dataclass
class Config:
    host: str = "0.0.0.0"
    port: int = 7700                 # TCP: JSON lines, TLS unless plain=True
    udp_port: int = 7701             # UDP rendezvous ("punch" -> "seen"); sent to clients in "start"
    plain: bool = False              # plain TCP instead of TLS (launcher: T6_LOBBY_SERVER=tcp://...)
    cert: str = "data/server.pem"    # created on first start if missing; give it to clients
    key: str = "data/server.key"     #   as T6_LOBBY_CERT so their launcher pins it
    db: str = "data/t6server.db"
    log_dir: str = "data/logs"       # logs launchers upload with {"t":"log"}

    # Who may play
    versions: list[str] = field(default_factory=list)  # accepted launcher versions, empty = any
    guests_allowed: bool = True
    allow_insecure_login: bool = False   # logins over plain TCP (always allowed from 127.0.0.1)
    allow_same_network: bool = False     # ranked between two players behind one IP / on one PC

    # Match flow
    confirm_seconds: int = 15        # time to press Accept after a queue match was found
    handshake_seconds: int = 20      # UDP punch + ping test must finish within this
    ready_seconds: int = 15          # quick-match lobby: both launchers must send "ready"
    next_seconds: int = 20           # after a game: time to press "Next game"
    result_wait_seconds: int = 15    # after the first "result", wait this long for the second
    ranked_target: int = 2           # ranked set: first to N wins
    player_target: int = 2           # player-match set
    lobby_target: int = 3            # set in a self-made lobby
    slow_limit: int = 50             # % of a fight under 60 FPS that ends the set ("slow_end")
    lag_warn_frames: float = 3.0     # warn when a side was this many frames more behind than expected

    notice: str = ""                 # banner text shown in every launcher
    login_attempts_per_minute: int = 10
