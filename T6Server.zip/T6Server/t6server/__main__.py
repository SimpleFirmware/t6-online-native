"""Run the server:  python -m t6server [options]

    python -m t6server                      TLS on 7700, UDP 7701, data in ./data
    python -m t6server --plain              plain TCP (for local tests)
    python -m t6server --allow-same-network ranked between two launchers on one PC

Launcher side (the rebuild, or any launcher that reads these variables):
    T6_LOBBY_SERVER=tls://<this host>:7700
    T6_LOBBY_CERT=<path to data/server.pem>
"""

import argparse
import asyncio
import logging
import os
import signal

from .certs import ensure_certificate
from .config import Config
from .server import Server


def parse_args() -> tuple[Config, str]:
    d = Config()
    p = argparse.ArgumentParser(prog="python -m t6server", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--host", default=d.host)
    p.add_argument("--port", type=int, default=d.port, help="TCP port (default %(default)s)")
    p.add_argument("--udp-port", type=int, default=d.udp_port, help="UDP rendezvous port (default %(default)s)")
    p.add_argument("--plain", action="store_true", help="plain TCP instead of TLS")
    p.add_argument("--data", default="data", help="folder for the database, certificate and logs")
    p.add_argument("--cert", help="certificate PEM (default <data>/server.pem, created if missing)")
    p.add_argument("--key", help="private key PEM (default <data>/server.key)")
    p.add_argument("--versions", default="", help="comma-separated launcher versions to accept (default: any)")
    p.add_argument("--no-guests", action="store_true", help="require an account")
    p.add_argument("--allow-insecure-login", action="store_true", help="allow logins over plain TCP from anywhere")
    p.add_argument("--allow-same-network", action="store_true", help="allow ranked between players on one IP/PC")
    p.add_argument("--notice", default="", help="banner text for every launcher")
    p.add_argument("--confirm-seconds", type=int, default=d.confirm_seconds)
    p.add_argument("--next-seconds", type=int, default=d.next_seconds)
    p.add_argument("--ranked-target", type=int, default=d.ranked_target, help="ranked set: first to N")
    p.add_argument("--player-target", type=int, default=d.player_target)
    p.add_argument("--lobby-target", type=int, default=d.lobby_target)
    p.add_argument("-v", "--verbose", action="store_true", help="log every message")
    a = p.parse_args()
    cfg = Config(
        host=a.host, port=a.port, udp_port=a.udp_port, plain=a.plain,
        cert=a.cert or os.path.join(a.data, "server.pem"),
        key=a.key or os.path.join(a.data, "server.key"),
        db=os.path.join(a.data, "t6server.db"), log_dir=os.path.join(a.data, "logs"),
        versions=[v.strip() for v in a.versions.split(",") if v.strip()],
        guests_allowed=not a.no_guests, allow_insecure_login=a.allow_insecure_login,
        allow_same_network=a.allow_same_network, notice=a.notice,
        confirm_seconds=a.confirm_seconds, next_seconds=a.next_seconds,
        ranked_target=a.ranked_target, player_target=a.player_target, lobby_target=a.lobby_target)
    return cfg, ("DEBUG" if a.verbose else "INFO")


async def run(cfg: Config):
    server = Server(cfg)
    await server.start()
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop.set)
        except (NotImplementedError, AttributeError):
            pass    # Windows: Ctrl+C raises KeyboardInterrupt instead
    try:
        await stop.wait()
    finally:
        await server.stop()


def main():
    cfg, level = parse_args()
    logging.basicConfig(level=level, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    log = logging.getLogger("t6server")
    if not cfg.plain:
        ensure_certificate(cfg.cert, cfg.key, log)
        log.info("launchers must pin this certificate: T6_LOBBY_CERT=%s", os.path.abspath(cfg.cert))
    try:
        asyncio.run(run(cfg))
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
