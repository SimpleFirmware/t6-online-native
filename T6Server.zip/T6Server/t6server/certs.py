"""The TLS certificate.

The launcher does not trust certificate authorities: it compares the server's certificate
with one file it was given (built in for the original server; T6_LOBBY_CERT=<file> for yours).
So a self-signed certificate is exactly right. It is created once with the openssl command
line tool (Git for Windows ships one, as do Linux and macOS) and must then stay the same,
because every launcher pins this exact file.
"""

import os
import shutil
import subprocess

SUBJECT = "/CN=Tekken 6 Native Online lobby (self-hosted)"


def ensure_certificate(cert_path: str, key_path: str, log) -> None:
    if os.path.exists(cert_path) and os.path.exists(key_path):
        return
    openssl = shutil.which("openssl")
    if openssl is None:
        raise SystemExit(
            f"No TLS certificate at {cert_path} and no 'openssl' command to create one.\n"
            "Install OpenSSL (or Git for Windows, which includes it), or start with --plain "
            "for an unencrypted test server.")
    os.makedirs(os.path.dirname(os.path.abspath(cert_path)), exist_ok=True)
    os.makedirs(os.path.dirname(os.path.abspath(key_path)), exist_ok=True)
    subprocess.run(
        [openssl, "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "3650",
         "-subj", SUBJECT, "-keyout", key_path, "-out", cert_path],
        check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    log.info("created a new TLS certificate: %s", cert_path)
