"""The lobby server: connections, accounts, matchmaking queue and message dispatch.

Protocol: one JSON object per line over TLS (or plain TCP for tests), field "t" = type.
The launcher speaks first ("hello"); we answer "welcome". The handlers below are named
on_<type> and are listed in the same order as the launcher's features: account, profile,
matchmaking, lobbies, match flow, lists.

Errors are sent as {"t":"error","msg":"<code>"} with the codes the launcher knows
(bad_login, name_taken, lobby_not_found, ...); it turns them into readable messages.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import secrets
import ssl
import time
from collections import defaultdict, deque

from . import ranks
from .config import Config
from .lobby import Lobby
from .rendezvous import Rendezvous
from .store import Store

log = logging.getLogger("t6server")

PROTOCOL_VERSION = 2
NAME_RE = re.compile(r"^[A-Za-z0-9 _.\-]{2,15}$")
MAX_LINE = 64 * 1024


def as_int(value, default: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


class Client:
    """One connected launcher."""

    def __init__(self, server: Server, writer: asyncio.StreamWriter, tls: bool):
        self.server = server
        self.writer = writer
        self.tls = tls
        peer = writer.get_extra_info("peername") or ("?", 0)
        self.ip = peer[0]
        self.open = True

        # from "hello"
        self.hello = False
        self.version = ""
        self.client_id = ""
        self.machine = ""
        self.build = ""
        self.wine = False

        # login
        self.logged_in = False
        self.guest = False
        self.account_id: int | None = None
        self.name = ""
        self.session = ""

        # profile
        self.char = 16
        self.costume = 0
        self.custom = ""
        self.side = 0
        self.region = ""
        self.region_lock = False
        self.strict = False

        # where they are
        self.lobby: Lobby | None = None
        self.queued_ranked: bool | None = None   # None = not searching
        self.queued_since = 0.0
        self.last_opponent: tuple[str, str] | None = None   # (key, name) for "block"

    def __repr__(self):
        return f"<{self.name or '?'}@{self.ip}>"

    @property
    def key(self) -> str:
        return f"a:{self.account_id}" if self.account_id else f"g:{self.client_id}"

    # ---- sending -------------------------------------------------------------------------

    def send(self, t: str, **fields):
        if not self.open:
            return
        fields["t"] = t
        line = json.dumps(fields, separators=(",", ":"))
        log.debug("%r << %s", self, line)
        try:
            self.writer.write(line.encode() + b"\n")
        except (ConnectionError, RuntimeError):
            self.open = False

    def error(self, code: str, **fields):
        self.send("error", msg=code, **fields)

    # ---- what others see -----------------------------------------------------------------

    def rating(self) -> dict:
        if self.account_id:
            return self.server.store.rating(self.account_id, self.char)
        return {"elo": ranks.START_ELO, "games": 0, "wins": 0}

    def public_info(self) -> dict:
        elo = self.rating()["elo"]
        return {"name": self.name, "char": self.char, "costume": self.costume, "elo": elo,
                "rank": ranks.rank_for(elo), "rank_name": ranks.rank_name(elo),
                "region": self.region, "guest": self.guest}

    def refresh_account(self, **extra):
        """(Re)send the "account" message with the current numbers."""
        r = self.rating()
        games, wins = (self.server.store.totals(self.account_id) if self.account_id else (0, 0))
        msg = {
            "guest": self.guest, "admin": False, "name": self.name,
            "elo": r["elo"], "games": games, "wins": wins, "rank": ranks.rank_for(r["elo"]),
            "chars": self.server.store.ratings(self.account_id) if self.account_id else {},
            "rank_names": ranks.RANK_NAMES, "online": self.server.online_count(),
        }
        if self.server.config.notice:
            msg["notice"] = {"text": self.server.config.notice}
        msg.update(extra)
        self.send("account", **msg)


class Server:
    def __init__(self, config: Config):
        self.config = config
        self.loop: asyncio.AbstractEventLoop | None = None
        os.makedirs(os.path.dirname(os.path.abspath(config.db)), exist_ok=True)
        self.store = Store(config.db)
        self.clients: set[Client] = set()
        self.lobbies: dict[str, Lobby] = {}
        self.queue: list[Client] = []
        self.tokens: dict[str, tuple] = {}          # UDP token -> (Game or Probe, Client)
        self.avoid: dict[frozenset, float] = {}     # pairs not to match again until <time>
        self.login_attempts: dict[str, deque] = defaultdict(deque)
        self._ids = 0
        self._last_online = -1
        self.tcp_server = None
        self.udp_transport = None

    # ---- start / stop --------------------------------------------------------------------

    async def start(self):
        self.loop = asyncio.get_running_loop()
        cfg = self.config
        ssl_ctx = None
        if not cfg.plain:
            ssl_ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ssl_ctx.minimum_version = ssl.TLSVersion.TLSv1_2
            ssl_ctx.load_cert_chain(cfg.cert, cfg.key)
        self.tcp_server = await asyncio.start_server(
            lambda r, w: self.handle_connection(r, w, ssl_ctx is not None),
            cfg.host, cfg.port, ssl=ssl_ctx, limit=MAX_LINE)
        self.udp_transport, _ = await self.loop.create_datagram_endpoint(
            lambda: Rendezvous(self.on_punch), local_addr=(cfg.host, cfg.udp_port))
        self.loop.call_later(1.0, self.tick)
        log.info("listening on %s:%d (%s), UDP rendezvous on %d", cfg.host, cfg.port,
                 "plain TCP" if cfg.plain else "TLS", cfg.udp_port)

    async def stop(self):
        if self.tcp_server:
            self.tcp_server.close()
        for c in list(self.clients):
            c.writer.close()
        if self.udp_transport:
            self.udp_transport.close()
        self.store.close()

    def new_id(self, prefix: str) -> str:
        self._ids += 1
        return f"{prefix}{self._ids}{secrets.token_hex(3)}"

    def tick(self):
        """Once a second: matchmaking and the online counter."""
        try:
            self.match_queue()
            now = time.time()
            for pair, until in list(self.avoid.items()):
                if until < now:
                    del self.avoid[pair]
            n = self.online_count()
            if n != self._last_online:
                self._last_online = n
                for c in self.clients:
                    if c.hello:
                        c.send("online", n=n)
        finally:
            self.loop.call_later(1.0, self.tick)

    def online_count(self) -> int:
        return sum(1 for c in self.clients if c.logged_in)

    # ---- connections ---------------------------------------------------------------------

    async def handle_connection(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter, tls: bool):
        client = Client(self, writer, tls)
        self.clients.add(client)
        log.info("connection from %s (%s)", client.ip, "TLS" if tls else "plain")
        try:
            while True:
                try:
                    line = await reader.readline()
                except (ValueError, asyncio.LimitOverrunError):
                    log.warning("%r sent a line that is too long", client)
                    break
                if not line:
                    break
                try:
                    msg = json.loads(line)
                except ValueError:
                    continue
                if isinstance(msg, dict):
                    self.dispatch(client, msg)
        except (ConnectionError, ssl.SSLError, OSError) as e:
            log.info("%r: %s", client, e)
        finally:
            client.open = False
            self.clients.discard(client)
            self.leave_everything(client, disconnected=True)
            log.info("%r disconnected", client)
            try:
                writer.close()
            except Exception:
                pass

    def dispatch(self, client: Client, msg: dict):
        t = msg.get("t")
        safe = dict(msg)
        if "password" in safe:
            safe["password"] = "***"
        log.debug("%r >> %s", client, json.dumps(safe))
        if not isinstance(t, str):
            return
        if not client.hello and t != "hello":
            return
        handler = getattr(self, "on_" + t, None)
        if handler is None:
            log.info("%r: unknown message type %r", client, t)
            return
        if t not in NO_LOGIN_NEEDED and not client.logged_in:
            client.error("login first")
            return
        try:
            handler(client, msg)
        except Exception:
            log.exception("handling %r from %r failed", t, client)

    # ---- hello and accounts ----------------------------------------------------------------

    def on_hello(self, c: Client, m: dict):
        if m.get("proto") != PROTOCOL_VERSION:
            c.error("protocol")
            return
        version = str(m.get("version", ""))
        if self.config.versions and version not in self.config.versions:
            c.error("protocol")
            return
        c.hello = True
        c.version = version
        c.client_id = str(m.get("client_id", ""))[:64] or secrets.token_hex(8)
        c.machine = str(m.get("machine", ""))[:64]
        c.build = str(m.get("build", ""))[:64]
        self.apply_profile(c, m)
        welcome = {"online": self.online_count(), "server": "t6server"}
        if self.config.notice:
            welcome["notice"] = {"text": self.config.notice}
        c.send("welcome", **welcome)

    def too_many_attempts(self, c: Client) -> bool:
        q = self.login_attempts[c.ip]
        now = time.time()
        while q and now - q[0] > 60:
            q.popleft()
        q.append(now)
        return len(q) > self.config.login_attempts_per_minute

    def login_allowed_here(self, c: Client) -> bool:
        return c.tls or self.config.allow_insecure_login or c.ip in ("127.0.0.1", "::1")

    def on_login(self, c: Client, m: dict):
        self._login(c, m, create=False)

    def on_register(self, c: Client, m: dict):
        self._login(c, m, create=True)

    def _login(self, c: Client, m: dict, create: bool):
        if not self.login_allowed_here(c):
            c.error("insecure")
            return
        if self.too_many_attempts(c):
            c.error("too_many_attempts")
            return
        name = str(m.get("name", "")).strip()
        password = str(m.get("password", ""))
        if create:
            if not NAME_RE.match(name) or name.lower().startswith("guest"):
                c.error("name_invalid")
                return
            if len(password) < 6:
                c.error("password_short")
                return
            account_id = self.store.register(name, password)
            if account_id is None:
                c.error("name_taken")
                return
            row = self.store.account(account_id)
            log.info("new account %s", name)
        else:
            row = self.store.login(name, password)
            if row is None:
                c.error("bad_login")
                return
        self.logged_in_as(c, row, self.store.create_session(row["id"]))

    def on_auth(self, c: Client, m: dict):
        row = self.store.session_account(str(m.get("session", "")))
        if row is None:
            c.error("session_expired")
            return
        self.logged_in_as(c, row, str(m["session"]), new_session=False)

    def logged_in_as(self, c: Client, row, session: str, new_session: bool = True):
        # One connection per account: the older one is logged out.
        for other in list(self.clients):
            if other is not c and other.account_id == row["id"] and other.logged_in:
                self.leave_everything(other)
                other.logged_in = False
                other.account_id = None
                other.error("logged_in_elsewhere")
        self.leave_everything(c)
        c.logged_in, c.guest = True, False
        c.account_id, c.name, c.session = row["id"], row["name"], session
        if c.region:
            self.store.set_region(c.account_id, c.region)
        extra = {"settings": self.store.settings(c.account_id)}
        if new_session:
            extra["session"] = session
        c.refresh_account(**extra)
        log.info("%r logged in", c)

    def on_guest(self, c: Client, m: dict):
        if not self.config.guests_allowed:
            c.error("guests_off")
            return
        name = re.sub(r"[^A-Za-z0-9 _.\-]", "", str(m.get("name", "")))[:15].strip()
        if not name:
            name = f"Guest{secrets.randbelow(9000) + 1000}"
        # Don't let guests use account names or the name of someone online.
        taken = {o.name.lower() for o in self.clients if o is not c and o.logged_in}
        base = name[:11]
        while name.lower() in taken or self.store.account_by_name(name) is not None:
            name = f"{base}{secrets.randbelow(900) + 100}"
        self.leave_everything(c)
        c.logged_in, c.guest, c.account_id, c.name = True, True, None, name
        c.refresh_account()

    def on_logout(self, c: Client, m: dict):
        self.leave_everything(c)
        if c.session:
            self.store.delete_session(c.session)
        c.logged_in, c.guest, c.account_id, c.session = False, False, None, ""
        c.send("logged_out")

    # ---- profile and settings -------------------------------------------------------------

    def apply_profile(self, c: Client, m: dict):
        char = as_int(m.get("char"), c.char)
        if 0 <= char < 43:
            c.char = char
        c.costume = max(0, min(2, as_int(m.get("costume"), c.costume)))
        custom = m.get("custom", c.custom)
        c.custom = custom if isinstance(custom, str) and len(custom) in (0, 160) else ""
        c.side = int(m.get("side", c.side)) if m.get("side") in (0, 1, 2) else c.side
        c.region = str(m.get("region", c.region))[:8]
        c.region_lock = bool(m.get("region_lock", c.region_lock))
        c.strict = bool(m.get("strict", c.strict))

    def on_profile(self, c: Client, m: dict):
        lobby = c.lobby
        if lobby and lobby.ranked and lobby.set_running() and as_int(m.get("char"), c.char) != c.char:
            c.error("char_locked_set")
            m = {k: v for k, v in m.items() if k not in ("char", "costume", "custom")}
        self.apply_profile(c, m)
        if c.account_id and c.region:
            self.store.set_region(c.account_id, c.region)
        if c.logged_in:
            c.refresh_account()     # MMR is per character: send the numbers for the new one
        if lobby and not lobby.closed and not lobby.set_running():
            lobby.broadcast_info()

    def on_settings(self, c: Client, m: dict):
        if c.account_id and isinstance(m.get("data"), dict):
            self.store.save_settings(c.account_id, m["data"])

    # ---- matchmaking queue ----------------------------------------------------------------

    def on_quick(self, c: Client, m: dict):
        ranked = bool(m.get("ranked", False))
        if ranked and c.guest:
            c.error("ranked_needs_account")
            return
        if c.lobby is not None:
            if c.lobby.set_running():
                return
            c.lobby.remove(c, disconnected=False)
        self.enqueue(c, ranked)
        self.match_queue()

    def on_quick_cancel(self, c: Client, m: dict):
        self.dequeue(c)

    def enqueue(self, c: Client, ranked: bool):
        if not c.open or not c.logged_in:
            return
        self.dequeue(c)
        c.queued_ranked = ranked
        c.queued_since = time.time()
        self.queue.append(c)
        c.send("queued", ranked=ranked, waiting=len(self.queue))

    def dequeue(self, c: Client):
        if c in self.queue:
            self.queue.remove(c)
        c.queued_ranked = None

    def avoid_pair(self, a: Client, b: Client, seconds: float = 60):
        self.avoid[frozenset((a.key, b.key))] = time.time() + seconds

    def same_network(self, a: Client, b: Client) -> bool:
        if self.config.allow_same_network:
            return False
        return a.ip == b.ip or (a.machine and a.machine == b.machine)

    def can_pair(self, a: Client, b: Client) -> bool:
        if a.queued_ranked != b.queued_ranked or a.key == b.key:
            return False
        if a.build != b.build or a.version != b.version:
            return False                    # different game builds would desync
        if frozenset((a.key, b.key)) in self.avoid:
            return False
        if (a.region_lock or b.region_lock) and a.region != b.region:
            return False
        if a.side and a.side == b.side:
            return False                    # both want the same side
        if a.queued_ranked and self.same_network(a, b):
            return False
        if self.store.blocked_either_way(a.key, b.key):
            return False
        return True

    def match_queue(self):
        """Pair the longest-waiting compatible players."""
        i = 0
        while i < len(self.queue):
            a = self.queue[i]
            partner = next((b for b in self.queue[i + 1:] if self.can_pair(a, b)), None)
            if partner is None:
                i += 1
                continue
            ranked = bool(a.queued_ranked)
            self.dequeue(a)
            self.dequeue(partner)
            lobby = Lobby(self, a, public=False, ranked=ranked, queue=True)
            self.lobbies[lobby.id] = lobby
            a.last_opponent = (partner.key, partner.name)
            partner.last_opponent = (a.key, a.name)
            log.info("queue match: %r vs %r (%s)", a, partner, "ranked" if ranked else "player")
            lobby.join(partner)

    # ---- lobbies --------------------------------------------------------------------------

    def lobby_closed(self, lobby: Lobby):
        self.lobbies.pop(lobby.id, None)

    def on_list(self, c: Client, m: dict):
        show_private = bool(m.get("private", False))
        out = [l.info() for l in self.lobbies.values()
               if not l.queue and not l.closed and (l.public or show_private)
               and not self.store.blocked_either_way(c.key, l.host.key)]
        c.send("lobbies", lobbies=out)

    def on_create(self, c: Client, m: dict):
        ranked = bool(m.get("ranked", False))
        if ranked and c.guest:
            c.error("ranked_needs_account")
            return
        self.leave_everything(c)
        lobby = Lobby(self, c, public=bool(m.get("public", True)), ranked=ranked, queue=False)
        self.lobbies[lobby.id] = lobby
        c.send("lobby", lobby=lobby.info(c))

    def on_join(self, c: Client, m: dict):
        code = str(m.get("code", "")).strip().upper()
        lobby = None
        if m.get("id"):
            lobby = self.lobbies.get(str(m["id"]))
        elif code:
            lobby = next((l for l in self.lobbies.values() if l.code == code), None)
            if lobby is None:
                c.error("wrong_code")
                return
        if (lobby is None or lobby.queue or lobby.closed or lobby.guest is not None
                or lobby.host is c or self.store.blocked_either_way(c.key, lobby.host.key)):
            c.error("lobby_not_found")
            return
        if lobby.code and code != lobby.code:
            c.error("wrong_code")
            return
        if lobby.ranked and c.guest:
            c.error("ranked_needs_account")
            return
        if lobby.ranked and self.same_network(c, lobby.host):
            c.error("same_network")
            return
        if c.build != lobby.host.build or c.version != lobby.host.version:
            c.error("version_mismatch", yours=c.version, theirs=lobby.host.version)
            return
        self.leave_everything(c)
        c.last_opponent = (lobby.host.key, lobby.host.name)
        lobby.host.last_opponent = (c.key, c.name)
        lobby.join(c)

    def on_stage(self, c: Client, m: dict):
        if c.lobby is not None:
            c.lobby.set_stage(c, as_int(m.get("stage"), -1))

    def on_leave(self, c: Client, m: dict):
        self.leave_everything(c)

    def leave_everything(self, c: Client, disconnected: bool = False):
        self.dequeue(c)
        if c.lobby is not None:
            c.lobby.remove(c, disconnected)
        c.lobby = None

    # ---- match flow -----------------------------------------------------------------------

    def current_game(self, c: Client, m: dict):
        game = c.lobby.game if c.lobby else None
        if game is None or m.get("match_id") != game.id:
            return None
        return game

    def on_ready(self, c: Client, m: dict):
        if c.lobby is not None:
            c.lobby.on_ready(c, m)

    def on_punch(self, token: str, public: tuple, local):
        """UDP "punch" with a token from a game (match) or a probe (lobby connection test)."""
        entry = self.tokens.get(token)
        if entry is not None:
            owner, client = entry
            owner.on_punch(client, public, local)

    def on_ping_report(self, c: Client, m: dict):
        game = self.current_game(c, m)
        if game:
            game.on_ping_report(c, as_int(m.get("ms"), 0), bool(m.get("ok", True)))

    def on_accept(self, c: Client, m: dict):
        game = self.current_game(c, m)
        if game:
            game.on_accept(c, bool(m.get("yes", False)))

    def on_playing(self, c: Client, m: dict):
        game = self.current_game(c, m)
        if game:
            game.on_playing(c)

    def on_result(self, c: Client, m: dict):
        game = self.current_game(c, m)
        if game:
            game.on_result(c, m)

    def on_forfeit(self, c: Client, m: dict):
        game = self.current_game(c, m)
        if game and game.phase == "go":
            game.finish(how="forfeit", winner=game.role(game.other(c)), quitter=c)

    # ---- lists ----------------------------------------------------------------------------

    def on_leaderboard(self, c: Client, m: dict):
        region = str(m.get("region", ""))
        players = self.store.leaderboard(region)
        msg = {"region": region, "players": players, "total": len(players), "top": 1,
               "updated": time.strftime("%Y-%m-%d %H:%M", time.gmtime())}
        mine = next((p for p in players if c.account_id and p["id"] == c.account_id), None)
        if mine:
            msg["you"] = {"place": mine["place"], "elo": mine["elo"]}
        for p in players:
            p.pop("id", None)
        c.send("leaderboard", **msg)

    def on_history(self, c: Client, m: dict):
        name = str(m.get("name", "")).strip() or c.name
        c.send("history", name=name, matches=self.store.history(name))

    def on_blocks(self, c: Client, m: dict):
        c.send("blocks", list=self.store.blocks(c.key))

    def on_block(self, c: Client, m: dict):
        if c.last_opponent is None:
            return
        key, name = c.last_opponent
        self.store.add_block(c.key, key, name)
        c.send("blocked", name=name)

    def on_unblock(self, c: Client, m: dict):
        self.store.remove_block(c.key, as_int(m.get("id"), 0))
        c.send("blocks", list=self.store.blocks(c.key))

    def on_choice(self, c: Client, m: dict):
        c.send("voted", poll=m.get("poll"), choice=m.get("choice"))

    def on_log(self, c: Client, m: dict):
        """A launcher uploads its log ("Send log"). Stored as data/logs/<time>_<name>.txt."""
        os.makedirs(self.config.log_dir, exist_ok=True)
        safe = re.sub(r"[^A-Za-z0-9_.-]", "_", c.name or "unknown")
        path = os.path.join(self.config.log_dir, f"{time.strftime('%Y%m%d_%H%M%S')}_{safe}.txt")
        data = m.get("data", "")
        with open(path, "w", encoding="utf-8") as f:
            f.write(data if isinstance(data, str) else json.dumps(data))
        c.send("log_saved", ok=True)


# Messages that work before logging in.
NO_LOGIN_NEEDED = {"hello", "login", "register", "auth", "guest", "logout", "profile", "settings",
                   "leaderboard", "history", "log"}
