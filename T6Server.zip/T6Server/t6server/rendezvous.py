"""UDP rendezvous: how the two launchers find each other's public address.

Before a match (and for the connection test inside a lobby) each launcher binds the game's UDP
port and sends {"t":"punch","token":...} here. The token tells us which player and which
match it belongs to; the packet's source address is that player's public address (what their
router turned the game port into). We answer {"t":"seen","addr":[port, "ip"]} so the
launcher can tell whether its router kept the port, and hand the address to the match, which
sends each player the other one's address ("peer" / "probe_peer" over TCP). The launchers
then send UDP packets straight to each other (hole punching) - the game traffic itself never
passes through this server.
"""

import asyncio
import json
import logging

log = logging.getLogger("t6server.udp")


class Rendezvous(asyncio.DatagramProtocol):
    def __init__(self, on_punch):
        # on_punch(token, (ip, port), local) -> None, local = [ip, port] or None
        self.on_punch = on_punch
        self.transport = None

    def connection_made(self, transport):
        self.transport = transport

    def datagram_received(self, data, addr):
        try:
            msg = json.loads(data)
        except ValueError:
            return
        if not isinstance(msg, dict) or msg.get("t") != "punch":
            return
        token = msg.get("token")
        if not isinstance(token, str):
            return
        ip, port = addr[0], addr[1]
        self.transport.sendto(json.dumps({"t": "seen", "addr": [port, ip]}).encode(), addr)
        local = msg.get("local")
        if not (isinstance(local, list) and len(local) == 2):
            local = None
        self.on_punch(token, (ip, port), local)
