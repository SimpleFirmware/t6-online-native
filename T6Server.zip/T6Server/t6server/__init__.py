"""Self-hosted lobby server for the Tekken 6 Native Online launcher (protocol 2)."""
__version__ = "1.0"
