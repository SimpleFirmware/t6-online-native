"""Lobbies, games and sets - the match flow as the launcher expects it.

Every match happens in a Lobby with two players. Quick matches ("RANKED MATCH" / "PLAYER
MATCH") get a lobby too, created by the matchmaker and flagged queue=True. A lobby runs a *set*
of games (first to N wins). Each game goes through these phases:

    both players "ready"
      -> "start"      to both: match id, role 1/2, a UDP token, seed, characters, ...
    handshake         launchers punch UDP (rendezvous.py), we send each one the other's
                      address ("peer"), they ping each other and send "ping_report"
      -> "confirm"    queue matches only: both must press Accept within N seconds
                      ("accept" yes/no, we tell the other side "accepted")
      -> "go"         launchers start the fight in the game
    playing           "playing" once the fight is on screen, "result" when it ended
                      (or "forfeit" when someone quits the fight)
      -> "rated"      ranked: new MMR for each player
      -> "set"        score + seconds to press "Next game" (= "ready" again)
         or "set_over" / "slow_end"   set finished, the lobby closes

Anything going wrong before "go" -> "cancel" (reason declined / timeout / left / ping).
A player leaving or disconnecting is handled in Lobby.remove().
"""

from __future__ import annotations

import logging
import secrets
from typing import TYPE_CHECKING

from . import ranks

if TYPE_CHECKING:
    from .server import Client, Server

log = logging.getLogger("t6server.lobby")

def _int(value, default: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"   # no 0/O, 1/I


class Timer:
    """Small wrapper around loop.call_later that can be restarted / cancelled."""

    def __init__(self, server: Server):
        self.loop = server.loop
        self.handle = None

    def start(self, seconds: float, callback, *args):
        self.cancel()
        self.handle = self.loop.call_later(seconds, callback, *args)

    def cancel(self):
        if self.handle is not None:
            self.handle.cancel()
            self.handle = None


# --------------------------------------------------------------------------------------------
# Connection test inside a lobby (before anyone presses Ready)

class Probe:
    """Same hole punching as before a match, but only measured and shown, not reported."""

    def __init__(self, lobby: Lobby):
        self.lobby = lobby
        self.server = lobby.server
        self.id = self.server.new_id("P")
        self.tokens: dict[Client, str] = {}
        self.public: dict[Client, tuple] = {}
        self.local: dict[Client, list] = {}
        self.sent = False
        self.timer = Timer(self.server)

    def start(self):
        for role, c in ((1, self.lobby.host), (2, self.lobby.guest)):
            token = secrets.token_hex(8)
            self.tokens[c] = token
            self.server.tokens[token] = (self, c)
            c.send("probe", id=self.id, token=token, role=role, udp_port=self.server.config.udp_port)
        self.timer.start(20, self.stop)

    def on_punch(self, client: Client, public: tuple, local):
        self.public[client] = public
        if local:
            self.local[client] = local
        if self.sent or len(self.public) < 2:
            return
        self.sent = True
        a, b = self.lobby.host, self.lobby.guest
        same_nat = self.public[a][0] == self.public[b][0]
        for me, other in ((a, b), (b, a)):
            me.send("probe_peer", id=self.id, same_nat=same_nat,
                    public=list(self.public[other]),
                    local=self.local.get(other) or [self.public[other][0], self.public[other][1]])

    def stop(self):
        self.timer.cancel()
        for token in self.tokens.values():
            self.server.tokens.pop(token, None)
        self.tokens.clear()


# --------------------------------------------------------------------------------------------
# One game

class Game:
    def __init__(self, lobby: Lobby, state_warning: bool):
        self.lobby = lobby
        self.server = lobby.server
        self.id = self.server.new_id("M")
        self.seed = secrets.randbelow(2**31)
        self.p = {1: lobby.p1, 2: lobby.p2}        # role -> client
        self.chars = {role: (c.char, c.costume) for role, c in self.p.items()}
        self.state_warning = state_warning
        self.phase = "handshake"     # handshake -> confirm -> go -> done
        self.tokens: dict[Client, str] = {}
        self.public: dict[Client, tuple] = {}
        self.local: dict[Client, list] = {}
        self.reports: dict[Client, tuple[int, bool]] = {}
        self.accepted: set[Client] = set()
        self.playing: set[Client] = set()
        self.results: dict[Client, dict] = {}
        self.peer_sent = False
        self.ping = 0
        self.timer = Timer(self.server)

    def role(self, c: Client) -> int:
        return 1 if self.p[1] is c else 2

    def other(self, c: Client) -> Client:
        return self.p[2] if self.p[1] is c else self.p[1]

    def clients(self):
        return (self.p[1], self.p[2])

    def player_info(self, c: Client) -> dict:
        info = c.public_info()
        info["custom"] = c.custom
        return info

    # ---- start and handshake -------------------------------------------------------------

    def start(self):
        lobby = self.lobby
        for role, c in self.p.items():
            ready = lobby.ready.get(c, {})
            self.local[c] = [ready.get("local_ip") or "", _int(ready.get("local_port"), 0)]
            token = secrets.token_hex(8)
            self.tokens[c] = token
            self.server.tokens[token] = (self, c)
        common = {
            "match_id": self.id, "udp_port": self.server.config.udp_port, "seed": self.seed,
            "queue": lobby.queue, "ranked": lobby.ranked,
            "p1": self.player_info(self.p[1]), "p2": self.player_info(self.p[2]),
            "game": lobby.games_played + 1, "wins": lobby.wins[:], "target": lobby.target,
        }
        if lobby.stage >= 0:
            common["stage"] = lobby.stage
        if self.state_warning:
            common["state_warning"] = True
        for role, c in self.p.items():
            c.send("start", role=role, token=self.tokens[c], **common)
        log.info("game %s started in lobby %s: %s vs %s", self.id, lobby.id,
                 self.p[1].name, self.p[2].name)
        self.timer.start(self.server.config.handshake_seconds, self.on_handshake_timeout)

    def on_punch(self, client: Client, public: tuple, local):
        if self.phase != "handshake":
            return
        self.public[client] = public
        if self.peer_sent or len(self.public) < 2:
            return
        self.peer_sent = True
        a, b = self.clients()
        same_nat = self.public[a][0] == self.public[b][0]
        for me, other in ((a, b), (b, a)):
            local = self.local[other] if self.local[other][0] else list(self.public[other])
            me.send("peer", match_id=self.id, same_nat=same_nat,
                    public=list(self.public[other]), local=local)

    def on_ping_report(self, client: Client, ms: int, ok: bool):
        if self.phase != "handshake" or client in self.reports:
            return
        self.reports[client] = (max(0, int(ms)), bool(ok))
        if len(self.reports) < 2:
            return
        self.ping = max(r[0] for r in self.reports.values())
        if not all(r[1] for r in self.reports.values()):
            self.cancel("ping", culprit=None)
        elif self.lobby.queue and self.lobby.games_played == 0:
            self.phase = "confirm"
            seconds = self.server.config.confirm_seconds
            for c in self.clients():
                c.send("confirm", match_id=self.id, ping=self.ping, seconds=seconds)
            self.timer.start(seconds + 1, self.on_confirm_timeout)
        else:
            self.go()

    def on_handshake_timeout(self):
        if self.phase != "handshake":
            return
        # The side that never reported could not reach the other one.
        missing = [c for c in self.clients() if c not in self.reports]
        self.cancel("left", culprit=missing[0] if len(missing) == 1 else None)

    # ---- confirm -------------------------------------------------------------------------

    def on_accept(self, client: Client, yes: bool):
        if self.phase != "confirm" or client in self.accepted:
            return
        if not yes:
            self.cancel("declined", culprit=client)
            return
        self.accepted.add(client)
        self.other(client).send("accepted", match_id=self.id)
        if len(self.accepted) == 2:
            self.go()

    def on_confirm_timeout(self):
        if self.phase != "confirm":
            return
        late = [c for c in self.clients() if c not in self.accepted]
        self.cancel("timeout", culprit=late[0] if len(late) == 1 else None, also_out=late)

    def go(self):
        self.phase = "go"
        self.timer.cancel()
        self.release_tokens()
        for c in self.clients():
            c.send("go", match_id=self.id, ping=self.ping)

    def cancel(self, reason: str, culprit: Client | None, also_out=()):
        """The game did not start. culprit = the player it is blamed on (gets you=true)."""
        self.phase = "done"
        self.timer.cancel()
        self.release_tokens()
        for c in self.clients():
            c.send("cancel", match_id=self.id, reason=reason, you=c is culprit, ping=self.ping)
        log.info("game %s cancelled: %s", self.id, reason)
        self.lobby.on_game_cancelled(self, reason, culprit, also_out)

    def release_tokens(self):
        for token in self.tokens.values():
            self.server.tokens.pop(token, None)

    # ---- playing and results -------------------------------------------------------------

    def on_playing(self, client: Client):
        if self.phase == "go":
            self.playing.add(client)

    def on_result(self, client: Client, msg: dict):
        if self.phase != "go" or client in self.results:
            return
        self.results[client] = msg
        if len(self.results) == 2:
            self.finish()
        else:
            self.timer.start(self.server.config.result_wait_seconds, self.finish)

    def finish(self, how: str = "", winner: int | None = None, quitter: Client | None = None):
        """End the game: decide the winner, record it, rate it and let the lobby continue."""
        if self.phase != "go":
            return
        self.phase = "done"
        self.timer.cancel()
        if winner is None:
            claims = {_int(m.get("winner"), -1) for m in self.results.values()}
            claims.discard(-1)
            if len(claims) != 1:
                log.warning("game %s: results disagree or are missing (%s) - not counted",
                            self.id, claims)
                self.lobby.on_game_finished(self, None, quitter, how)
                return
            winner = claims.pop()
        self.lobby.on_game_finished(self, winner, quitter, how)

    def slow_percent(self) -> int:
        return max([_int(m.get("slow"), -1) for m in self.results.values()] + [-1])


# --------------------------------------------------------------------------------------------
# Lobby / set

class Lobby:
    def __init__(self, server: Server, host: Client, *, public: bool, ranked: bool, queue: bool):
        self.server = server
        self.id = server.new_id("L")
        self.host = host
        self.guest: Client | None = None
        self.public = public
        self.ranked = ranked
        self.queue = queue
        self.code = "" if public or queue else "".join(secrets.choice(CODE_ALPHABET) for _ in range(5))
        self.stage = -1
        self.ready: dict[Client, dict] = {}
        self.game: Game | None = None
        self.probe: Probe | None = None
        self.p1: Client | None = None       # sides are fixed for the whole set
        self.p2: Client | None = None
        self.wins = [0, 0]
        self.games_played = 0
        cfg = server.config
        self.target = cfg.ranked_target if ranked else (cfg.player_target if queue else cfg.lobby_target)
        self.timer = Timer(server)          # ready timeout (queue) / next-game timeout
        self.closed = False
        host.lobby = self

    # ---- info ----------------------------------------------------------------------------

    def members(self):
        return [c for c in (self.host, self.guest) if c is not None]

    def other(self, c: Client) -> Client | None:
        return self.guest if c is self.host else self.host

    def info(self, viewer: Client | None = None) -> dict:
        d = {"id": self.id, "host": self.host.public_info(),
             "guest": self.guest.public_info() if self.guest else {},
             "ranked": self.ranked, "public": self.public, "private": not self.public and not self.queue,
             "queue": self.queue, "stage": self.stage, "wins": self.wins[:], "target": self.target,
             "games": self.games_played, "full": self.guest is not None}
        if self.code and viewer in self.members():
            d["code"] = self.code
        return d

    def broadcast_info(self, **extra):
        for c in self.members():
            c.send("lobby", lobby=self.info(c), **extra)

    def set_running(self) -> bool:
        return self.games_played > 0 or (self.game is not None and self.game.phase != "done")

    # ---- joining -------------------------------------------------------------------------

    def join(self, guest: Client):
        self.guest = guest
        guest.lobby = self
        self.ready.clear()
        if self.queue:
            # Matchmaker lobby: the launchers answer with "ready" right away.
            self.broadcast_info(quick=True)
            self.timer.start(self.server.config.ready_seconds, self.on_ready_timeout)
        else:
            self.broadcast_info()
            self.probe = Probe(self)
            self.probe.start()

    def set_stage(self, client: Client, stage: int):
        if client is self.host and not self.set_running():
            self.stage = stage if stage >= 0 else -1
            self.broadcast_info()

    # ---- ready -> start ------------------------------------------------------------------

    def on_ready(self, client: Client, msg: dict):
        if self.closed or self.guest is None:
            return
        if self.game is not None and self.game.phase != "done":
            return
        self.ready[client] = msg
        if len(self.ready) == 2:
            self.start_game()

    def start_game(self):
        self.timer.cancel()
        if self.probe:
            self.probe.stop()
            self.probe = None
        if self.p1 is None:
            # Side wishes (0 any, 1 left, 2 right): the host is player 1 unless that clashes.
            if self.host.side == 2 or self.guest.side == 1:
                self.p1, self.p2 = self.guest, self.host
            else:
                self.p1, self.p2 = self.host, self.guest

        # Parked games report a hash of their memory; different hashes mean different game
        # files or settings, which would desync. Only checked before the first game.
        warning = False
        if self.games_played == 0:
            states = [str(self.ready[c].get("state") or "") for c in (self.p1, self.p2)]
            if states[0] and states[1] and states[0] != states[1]:
                if self.ranked:
                    for c in self.members():
                        c.send("error", msg="state_mismatch")
                    self.ready.clear()
                    if self.queue:
                        self.close(notify="left", reason="state_mismatch")
                    return
                warning = True
        self.game = Game(self, warning)
        self.game.start()

    def on_ready_timeout(self):
        # Quick-match lobby where a launcher never answered: put the other one back in the queue.
        if self.closed or self.game is not None:
            return
        responsive = [c for c in self.members() if c in self.ready]
        self.close(notify="left", reason="requeue", requeue=responsive)

    # ---- outcomes ------------------------------------------------------------------------

    def on_game_cancelled(self, game: Game, reason: str, culprit: Client | None, also_out=()):
        self.ready.clear()
        out = {culprit, *also_out} - {None}
        if self.games_played > 0:
            # A later game of a set did not start: end the set.
            self.end_set("cancelled")
        elif self.queue:
            # Back to searching - except whoever declined or didn't answer. Don't pair the
            # same two players again right away.
            a, b = self.members()
            self.server.avoid_pair(a, b)
            self.close(notify="left", reason="requeue", requeue=[c for c in self.members() if c not in out])
        else:
            self.p1 = self.p2 = None
            self.broadcast_info()

    def on_game_finished(self, game: Game, winner: int | None, quitter: Client | None, how: str):
        """winner: 0 draw, 1/2 side, None = not counted."""
        store = self.server.store
        p1, p2 = game.p[1], game.p[2]
        deltas = {p1: 0, p2: 0}
        if winner is not None:
            if winner in (1, 2):
                self.wins[winner - 1] += 1
            if self.ranked and p1.account_id and p2.account_id:
                deltas = self.rate(game, winner, quitter)
            store.record_game(
                ranked=self.ranked,
                p1=(p1.key, p1.name, game.chars[1][0]), p2=(p2.key, p2.name, game.chars[2][0]),
                winner=winner, p1_delta=deltas[p1], p2_delta=deltas[p2], how=how)
        self.games_played += 1
        self.ready.clear()
        log.info("game %s finished: winner %s (%s), set %s-%s", game.id, winner, how or "normal",
                 *self.wins)

        if self.ranked:
            for c in (p1, p2):
                if c.account_id:
                    r = store.rating(c.account_id, game.chars[game.role(c)][0])
                    mine, theirs = self.wins[game.role(c) - 1], self.wins[2 - game.role(c)]
                    extra = {}
                    if quitter is not None:
                        extra["quit"] = 1 if c is quitter else 2
                    c.send("rated", elo=r["elo"], elo_delta=deltas[c], rank=ranks.rank_for(r["elo"]),
                           rank_delta=ranks.rank_for(r["elo"]) - ranks.rank_for(r["elo"] - deltas[c]),
                           rank_name=ranks.rank_name(r["elo"]), set=[mine, theirs], **extra)
                    c.refresh_account()

        if quitter is not None:
            other = game.other(quitter)
            if not self.ranked:
                other.send("left", reason="host_left")
            self.end_set("forfeit")
        elif game.slow_percent() >= self.server.config.slow_limit:
            for c in self.members():
                c.send("slow_end", pct=game.slow_percent())
            self.close()
        elif max(self.wins) >= self.target:
            self.end_set("done")
        else:
            seconds = self.server.config.next_seconds
            for c in self.members():
                c.send("set", wins=self.wins[:], target=self.target, next_seconds=seconds,
                       loser=(2 if winner == 1 else 1) if winner in (1, 2) else 0)
            self.timer.start(seconds + 2, self.on_next_timeout)

    def rate(self, game: Game, winner: int, quitter: Client | None) -> dict:
        store = self.server.store
        p1, p2 = game.p[1], game.p[2]
        c1, c2 = game.chars[1][0], game.chars[2][0]
        e1 = store.rating(p1.account_id, c1)["elo"]
        e2 = store.rating(p2.account_id, c2)["elo"]
        score = {1: 1.0, 2: 0.0, 0: 0.5}[winner]
        quit_by = None if quitter is None else ("a" if quitter is p1 else "b")
        d1, d2 = ranks.elo_changes(e1, e2, score, quit_by)
        store.apply_rating(p1.account_id, c1, d1, winner == 1)
        store.apply_rating(p2.account_id, c2, d2, winner == 2)
        return {p1: d1, p2: d2}

    def on_next_timeout(self):
        if not self.closed and (self.game is None or self.game.phase == "done"):
            self.end_set("next_timeout")

    def end_set(self, why: str, leaver: Client | None = None):
        for c in self.members():
            extra = {}
            if leaver is not None:
                extra["left"] = 1 if c is leaver else 2
            c.send("set_over", why=why, wins=self.wins[:], **extra)
        self.close()

    # ---- leaving -------------------------------------------------------------------------

    def remove(self, client: Client, disconnected: bool):
        """A member sent "leave", logged out or disconnected."""
        game = self.game
        other = self.other(client)
        if game is not None and game.phase in ("handshake", "confirm"):
            game.cancel("left", culprit=client)          # may close/requeue the lobby
        elif game is not None and game.phase == "go":
            if game.results:
                game.finish()                            # one result is in: use it
            else:
                # Left the running fight: counts as a forfeit.
                game.finish(how="disconnect" if disconnected else "forfeit",
                            winner=game.role(other), quitter=client)
        if self.closed:
            client.lobby = None
            return

        if self.set_running() or self.games_played > 0:
            if self.ranked and client.account_id and other is not None:
                # Tell both who left the set (the launcher shows "You left the set: loss").
                for c in self.members():
                    if c.account_id:
                        r = self.server.store.rating(c.account_id, c.char)
                        c.send("rated", elo=r["elo"], elo_delta=0, rank=ranks.rank_for(r["elo"]),
                               left=1 if c is client else 2)
            self.end_set("left", leaver=client)
        elif client is self.host:
            if self.queue:
                self.close(notify="left", reason="requeue",
                           requeue=[c for c in self.members() if c is not client])
            else:
                if other is not None:
                    other.send("left", reason="host_left")
                self.close()
        else:
            # The guest left a lobby that hasn't played yet.
            if self.queue:
                self.close(notify="left", reason="requeue", requeue=[self.host])
            else:
                if self.probe:
                    self.probe.stop()
                    self.probe = None
                self.guest = None
                self.ready.clear()
                self.p1 = self.p2 = None
                self.broadcast_info()
        client.lobby = None

    def close(self, notify: str | None = None, reason: str = "", requeue=()):
        if self.closed:
            return
        self.closed = True
        self.timer.cancel()
        if self.probe:
            self.probe.stop()
        if self.game:
            self.game.timer.cancel()
            self.game.release_tokens()
        for c in self.members():
            if c.lobby is self:
                c.lobby = None
            if notify:
                c.send(notify, reason=reason)
        self.server.lobby_closed(self)
        for c in requeue:
            self.server.enqueue(c, self.ranked)
