# T6Server: a self-hosted lobby server for the T6Launcher rebuild

This is a lobby server that speaks the same protocol (version 2) as the Tekken 6 Native Online
launcher and the T6Launcher rebuild. It covers accounts, ranked and player matchmaking,
lobbies, UDP hole punching, the Accept step, sets, MMR, the leaderboard, match history and
blocking.

It needs only Python 3.10 or newer and its standard library: no packages to install. The
`openssl` command is used once, to create the TLS certificate.

I wrote this server from the launcher's side of the conversation. It is **not** the original
author's server. It does what the launcher expects, but its rules are my own: MMR maths,
rank ladder, set lengths and timeouts. See "Differences" below.

## Running it

```sh
python -m t6server                       # TLS on 7700, UDP 7701, data in ./data
python -m t6server --plain               # plain TCP, easiest for local tests
python -m t6server --allow-same-network  # allow ranked between two launchers on one PC / IP
python -m t6server --help                # all options
```

On the first start it creates `data/server.pem` (certificate), `data/server.key` (key) and
`data/t6server.db` (accounts, ratings, history).

Open **TCP 7700 and UDP 7701** in your firewall or router if players connect from outside
your network. Game traffic goes directly between the players; it does not pass through
this server.

### Pointing the launcher at it

The launcher pins the server certificate, so every player needs a copy of `data/server.pem`:

```bat
set T6_LOBBY_SERVER=tls://your.server.address:7700
set T6_LOBBY_CERT=C:\path\to\server.pem
T6Launcher.exe
```

For a `--plain` server use `T6_LOBBY_SERVER=tcp://127.0.0.1:7700`, with no certificate.
Logins over plain TCP are accepted only from the same PC, unless you add
`--allow-insecure-login`.

**Keep `server.key` private and don't regenerate the certificate.** Every launcher pins
that exact file, so a new certificate means sending everyone the new `server.pem`.

## How a match flows

```
launcher A / B                       server
quick {ranked}            ─────────▶ queued
                          ◀───────── lobby {quick:true}           (paired by the matchmaker)
ready {local_ip, state}   ─────────▶
                          ◀───────── start {match_id, role, token, seed, p1, p2, udp_port}
UDP punch {token}         ─────────▶ (UDP 7701)  ◀── seen {addr:[port, ip]}
                          ◀───────── peer {public, local, same_nat}
UDP hi / pp / pq   ◀────── directly between A and B ──────▶
ping_report {ms, ok}      ─────────▶
                          ◀───────── confirm {ping, seconds}     (queue matches only)
accept {yes}              ─────────▶ accepted (to the other one)
                          ◀───────── go
playing, result {winner}  ─────────▶
                          ◀───────── rated (ranked) · set {wins, next_seconds} · or set_over
ready (= "Next game")     ─────────▶ start … (no Accept step for later games)
```

Things that go wrong before `go` produce a `cancel`:
* `declined` or `timeout`: the other player goes back into the queue.
* `ping`: both go back, but they aren't paired with each other again for a minute.
* `left`: the UDP handshake didn't finish, or someone left.

If a player leaves or disconnects mid-fight, it counts as a forfeit. In ranked that is a
double MMR loss for the leaver.

## Code tour

| File | What it does |
|---|---|
| `t6server/server.py` | Connections, login, matchmaking queue, one `on_<message>` handler per message type |
| `t6server/lobby.py` | `Lobby` (a set of games), `Game` (one fight: start → handshake → confirm → go → result) and `Probe` (the in-lobby connection test) |
| `t6server/rendezvous.py` | UDP `punch` → `seen`; passes public addresses to the game or probe |
| `t6server/store.py` | SQLite tables: accounts (scrypt passwords), sessions, per-character MMR, games, blocks |
| `t6server/ranks.py` | Rank names and Elo maths |
| `t6server/config.py` | Every setting with its default |

Run with `-v` to log every message in both directions; passwords are masked.

## Tests

```sh
python -m unittest discover -s tests -t . -v
```

These are 38 scripted scenarios. Each one uses fake launchers that do the real UDP hole
punching. They cover:
* TLS, accounts and sessions;
* the full set flow, declines, timeouts, a ping that is too high and blocked UDP;
* lobbies with codes and the probe;
* forfeits, disconnects, state-hash checks, blocking, the leaderboard and per-character MMR.

### End-to-end with two real launchers

```sh
tests/run_two_launchers.sh /path/to/T6Launcher ranked        # or: player
tests/run_two_launchers.sh /path/to/T6Launcher ranked quit   # kill one launcher mid-fight
```

The script starts the server over TLS and two real T6Launcher instances (Linux build,
offscreen). The real game is replaced by `tests/fake_game.py`, which reads `cmd.txt`, writes
`status.txt` and exchanges real UDP packets with the other fake game at the address the
launcher was given. So a fight only "happens" if the hole punching worked. The launchers are
driven by these test hooks in the rebuild:

| Variable | Effect |
|---|---|
| `T6_AUTO_LOGIN=name:password` | Log in when connected; register the account if it doesn't exist |
| `T6_AUTO_SEARCH=ranked\|player` | Start searching once logged in and the game is parked |
| `T6_AUTO_ACCEPT=1` | Accept found matches |
| `T6_AUTO_NEXT=1` | Press "Next game", and "Back to menu" when the set is over |

## Differences from the original server (as far as the launcher shows)

* **Rules are my own.** MMR is standard Elo (K 32, start 500, per character). The rank is
  500 MMR = "Expert", moving one step per 25 MMR. Sets are first to 2 (ranked and player)
  and first to 3 in lobbies, all configurable.
* **Not implemented:** `lag_warn` (the lag statistic in `result` is stored but not analysed),
  polls (`choice` is acknowledged but there is no poll to vote on) and admin tools.
  `notice` comes from `--notice`.
* **Simple matchmaking:** oldest-waiting compatible pair first. "Compatible" means the same
  launcher version and build fingerprint, region lock, side wishes, blocks, and not the same
  network for ranked.
* Version check: with `--versions 2.2.6,…` other launcher versions get the `protocol` error.
  By default any version is accepted.
