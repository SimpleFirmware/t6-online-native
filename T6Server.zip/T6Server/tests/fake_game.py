#!/usr/bin/env python3
"""Stand-in for native/tekken6.exe, for testing the launcher + server without the real game.

Copy (or symlink) it as <package>/native/tekken6.exe and make it executable. It behaves like
the parked online game: reads commands from $T6_NET_CMD (cmd.txt), writes status.txt next to
it, and on "start ... port=P remote=IP:PORT seed=S" really exchanges UDP packets with the
opponent's fake game at that address - so a fight only "happens" if the hole punching handed
the launcher a working address. The winner is derived from the seed, so both sides agree.

    FAKE_FIGHT_SECONDS   how long a fight lasts (default 2)
    FAKE_WINNER          force the winner (1 or 2)
"""

import os
import socket
import sys
import time

cmd_path = os.environ.get("T6_NET_CMD")
if not cmd_path:
    sys.exit("T6_NET_CMD is not set - start me from the launcher")
run_dir = os.path.dirname(cmd_path)
status_path = os.path.join(run_dir, "status.txt")
log_path = os.path.join(run_dir, "fake_game.log")
FIGHT = float(os.environ.get("FAKE_FIGHT_SECONDS", "2"))


def log(text):
    with open(log_path, "a") as f:
        f.write(f"{time.strftime('%H:%M:%S')} {text}\n")


def status(*lines):
    tmp = status_path + ".tmp"
    with open(tmp, "w") as f:
        f.write("\n".join(lines) + "\n")
    os.replace(tmp, status_path)


def parked():
    status("state ready", "statehash 0badc0de", "heaphash 1234")


def parse_start(line):
    args = dict(p.split("=", 1) for p in line.split()[1:] if "=" in p)
    ip, port = args["remote"].rsplit(":", 1)
    return int(args["player"]), int(args["port"]), (ip, int(port)), int(args["seed"])


def fight(line):
    me, port, remote, seed = parse_start(line)
    log(f"start: player {me}, port {port}, remote {remote}, seed {seed}")
    status("state loading")
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("0.0.0.0", port))
    sock.settimeout(0.1)
    contact = False
    start = time.time()
    last_heard = 0.0
    fight_start = None
    winner = int(os.environ.get("FAKE_WINNER", (seed % 2) + 1))
    try:
        while True:
            if check_commands() in ("park", "quit"):
                return
            sock.sendto(f"frame {me}".encode(), remote)
            try:
                data, addr = sock.recvfrom(100)
                if data.startswith(b"frame") and not data.endswith(str(me).encode()):
                    if not contact:
                        log(f"opponent's game answered from {addr}")
                    contact = True
                    last_heard = time.time()
            except socket.timeout:
                pass
            now = time.time()
            if not contact:
                if now - start > 10:
                    status("state error no connection to the opponent")
                    log("no contact with the opponent")
                    return wait_for_park()
                continue
            if fight_start is None:
                fight_start = now
            if now - last_heard > 3:
                status("state fight", "disconnected")
                log("opponent's game went silent")
                return wait_for_park()
            elapsed = now - fight_start
            if elapsed < FIGHT:
                status("state fight", f"round {1 + int(elapsed * 2 / FIGHT)}", "slow 0", "lag 0 0 20")
            else:
                status("state result", f"winner {winner}", "round 3", "slow 0", "lag 1 2 20")
                log(f"fight over, winner {winner}")
                # Keep answering a little so the other side also sees the end.
                linger = time.time()
                while time.time() - linger < 1.0:
                    sock.sendto(f"frame {me}".encode(), remote)
                    time.sleep(0.05)
                return wait_for_park()
    finally:
        sock.close()


pending = []
offset = 0


def check_commands():
    """Read new lines from cmd.txt. Returns the last control command seen (park/quit/start)."""
    global offset
    try:
        with open(cmd_path) as f:
            f.seek(offset)
            data = f.read()
            offset = f.tell()
    except FileNotFoundError:
        return None
    result = None
    for line in data.splitlines():
        line = line.strip()
        if not line:
            continue
        log(f"command: {line[:80]}")
        word = line.split()[0]
        if word == "quit":
            log("quit")
            sys.exit(0)
        if word == "park":
            parked()
            result = "park"
            pending.clear()
        elif word == "start":
            pending.append(line)
            result = result or "start"
    return result


def wait_for_park():
    while True:
        if check_commands() == "park":
            return
        time.sleep(0.1)


def main():
    log("fake game started (parked)")
    time.sleep(0.5)          # "loading"
    parked()
    while True:
        check_commands()
        if pending:
            line = pending[-1]
            pending.clear()
            fight(line)
        time.sleep(0.1)


if __name__ == "__main__":
    main()
