"""End-to-end tests of the lobby server with scripted launchers.

    python -m unittest discover -s tests -v
"""

import asyncio
import os
import socket
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from t6server.certs import ensure_certificate   # noqa: E402
from t6server.config import Config              # noqa: E402
from t6server.server import Server              # noqa: E402
from tests.client import TestClient             # noqa: E402

import logging  # noqa: E402
logging.basicConfig(level=os.environ.get("T6_TEST_LOG", "WARNING"))


def free_port(kind=socket.SOCK_STREAM):
    s = socket.socket(socket.AF_INET, kind)
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


class ServerTest(unittest.IsolatedAsyncioTestCase):
    tls = False
    overrides: dict = {}

    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        cfg = Config(host="127.0.0.1", port=free_port(), udp_port=free_port(socket.SOCK_DGRAM),
                     plain=not self.tls, db=os.path.join(self.tmp.name, "t.db"),
                     cert=os.path.join(self.tmp.name, "c.pem"), key=os.path.join(self.tmp.name, "k.pem"),
                     log_dir=os.path.join(self.tmp.name, "logs"),
                     confirm_seconds=2, next_seconds=2, handshake_seconds=4, ready_seconds=3,
                     result_wait_seconds=1)
        for k, v in self.overrides.items():
            setattr(cfg, k, v)
        if self.tls:
            ensure_certificate(cfg.cert, cfg.key, logging.getLogger())
        self.cfg = cfg
        self.server = Server(cfg)
        await self.server.start()
        self.clients = []

    async def asyncTearDown(self):
        for c in self.clients:
            await c.close()
        await self.server.stop()
        self.tmp.cleanup()

    async def client(self, name) -> TestClient:
        c = TestClient(name)
        await c.connect(self.cfg.port, cert=self.cfg.cert if self.tls else None)
        self.clients.append(c)
        return c

    async def guests(self, *names, **hello):
        out = []
        for n in names:
            c = await self.client(n)
            await c.as_guest(machine=f"m-{n}", **hello)
            out.append(c)
        return out

    async def accounts(self, *names, **hello):
        out = []
        for n in names:
            c = await self.client(n)
            await c.as_account(**hello)
            out.append(c)
        return out

    # ---- helpers that walk through a match -------------------------------------------------

    @staticmethod
    def ready(*clients, state=""):
        for c in clients:
            c.send("ready", local_ip="", local_port=0, state=state, random_stage=False)

    async def quick_until_lobby(self, a, b, ranked=False):
        for c in (a, b):
            c.send("quick", **({"ranked": True} if ranked else {}))
            await c.expect("queued")
        la = await a.expect("lobby", quick=True)
        await b.expect("lobby", quick=True)
        return la

    async def start_game(self, a, b):
        """Both ready -> both get "start"; returns {client: start message}."""
        self.ready(a, b)
        starts = {a: await a.expect("start"), b: await b.expect("start")}
        self.assertEqual(starts[a]["match_id"], starts[b]["match_id"])
        self.assertEqual({starts[a]["role"], starts[b]["role"]}, {1, 2})
        return starts

    async def through_confirm(self, a, b, mid):
        for c in (a, b):
            await c.expect("peer", match_id=mid)
            await c.expect("confirm", match_id=mid)
        a.send("accept", match_id=mid, yes=True)
        await b.expect("accepted", match_id=mid)
        b.send("accept", match_id=mid, yes=True)
        for c in (a, b):
            await c.expect("go", match_id=mid)

    @staticmethod
    def by_role(starts):
        return {m["role"]: c for c, m in starts.items()}

    def report(self, starts, winner, slow=0):
        for c, m in starts.items():
            c.send("playing", match_id=m["match_id"])
            c.send("result", match_id=m["match_id"], winner=winner, slow=slow, lag=0, behind=0, ping=20)


class TlsAndAccounts(ServerTest):
    tls = True

    async def test_tls_guest_login(self):
        c = await self.client("Alice")
        await c.hello()
        c.send("guest", name="Alice")
        acc = await c.expect("account")
        self.assertTrue(acc["guest"])
        self.assertEqual(acc["name"], "Alice")
        self.assertEqual(acc["rank_names"][acc["rank"]], "Expert")

    async def test_protocol_mismatch(self):
        c = await self.client("old")
        c.send("hello", proto=1, version="1.0")
        err = await c.expect("error")
        self.assertEqual(err["msg"], "protocol")

    async def test_register_login_session(self):
        c = await self.client("Bob")
        await c.hello()
        c.send("register", name="Bob", password="short")
        self.assertEqual((await c.expect("error"))["msg"], "password_short")
        c.send("register", name="x", password="longenough")
        self.assertEqual((await c.expect("error"))["msg"], "name_invalid")
        c.send("register", name="Bob", password="longenough")
        acc = await c.expect("account")
        self.assertFalse(acc["guest"])
        session = acc["session"]

        d = await self.client("Bob2")
        await d.hello()
        d.send("register", name="bob", password="whatever1")
        self.assertEqual((await d.expect("error"))["msg"], "name_taken")
        d.send("login", name="Bob", password="wrong!!")
        self.assertEqual((await d.expect("error"))["msg"], "bad_login")
        d.send("auth", session=session)
        acc2 = await d.expect("account")
        self.assertEqual(acc2["name"], "Bob")
        self.assertNotIn("session", acc2)
        # The first connection was logged out.
        self.assertEqual((await c.expect("error"))["msg"], "logged_in_elsewhere")

        d.send("settings", data={"delay": 2, "char_index": 5})
        d.send("logout", session=session)
        await d.expect("logged_out")
        e = await self.client("Bob3")
        await e.hello()
        e.send("auth", session=session)
        self.assertEqual((await e.expect("error"))["msg"], "session_expired")
        e.send("login", name="Bob", password="longenough")
        acc3 = await e.expect("account")
        self.assertEqual(acc3["settings"], {"delay": 2, "char_index": 5})

    async def test_login_first(self):
        c = await self.client("nobody")
        await c.hello()
        c.send("quick")
        self.assertEqual((await c.expect("error"))["msg"], "login first")

    async def test_too_many_attempts(self):
        c = await self.client("brute")
        await c.hello()
        for _ in range(self.cfg.login_attempts_per_minute):
            c.send("login", name="nobody", password="xxxxxx")
            self.assertEqual((await c.expect("error"))["msg"], "bad_login")
        c.send("login", name="nobody", password="xxxxxx")
        self.assertEqual((await c.expect("error"))["msg"], "too_many_attempts")


class InsecureLogin(ServerTest):
    async def test_plain_login_from_loopback_is_allowed_but_not_remote(self):
        c = await self.client("Lo")
        await c.hello()
        c.send("register", name="Lo", password="secret123")
        await c.expect("account")
        # Pretend the connection came from elsewhere.
        srv_client = next(iter(self.server.clients))
        srv_client.ip = "203.0.113.5"
        c.send("login", name="Lo", password="secret123")
        self.assertEqual((await c.expect("error"))["msg"], "insecure")


class QuickMatch(ServerTest):
    async def test_player_match_full_set(self):
        a, b = await self.guests("A", "B")
        lobby = await self.quick_until_lobby(a, b)
        self.assertTrue(lobby["lobby"]["queue"])
        starts = await self.start_game(a, b)
        mid = starts[a]["match_id"]
        self.assertEqual(starts[a]["seed"], starts[b]["seed"])
        self.assertEqual(starts[a]["p1"]["name"], starts[b]["p1"]["name"])
        await self.through_confirm(a, b, mid)
        # Both launchers found each other over UDP.
        self.assertIsNotNone(a.udp[mid].peer)
        self.assertIsNotNone(b.udp[mid].peer)
        self.assertEqual(a.udp[mid].seen_addr[0], a.udp[mid].transport.get_extra_info("sockname")[1])

        self.report(starts, winner=1)
        s = await a.expect("set")
        await b.expect("set")
        self.assertEqual(s["wins"], [1, 0])
        self.assertEqual(s["target"], 2)

        # Next game: no confirm this time, straight to go.
        starts2 = await self.start_game(a, b)
        mid2 = starts2[a]["match_id"]
        self.assertNotEqual(mid, mid2)
        self.assertEqual(self.by_role(starts2)[1], self.by_role(starts)[1], "sides stay the same")
        for c in (a, b):
            await c.expect("go", match_id=mid2)
        self.report(starts2, winner=1)
        over = await a.expect("set_over")
        self.assertEqual(over["why"], "done")
        self.assertEqual(over["wins"], [2, 0])
        await b.expect("set_over")

        p1 = self.by_role(starts)[1]
        p1.send("history", name=p1.name)
        h = await p1.expect("history")
        self.assertEqual([m["result"] for m in h["matches"]], ["win", "win"])

    async def test_results_disagree_not_counted(self):
        a, b = await self.guests("A", "B")
        await self.quick_until_lobby(a, b)
        starts = await self.start_game(a, b)
        mid = starts[a]["match_id"]
        await self.through_confirm(a, b, mid)
        a.send("result", match_id=mid, winner=1)
        b.send("result", match_id=mid, winner=2)
        s = await a.expect("set")
        self.assertEqual(s["wins"], [0, 0])

    async def test_one_result_is_enough_after_wait(self):
        a, b = await self.guests("A", "B")
        await self.quick_until_lobby(a, b)
        starts = await self.start_game(a, b)
        mid = starts[a]["match_id"]
        await self.through_confirm(a, b, mid)
        a.send("result", match_id=mid, winner=2)
        s = await b.expect("set", timeout=3)
        self.assertEqual(s["wins"], [0, 1])

    async def test_decline_requeues_the_other(self):
        a, b = await self.guests("A", "B")
        await self.quick_until_lobby(a, b)
        starts = await self.start_game(a, b)
        mid = starts[a]["match_id"]
        for c in (a, b):
            await c.expect("confirm", match_id=mid)
        a.send("accept", match_id=mid, yes=False)
        ca, cb = await a.expect("cancel"), await b.expect("cancel")
        self.assertEqual((ca["reason"], ca["you"]), ("declined", True))
        self.assertEqual((cb["reason"], cb["you"]), ("declined", False))
        await b.expect("left", reason="requeue")
        await b.expect("queued")
        await a.nothing("queued", 0.5)

    async def test_confirm_timeout(self):
        a, b = await self.guests("A", "B")
        await self.quick_until_lobby(a, b)
        starts = await self.start_game(a, b)
        mid = starts[a]["match_id"]
        await a.expect("confirm")
        a.send("accept", match_id=mid, yes=True)
        cb = await b.expect("cancel", timeout=5)
        self.assertEqual((cb["reason"], cb["you"]), ("timeout", True))
        await a.expect("queued")

    async def test_ping_too_high_cancels_and_avoids_pair(self):
        a, b = await self.guests("A", "B")
        b.ping_ok = False
        await self.quick_until_lobby(a, b)
        await self.start_game(a, b)
        c = await a.expect("cancel")
        self.assertEqual(c["reason"], "ping")
        await a.expect("queued")
        await b.expect("queued")
        await a.nothing("lobby", 1.5)       # not paired again right away

    async def test_handshake_timeout_when_udp_blocked(self):
        a, b = await self.guests("A", "B")
        b.auto_udp = False                   # b's UDP never gets out
        await self.quick_until_lobby(a, b)
        await self.start_game(a, b)
        c = await a.expect("cancel", timeout=6)
        self.assertEqual((c["reason"], c["you"]), ("left", False))

    async def test_ready_timeout_requeues(self):
        a, b = await self.guests("A", "B")
        await self.quick_until_lobby(a, b)
        self.ready(a)
        await a.expect("left", reason="requeue", timeout=5)
        await a.expect("queued")
        await b.nothing("queued", 0.5)

    async def test_cancel_search(self):
        a, b = await self.guests("A", "B")
        a.send("quick")
        await a.expect("queued")
        a.send("quick_cancel")
        await asyncio.sleep(0.2)
        b.send("quick")
        await b.expect("queued")
        await b.nothing("lobby", 1.5)

    async def test_different_builds_are_not_paired(self):
        a = (await self.guests("A"))[0]
        b = (await self.guests("B", build="other"))[0]
        a.send("quick")
        b.send("quick")
        await a.nothing("lobby", 1.5)

    async def test_side_wishes(self):
        a, b = await self.guests("A", "B")
        b.send("profile", char=3, costume=0, custom="", side=1, region="EU", region_lock=False, strict=False)
        await b.expect("account")
        await self.quick_until_lobby(a, b)
        starts = await self.start_game(a, b)
        self.assertEqual(starts[b]["role"], 1)

    async def test_region_lock(self):
        a = (await self.guests("A", region="EU", region_lock=True))[0]
        b = (await self.guests("B", region="USA"))[0]
        a.send("quick")
        b.send("quick")
        await a.nothing("lobby", 1.5)

    async def test_ranked_needs_account(self):
        (a,) = await self.guests("A")
        a.send("quick", ranked=True)
        self.assertEqual((await a.expect("error"))["msg"], "ranked_needs_account")

    async def test_ranked_refused_on_same_network(self):
        a, b = await self.accounts("Ra", "Rb")
        a.send("quick", ranked=True)
        b.send("quick", ranked=True)
        await a.nothing("lobby", 1.5)

    async def test_slow_end(self):
        a, b = await self.guests("A", "B")
        await self.quick_until_lobby(a, b)
        starts = await self.start_game(a, b)
        await self.through_confirm(a, b, starts[a]["match_id"])
        self.report(starts, winner=2, slow=80)
        await a.expect("slow_end")

    async def test_next_game_timeout(self):
        a, b = await self.guests("A", "B")
        await self.quick_until_lobby(a, b)
        starts = await self.start_game(a, b)
        await self.through_confirm(a, b, starts[a]["match_id"])
        self.report(starts, winner=2)
        await a.expect("set")
        self.ready(a)                        # only one presses Next game
        over = await b.expect("set_over", timeout=6)
        self.assertEqual(over["why"], "next_timeout")

    async def test_state_warning_in_player_match(self):
        a, b = await self.guests("A", "B")
        await self.quick_until_lobby(a, b)
        a.send("ready", local_ip="", local_port=0, state="aaa/1", random_stage=False)
        b.send("ready", local_ip="", local_port=0, state="bbb/1", random_stage=False)
        s = await a.expect("start")
        self.assertTrue(s.get("state_warning"))

    async def test_leave_during_handshake(self):
        a, b = await self.guests("A", "B")
        b.auto_udp = False
        await self.quick_until_lobby(a, b)
        await self.start_game(a, b)
        b.send("leave")
        ca = await a.expect("cancel")
        self.assertEqual((ca["reason"], ca["you"]), ("left", False))
        await a.expect("queued")

    async def test_disconnect_during_fight(self):
        a, b = await self.guests("A", "B")
        await self.quick_until_lobby(a, b)
        starts = await self.start_game(a, b)
        await self.through_confirm(a, b, starts[a]["match_id"])
        await b.close()
        self.clients.remove(b)
        await a.expect("left", reason="host_left")
        over = await a.expect("set_over")
        self.assertEqual(over["why"], "forfeit")
        a.send("history", name="A")
        h = await a.expect("history")
        self.assertEqual((h["matches"][0]["result"], h["matches"][0]["how"]), ("win", "disconnect"))

    async def test_block(self):
        a, b = await self.guests("A", "B")
        await self.quick_until_lobby(a, b)
        a.send("leave")
        await b.expect("queued")
        b.send("quick_cancel")
        a.send("block")
        self.assertEqual((await a.expect("blocked"))["name"], "B")
        a.send("blocks")
        blocks = (await a.expect("blocks"))["list"]
        self.assertEqual([x["name"] for x in blocks], ["B"])
        a.send("quick")
        b.send("quick")
        await a.nothing("lobby", 1.5)
        a.send("unblock", id=blocks[0]["id"])
        self.assertEqual((await a.expect("blocks"))["list"], [])
        await a.expect("lobby", timeout=3)

    async def test_online_and_guest_names(self):
        a = (await self.guests("Same"))[0]
        b = await self.client("Same")
        await b.hello()
        b.send("guest", name="Same")
        acc = await b.expect("account")
        self.assertNotEqual(acc["name"], "Same")
        n = await a.expect("online", timeout=3)
        self.assertEqual(n["n"], 2)


class Ranked(ServerTest):
    overrides = {"allow_same_network": True}

    async def test_ranked_set_rates_and_leaderboard(self):
        a, b = await self.accounts("Kaz", "Jin")
        await self.quick_until_lobby(a, b, ranked=True)
        starts = await self.start_game(a, b)
        self.assertTrue(starts[a]["ranked"])
        winner_client = self.by_role(starts)[1]
        loser_client = self.by_role(starts)[2]
        for game in range(2):
            if game:
                starts = await self.start_game(a, b)
                for c in (a, b):
                    await c.expect("go")
            else:
                await self.through_confirm(a, b, starts[a]["match_id"])
            self.report(starts, winner=1)
            rw = await winner_client.expect("rated")
            rl = await loser_client.expect("rated")
            self.assertGreater(rw["elo_delta"], 0)
            self.assertLess(rl["elo_delta"], 0)
            self.assertEqual(rw["set"], [game + 1, 0])
        self.assertEqual(rw["elo"], 500 + 16 + 15)     # K=32: +16 then +15
        await a.expect("set_over", why="done")

        a.send("leaderboard", region="")
        lb = await a.expect("leaderboard")
        self.assertEqual([p["name"] for p in lb["players"]], [winner_client.name, loser_client.name])
        self.assertIn("you", lb)
        a.send("leaderboard", region="USA")
        self.assertEqual((await a.expect("leaderboard"))["players"], [])

    async def test_forfeit_is_double_loss(self):
        a, b = await self.accounts("Law", "Lei")
        await self.quick_until_lobby(a, b, ranked=True)
        starts = await self.start_game(a, b)
        await self.through_confirm(a, b, starts[a]["match_id"])
        a.send("forfeit", match_id=starts[a]["match_id"])
        ra, rb = await a.expect("rated"), await b.expect("rated")
        self.assertEqual((ra["quit"], rb["quit"]), (1, 2))
        self.assertEqual(ra["elo_delta"], -32)
        self.assertEqual(rb["elo_delta"], 16)
        await b.expect("set_over", why="forfeit")

    async def test_char_locked_in_ranked_set(self):
        a, b = await self.accounts("Paul", "King")
        await self.quick_until_lobby(a, b, ranked=True)
        starts = await self.start_game(a, b)
        await self.through_confirm(a, b, starts[a]["match_id"])
        a.send("profile", char=3)
        self.assertEqual((await a.expect("error"))["msg"], "char_locked_set")

    async def test_state_mismatch_refuses_ranked(self):
        a, b = await self.accounts("Nina", "Anna")
        await self.quick_until_lobby(a, b, ranked=True)
        a.send("ready", local_ip="", local_port=0, state="aaa/1", random_stage=False)
        b.send("ready", local_ip="", local_port=0, state="bbb/1", random_stage=False)
        self.assertEqual((await a.expect("error"))["msg"], "state_mismatch")

    async def test_mmr_is_per_character(self):
        a, b = await self.accounts("Bryan", "Steve")
        await self.quick_until_lobby(a, b, ranked=True)
        starts = await self.start_game(a, b)
        await self.through_confirm(a, b, starts[a]["match_id"])
        a.send("forfeit", match_id=starts[a]["match_id"])
        await a.expect("set_over")
        a.send("profile", char=20)
        acc = await a.expect("account")
        self.assertEqual(acc["elo"], 500)            # fresh character
        self.assertEqual(acc["chars"]["16"]["elo"], 468)


class Lobbies(ServerTest):
    async def test_public_lobby_probe_and_match(self):
        a, b = await self.guests("Host", "Guest")
        a.send("create", public=True, ranked=False)
        lob = (await a.expect("lobby"))["lobby"]
        self.assertFalse(lob["private"])
        b.send("list", private=False)
        ls = (await b.expect("lobbies"))["lobbies"]
        self.assertEqual([x["id"] for x in ls], [lob["id"]])
        b.send("join", id=lob["id"])
        joined = (await a.expect("lobby"))["lobby"]
        self.assertEqual(joined["guest"]["name"], "Guest")
        # Connection test inside the lobby.
        pa, pb = await a.expect("probe"), await b.expect("probe")
        self.assertEqual({pa["role"], pb["role"]}, {1, 2})
        await a.expect("probe_peer")
        await b.expect("probe_peer")
        for _ in range(40):
            if a.udp[pa["id"]].samples and b.udp[pb["id"]].samples:
                break
            await asyncio.sleep(0.05)
        self.assertTrue(a.udp[pa["id"]].samples, "probe ping measured")

        a.send("stage", stage=5)
        self.assertEqual((await b.expect("lobby"))["lobby"]["stage"], 5)
        await a.expect("lobby")
        b.send("stage", stage=7)             # only the host may change it
        await a.nothing("lobby", 0.5)

        starts = await self.start_game(a, b)
        self.assertEqual(starts[a]["stage"], 5)
        self.assertFalse(starts[a]["queue"])
        for c in (a, b):
            await c.expect("go")             # no Accept step in lobbies
        self.report(starts, winner=1)
        s = await a.expect("set")
        self.assertEqual(s["target"], 3)

    async def test_private_lobby_code(self):
        a, b = await self.guests("Host", "Guest")
        a.send("create", public=False, ranked=False)
        lob = (await a.expect("lobby"))["lobby"]
        code = lob["code"]
        self.assertEqual(len(code), 5)
        b.send("list", private=False)
        self.assertEqual((await b.expect("lobbies"))["lobbies"], [])
        b.send("list", private=True)
        listed = (await b.expect("lobbies"))["lobbies"]
        self.assertNotIn("code", listed[0])
        b.send("join", id=lob["id"], code="WRONG")
        self.assertEqual((await b.expect("error"))["msg"], "wrong_code")
        b.send("join", code="NOPE1")
        self.assertEqual((await b.expect("error"))["msg"], "wrong_code")
        b.send("join", code=code.lower())
        await b.expect("lobby")

    async def test_guest_leaves_and_host_leaves(self):
        a, b, c = await self.guests("Host", "Guest", "Third")
        a.send("create", public=True, ranked=False)
        lob = (await a.expect("lobby"))["lobby"]
        b.send("join", id=lob["id"])
        await a.expect("lobby")
        c.send("join", id=lob["id"])
        self.assertEqual((await c.expect("error"))["msg"], "lobby_not_found")
        b.send("leave")
        upd = (await a.expect("lobby"))["lobby"]
        self.assertEqual(upd["guest"], {})
        c.send("join", id=lob["id"])
        await c.expect("lobby")
        a.send("leave")
        await c.expect("left", reason="host_left")
        c.send("list", private=True)
        self.assertEqual((await c.expect("lobbies"))["lobbies"], [])

    async def test_version_mismatch(self):
        (a,) = await self.guests("Host")
        (b,) = await self.guests("Guest", build="different")
        a.send("create", public=True, ranked=False)
        lob = (await a.expect("lobby"))["lobby"]
        b.send("join", id=lob["id"])
        err = await b.expect("error")
        self.assertEqual((err["msg"], err["yours"], err["theirs"]), ("version_mismatch", "2.2.6", "2.2.6"))

    async def test_leave_set_between_games(self):
        a, b = await self.guests("Host", "Guest")
        a.send("create", public=True, ranked=False)
        lob = (await a.expect("lobby"))["lobby"]
        b.send("join", id=lob["id"])
        starts = await self.start_game(a, b)
        for c in (a, b):
            await c.expect("go")
        self.report(starts, winner=2)
        await a.expect("set")
        b.send("leave")
        over = await a.expect("set_over")
        self.assertEqual((over["why"], over["left"]), ("left", 2))

    async def test_log_upload(self):
        (a,) = await self.guests("Host")
        a.send("log", i=0, n=1, data="hello log", version="2.2.6")
        self.assertTrue((await a.expect("log_saved"))["ok"])
        files = os.listdir(self.cfg.log_dir)
        self.assertEqual(len(files), 1)


if __name__ == "__main__":
    unittest.main()
