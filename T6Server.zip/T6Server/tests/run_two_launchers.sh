#!/bin/sh
# End-to-end test: this server + two real T6Launcher instances + the fake game, over TLS.
# The launchers log in (registering the accounts), search ranked, accept, play a whole set
# through the fake game (real UDP between the two fake games) and go back to the menu.
#
#   tests/run_two_launchers.sh /path/to/T6Launcher-binary [mode] [quit]
#     mode = ranked | player
#     quit = kill launcher 2 (and its game) in the middle of the first fight
set -eu
LAUNCHER=$(realpath "$1")
MODE=${2:-ranked}
QUIT=${3:-}
if [ -n "$QUIT" ]; then FIGHT=8; NEED=1; else FIGHT=2; NEED=2; fi
HERE=$(cd "$(dirname "$0")/.." && pwd)
WORK=$(mktemp -d)
PORT=17700
UDP=17701

mkdir -p "$WORK/pkg/native/game"
cp "$LAUNCHER" "$WORK/pkg/T6Launcher"
cp "$HERE/tests/fake_game.py" "$WORK/pkg/native/tekken6.exe"
chmod +x "$WORK/pkg/native/tekken6.exe"

cd "$HERE"
python3 -m t6server --data "$WORK/data" --port $PORT --udp-port $UDP --allow-same-network \
    --next-seconds 10 -v > "$WORK/server.log" 2>&1 &
SERVER=$!
sleep 1.5

run_launcher() {   # instance name
    T6_LOBBY_SERVER=tls://127.0.0.1:$PORT T6_LOBBY_CERT="$WORK/data/server.pem" T6_NO_UPNP=1 \
    FAKE_FIGHT_SECONDS=$FIGHT T6_AUTO_LOGIN="$2:password1" T6_AUTO_SEARCH=$MODE T6_AUTO_ACCEPT=1 T6_AUTO_NEXT=1 \
    QT_QPA_PLATFORM=offscreen \
        "$WORK/pkg/T6Launcher" --instance "$1" > "$WORK/launcher$1.out" 2>&1 &
}
run_launcher 1 Alice
L1=$!
run_launcher 2 Bob
L2=$!

if [ -n "$QUIT" ]; then
    # Wait for the fight to start, then pull the plug on launcher 2 and its game.
    i=0
    while [ $i -lt 30 ] && ! grep -q "opponent's game answered" "$WORK/pkg/runs/online_2/fake_game.log" 2>/dev/null; do
        sleep 1; i=$((i + 1))
    done
    sleep 2
    echo "== killing launcher 2 mid-fight"
    pkill -9 -P $L2 || true      # its game
    kill -9 $L2
fi

# Wait until the set is over and both launchers are back in the menu (or 90 s).
i=0
while [ $i -lt 90 ]; do
    if [ "$(grep -c '"t":"set_over"' "$WORK/server.log" || true)" -ge $NEED ] && \
       [ "$(grep -c '>> {"t": "leave"' "$WORK/server.log" || true)" -ge $NEED ]; then
        break
    fi
    sleep 1; i=$((i + 1))
done
sleep 1
kill $L1 $L2 2>/dev/null || true
sleep 1
kill $SERVER 2>/dev/null || true
wait 2>/dev/null || true

echo "== server: matches and results"
grep -E "queue match|game .* (started|finished|cancelled)|logged in|new account" "$WORK/server.log" | sed 's/^[0-9-]* //'
echo "== server: rated / set messages"
grep -E '"t":"(rated|set|set_over|left|cancel|error)"' "$WORK/server.log" | sed -E 's/^[0-9-]+ ([0-9:,]+) DEBUG t6server: /\1 /' | cut -c1-170
for n in 1 2; do
    echo "== fake game $n"
    cat "$WORK/pkg/runs/online_$n/fake_game.log" 2>/dev/null | grep -v "command: start" || echo "(no log)"
done
echo "== work dir: $WORK"
