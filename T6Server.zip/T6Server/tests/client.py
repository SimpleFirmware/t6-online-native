"""A scripted launcher for tests: speaks the lobby protocol over TCP/TLS and does the same UDP
hole punching as the real launcher (punch -> hi -> pp/pq -> ping_report).
"""

import asyncio
import json
import ssl


class UdpPeer(asyncio.DatagramProtocol):
    """The launcher's PeerLink / LobbyProbe in a few lines."""

    def __init__(self, client, kind, msg):
        self.client = client
        self.kind = kind                    # "match" or "probe"
        self.id = msg["match_id"] if kind == "match" else msg["id"]
        self.token = msg["token"]
        self.role = msg["role"]
        self.server_port = msg["udp_port"]
        self.candidates = []
        self.peer = None
        self.samples = []
        self.reported = False
        self.seen_addr = None
        self.transport = None
        self.loop = asyncio.get_running_loop()
        self.t0 = self.loop.time()
        self.task = None

    def connection_made(self, transport):
        self.transport = transport
        self.task = asyncio.ensure_future(self.run())

    def tag(self):
        return {"match": self.id} if self.kind == "match" else {"probe": self.id}

    def sendto(self, obj, addr):
        self.transport.sendto(json.dumps(obj).encode(), tuple(addr))

    async def run(self):
        tick = 0
        while not self.reported and tick < 150:
            tick += 1
            if not self.candidates and tick % 2 == 1:
                punch = {"t": "punch", "token": self.token}
                if self.kind == "probe":
                    punch["local"] = ["127.0.0.1", self.transport.get_extra_info("sockname")[1]]
                self.sendto(punch, (self.client.host, self.server_port))
            for c in self.candidates:
                self.sendto({"t": "hi", "role": self.role, **self.tag()}, c)
            if self.peer is not None:
                self.sendto({"t": "pp", "ts": int((self.loop.time() - self.t0) * 1000), **self.tag()}, self.peer)
                if len(self.samples) >= 3 and self.kind == "match":
                    self.reported = True
                    self.client.send("ping_report", match_id=self.id, ms=min(self.samples),
                                     ok=self.client.ping_ok)
                elif len(self.samples) >= 3:
                    self.reported = True
            await asyncio.sleep(0.05)

    def datagram_received(self, data, addr):
        msg = json.loads(data)
        t = msg.get("t")
        if t == "seen":
            self.seen_addr = msg["addr"]
            return
        if msg.get("match", msg.get("probe")) != self.id:
            return
        if t == "hi" and msg.get("role") != self.role and self.peer is None:
            self.peer = addr
        elif t == "pp":
            self.sendto({"t": "pq", "ts": msg["ts"], **self.tag()}, addr)
        elif t == "pq":
            self.samples.append(int((self.loop.time() - self.t0) * 1000) - msg["ts"])

    def close(self):
        if self.task:
            self.task.cancel()
        if self.transport:
            self.transport.close()


class TestClient:
    def __init__(self, name="tester"):
        self.name = name
        self.inbox: asyncio.Queue = asyncio.Queue()
        self.log = []
        self.udp: dict[str, UdpPeer] = {}
        self.ping_ok = True
        self.auto_udp = True
        self.host = "127.0.0.1"

    async def connect(self, port, host="127.0.0.1", cert=None):
        self.host = host
        ctx = None
        if cert:
            ctx = ssl.create_default_context(cafile=cert)
            ctx.check_hostname = False      # pinned self-signed certificate, like the launcher
        self.reader, self.writer = await asyncio.open_connection(host, port, ssl=ctx)
        self.reader_task = asyncio.ensure_future(self._read())
        return self

    async def _read(self):
        while True:
            line = await self.reader.readline()
            if not line:
                await self.inbox.put({"t": "_closed"})
                return
            msg = json.loads(line)
            self.log.append(msg)
            if self.auto_udp:
                await self._auto(msg)
            await self.inbox.put(msg)

    async def _auto(self, msg):
        t = msg.get("t")
        loop = asyncio.get_running_loop()
        if t == "start":
            await self._open_udp("match", msg)
        elif t == "probe":
            await self._open_udp("probe", msg)
        elif t == "peer" and msg["match_id"] in self.udp:
            self.udp[msg["match_id"]].candidates = self._candidates(msg)
        elif t == "probe_peer" and msg["id"] in self.udp:
            self.udp[msg["id"]].candidates = self._candidates(msg)

    async def _open_udp(self, kind, msg):
        loop = asyncio.get_running_loop()
        _, proto = await loop.create_datagram_endpoint(
            lambda: UdpPeer(self, kind, msg), local_addr=("127.0.0.1", 0))
        self.udp[proto.id] = proto

    @staticmethod
    def _candidates(msg):
        c = []
        if msg.get("same_nat") and msg.get("local") and msg["local"][1]:
            c.append(tuple(msg["local"]))
        c.append(tuple(msg["public"]))
        return c

    def send(self, t, **fields):
        fields["t"] = t
        self.writer.write((json.dumps(fields) + "\n").encode())

    async def expect(self, t, timeout=5.0, **match):
        """Wait for a message of type t (others are skipped). Fails on timeout."""
        deadline = asyncio.get_running_loop().time() + timeout
        while True:
            left = deadline - asyncio.get_running_loop().time()
            if left <= 0:
                raise AssertionError(f"{self.name}: no {t!r} {match} within {timeout}s; "
                                     f"last messages: {[m.get('t') for m in self.log[-12:]]}")
            try:
                msg = await asyncio.wait_for(self.inbox.get(), left)
            except asyncio.TimeoutError:
                continue
            if msg.get("t") == t and all(msg.get(k) == v for k, v in match.items()):
                return msg

    async def nothing(self, t, seconds=1.0):
        """Assert that no message of type t arrives within `seconds`."""
        try:
            msg = await self.expect(t, timeout=seconds)
        except AssertionError:
            return
        raise AssertionError(f"{self.name}: unexpected {msg}")

    async def hello(self, **overrides):
        h = {"proto": 2, "private_lobbies": True, "version": "2.2.6", "client_id": f"cid-{self.name}",
             "machine": f"m-{self.name}", "char": 16, "costume": 0, "custom": "", "side": 0,
             "region": "EU", "region_lock": False, "strict": False, "build": "b1"}
        h.update(overrides)
        self.send("hello", **h)
        return await self.expect("welcome")

    async def as_guest(self, **hello):
        await self.hello(**hello)
        self.send("guest", name=self.name)
        return await self.expect("account")

    async def as_account(self, password="secret123", **hello):
        await self.hello(**hello)
        self.send("register", name=self.name, password=password)
        msg = await self.expect_any("account", "error")
        if msg["t"] == "error":           # already registered in this database
            self.send("login", name=self.name, password=password)
            msg = await self.expect("account")
        return msg

    async def expect_any(self, *types, timeout=5.0):
        deadline = asyncio.get_running_loop().time() + timeout
        while True:
            left = deadline - asyncio.get_running_loop().time()
            if left <= 0:
                raise AssertionError(f"{self.name}: none of {types} within {timeout}s")
            msg = await asyncio.wait_for(self.inbox.get(), left)
            if msg.get("t") in types:
                return msg

    async def close(self):
        for u in self.udp.values():
            u.close()
        self.reader_task.cancel()
        self.writer.close()
        try:
            await self.writer.wait_closed()
        except Exception:
            pass
