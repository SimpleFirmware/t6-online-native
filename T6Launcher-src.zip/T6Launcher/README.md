# T6Launcher: a readable rebuild of the Tekken 6 Native Online launcher

This is a Qt 6 / C++17 rewrite of the launcher from
[Ekspym/Tekken6-native-online](https://github.com/Ekspym/Tekken6-native-online), release v2.2.6.
I wrote it by studying a decompile of the original `Tekken6NativeOnline.exe`. It is **not the
author's source code**. It reimplements the same behaviour with readable names, comments and
a plain Qt Widgets window, so you can experiment with it.

## Please read first

* **Personal use only.** The original project is not open source. This rebuild is for your
  own learning and experiments. Don't redistribute it or present it as the official launcher.
* **It still talks to the original author's lobby server** (`130.61.213.14:7700`) and reports
  itself as version `2.2.6`. Be a good guest: no message flooding, no fake results. You can
  point it at your own test server instead (see `T6_LOBBY_SERVER` below).
* **You still need the original release package.** This launcher only drives the game. It
  needs the release's `builder\` (Python script that builds the game from your own Tekken 6
  Xbox 360 disc image), `tools\` and, once built, `native\tekken6.exe`.

## Building

You need Qt 6.5 or newer (Core, Gui, Widgets, Network) and CMake 3.21 or newer.

### Windows (MSVC)

1. Install Qt 6 with the Qt online installer and pick the "MSVC 2022 64-bit" kit.
2. Open a "x64 Native Tools Command Prompt for VS 2022" and run:

```bat
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH=C:\Qt\6.8.0\msvc2022_64
cmake --build build
C:\Qt\6.8.0\msvc2022_64\bin\windeployqt.exe build\T6Launcher.exe
```

You can also open the folder in Qt Creator or Visual Studio ("Open folder") and build from there.

### Linux (for testing the UI and protocol)

```sh
cmake -S . -B build -DCMAKE_PREFIX_PATH=/path/to/qt6
cmake --build build -j
```

The game itself is a Windows program. On Linux the Windows-only helpers (hiding windows, job
objects, DXGI) are stubs.

### Installing next to the game

Copy `T6Launcher.exe`, plus the Qt DLLs from `windeployqt`, into the release folder, next to
`Tekken6NativeOnline.exe`, `builder\` and `tools\`. It uses the same `launcher_native.ini`, so
your settings carry over. Close the original launcher first: both use the same UDP port.

## Code tour

| File | What it does |
|---|---|
| `src/main.cpp` | Start-up: `--instance N`, single-instance lock, post-update cleanup |
| `src/MatchController.*` | **Start here.** Reacts to every server message and runs a match from search to result |
| `src/net/LobbyClient.*` | TLS connection with certificate pinning. JSON, one object per line |
| `src/net/PeerLink.*` | UDP hole punching and ping measurement with the opponent before a match |
| `src/net/LobbyProbe.*` | The same connection test, used inside a lobby |
| `src/net/Upnp.*` | Asks the router to forward the game's UDP port |
| `src/net/NetUtil.*` | Server address, LAN IP, Wi-Fi and Wine detection |
| `src/game/OnlineGame.*` | The "parked" game process: `cmd.txt` in, `status.txt` out |
| `src/game/Practice.*` | Practice-mode game process |
| `src/game/GameLaunch.*` | Run folder, environment variables and command line shared by both |
| `src/game/Platform.*` | Windows helpers (hidden start, job object, window show/hide, sound) |
| `src/core/*` | Settings (`.ini`), static game tables, machine ID and build fingerprint, log, paths |
| `src/build/Builder.*` | Runs `builder\build_native.py` and parses its `STEP/PROGRESS/DONE` lines |
| `src/update/Updater.*` | GitHub release check, SHA-256-verified patch install |
| `src/ui/*` | The window and the key-binding button |

The comment at the top of `MatchController.h` shows the whole match message flow.

## Experimenting

* **Log tab:** shows every message sent (`>>`) and received (`<<`); passwords are masked.
  The box at the bottom sends any JSON object to the server, e.g. `{"t":"leaderboard","region":"EU"}`.
* **Two launchers on one PC:** `T6Launcher.exe --instance 2` uses `launcher_native_2.ini`, UDP
  port 7004 and its own run folders.
* **Your own server:** `T6_LOBBY_SERVER=tcp://127.0.0.1:7700` uses plain TCP, which is easiest
  for a test server. `tls://host:port` keeps TLS; then set `T6_LOBBY_CERT=path\to\cert.pem` to
  pin your own certificate. For a complete server, see T6Server below. A minimal fake server that walks through one
  match handshake is in `tools/fake_server.py`.

### Environment variables

| Variable | Effect |
|---|---|
| `T6_LOBBY_SERVER` | Lobby server URL (`tls://` or `tcp://`) |
| `T6_LOBBY_CERT` | PEM certificate to pin instead of the built-in one |
| `T6_NO_UPNP` | Skip UPnP port forwarding |
| `T6_LAUNCHER_SHOW_GAME` | Don't hide the parked game window |
| `T6_AUTO_ACCEPT` | Accept found matches automatically |
| `T6_ROUNDS`, `T6_ROUND_TIME` | Rounds per game / round time passed to the game |
| `T6_NET_INPUT` | `input=` value of the start command (default `live`) |
| `T6_GAME_ARGS` | Extra command-line settings for the game, e.g. `"--d3d12_tiled_shared_memory=false"` |
| `T6_RENDER_PATH` | Force `--render_target_path_d3d12` (`rtv` or `rov`). Linux builds default to `rtv` (the game runs under Wine) |
| `T6_VERSION_OVERRIDE` | Version reported in `hello` |
| `T6_UPDATE_API` | Release-check URL for the updater |

Start the launcher with `--auto` to join as a guest automatically when there is no saved login.

Test hooks (used by T6Server's `tests/run_two_launchers.sh` to let two launchers play each
other unattended):

| Variable | Effect |
|---|---|
| `T6_AUTO_LOGIN=name:password` | Log in when connected; register the account if it doesn't exist |
| `T6_AUTO_SEARCH=ranked\|player` | Start searching once logged in and the game is parked |
| `T6_AUTO_NEXT` | Press "Next game", and "Back to menu" when the set is over |

### Your own server

T6Server, a separate download, is a self-hosted lobby server that speaks this protocol.
Run `python -m t6server` and start the launcher with
`T6_LOBBY_SERVER=tls://<host>:7700 T6_LOBBY_CERT=<its data/server.pem>`.

## Differences from the original

Reproduced:
* The lobby protocol: hello, auth, guest and login; profile, settings, quick match, lobbies,
  confirm/accept, ready/state hashes, results, forfeits, leaderboard, history and blocks.
* The pinned TLS certificate.
* The UDP handshake and lobby probe.
* The parked-game control, including the exact start command, retries, timeouts, the crash
  limit, and rematch/park.
* Game environment and arguments, shader-cache merge, machine ID and build fingerprint.
* Builder runner, updater and UPnP.

Left out or simplified:
* The original's custom-drawn UI, fonts, rank icons and VS screen. This version uses plain
  Qt widgets.
* Customize mode (custom costume editor). Existing custom looks from the `.ini` are still sent.
* The gamepad-button capture UI. `pad_*` values in the `.ini` are still used.
* Polls/voting UI, crash handler, log upload, tray icon and some explanatory dialogs.
* Some status texts are reworded, and a few rare edge cases are handled more simply than in
  the original.
* **Update tab:** installing an update installs the *original* release's files, including
  the original launcher. It does not update this rebuild.

If the server changes its protocol in a newer release, this rebuild will stop working until
you update it.
