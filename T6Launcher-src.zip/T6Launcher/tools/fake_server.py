# Minimal fake lobby server for local experiments. Run it, then start the launcher with
#   T6_LOBBY_SERVER=tcp://127.0.0.1:17700 T6_NO_UPNP=1 T6_AUTO_ACCEPT=1 T6Launcher --auto
# It accepts a guest, pairs you with a fake opponent on UDP 17999 and walks through
# start -> punch -> peer -> ping_report -> confirm -> accept -> go.
import socket, json, threading, time
u = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); u.bind(("127.0.0.1", 17701)); u.settimeout(8)
peer = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); peer.bind(("127.0.0.1", 17999)); peer.settimeout(8)
s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("127.0.0.1", 17700)); s.listen(1)
c, _ = s.accept(); f = c.makefile("rwb")
def send(o): f.write((json.dumps(o)+"\n").encode()); f.flush()
send({"t":"welcome"})
def peer_loop():
    while True:
        try: d, a = peer.recvfrom(2048)
        except Exception: return
        m = json.loads(d); print("peer<<", m, flush=True)
        if m.get("t") == "hi": peer.sendto(json.dumps({"t":"hi","match":"M1","role":2}).encode(), a)
        if m.get("t") == "pp": peer.sendto(json.dumps({"t":"pq","match":"M1","ts":m["ts"]}).encode(), a)
threading.Thread(target=peer_loop, daemon=True).start()
for line in f:
    m = json.loads(line); print("<<", m, flush=True)
    if m["t"] == "guest":
        send({"t":"account","guest":True,"name":"tester","online":2})
    elif m["t"] == "profile":
        send({"t":"start","match_id":"M1","role":1,"token":"tok","udp_port":17701,"seed":42,"queue":True,
              "p1":{"name":"tester","char":16,"costume":0},"p2":{"name":"bob","char":3,"costume":1}})
        d, a = u.recvfrom(2048); print("udp<<", json.loads(d), flush=True)
        u.sendto(json.dumps({"t":"seen","addr":[a[1], a[0]]}).encode(), a)
        send({"t":"peer","match_id":"M1","public":["127.0.0.1",17999],"local":["127.0.0.1",17999],"same_nat":False})
    elif m["t"] == "ping_report":
        send({"t":"confirm","match_id":"M1","ping":m["ms"],"seconds":15})
    elif m["t"] == "accept":
        send({"t":"go","match_id":"M1"})
        time.sleep(1); break
c.close()
