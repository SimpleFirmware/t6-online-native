#pragma once

#include <QString>
#include <QStringList>

class QProcess;
class QWidget;

// Windows-specific helpers. On other systems they do nothing (the game itself is a Windows
// program; under Wine/Proton the Windows code paths are the ones that run).
namespace Platform {

// Start the process with its window hidden (the parked game stays invisible until a match).
void startHidden(QProcess *process);
// Start a console program without opening a console window (the builder).
void startWithoutConsole(QProcess *process);

// Put a started process into a Windows job object with KILL_ON_JOB_CLOSE, so the game closes
// automatically if the launcher exits or crashes.
void killWithLauncher(qint64 pid);

// Show (optionally borderless fullscreen) or hide the top-level windows of process `pid`.
void showProcessWindows(qint64 pid, bool show, bool borderless);

// End tekken6.exe processes left over from an earlier launcher - only ones started from
// `exePath`, never other programs. Returns how many were ended.
int killStaleGameProcesses(const QString &exePath);

void bringToFront(QWidget *window);
void flashTaskbar(QWidget *window);

// Built-in beep or a .wav file.
void playSound(const QString &wavFile);

// Names of the PC's graphics adapters in DXGI order (index = --d3d12_adapter value).
QStringList graphicsAdapters();

}
