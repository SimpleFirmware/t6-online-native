#include "game/OnlineGame.h"

#include "core/Log.h"
#include "core/Paths.h"
#include "core/Settings.h"
#include "game/GameLaunch.h"
#include "game/Platform.h"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QProcess>

OnlineGame::OnlineGame(Settings &settings, QObject *parent) : QObject(parent), m_settings(settings)
{
    m_pollTimer.setInterval(100);
    connect(&m_pollTimer, &QTimer::timeout, this, &OnlineGame::poll);
}

OnlineGame::~OnlineGame()
{
    if (isRunning())
        kill("the launcher closes");
}

bool OnlineGame::isRunning() const
{
    return m_process && m_process->state() != QProcess::NotRunning;
}

qint64 OnlineGame::pid() const { return m_process ? m_process->processId() : 0; }

QString OnlineGame::logFile() const { return QDir(m_runDir).filePath("tekken6.log"); }

bool OnlineGame::start()
{
    if (m_process)
        return false;
    const QString exe = Paths::builtGameExe();
    if (!QFile::exists(exe)) {
        Log::info("the game is not built yet (native\\tekken6.exe missing)");
        return false;
    }

    m_runDir = Paths::runDir("online");
    m_statusFile = QDir(m_runDir).filePath("status.txt");
    m_cmdFile = QDir(m_runDir).filePath("cmd.txt");
    GameLaunch::prepareRunDir(m_runDir);
    QFile::remove(m_statusFile);
    QFile::remove(m_cmdFile);

    QProcessEnvironment env = GameLaunch::environment(m_settings, m_runDir);
    env.insert("T6_NET", "1");
    env.insert("T6_NET_HOLD", "1");    // load and wait for a "start" command
    env.insert("T6_NET_CMD", QDir::toNativeSeparators(m_cmdFile));
    env.insert("T6_SOUND_SEPARATE", "1");

    m_process = new QProcess(this);
    m_process->setProcessEnvironment(env);
    m_process->setProgram(exe);
    m_process->setWorkingDirectory(QFileInfo(exe).absolutePath());
    m_process->setArguments(GameLaunch::arguments(m_settings, m_runDir));
    if (!qEnvironmentVariableIsSet("T6_LAUNCHER_SHOW_GAME"))
        Platform::startHidden(m_process);

    connect(m_process, &QProcess::finished, this, [this](int code, QProcess::ExitStatus status) {
        m_pollTimer.stop();
        const QString reason = m_killReason;
        Log::info(reason.isEmpty()
                      ? QStringLiteral("the game process ended by itself, exit code 0x%1").arg(uint(code), 0, 16)
                      : QStringLiteral("the game process ended (killed by the launcher: %1)").arg(reason));
        m_process->deleteLater();
        m_process = nullptr;
        m_killReason.clear();
        m_windowShown = false;
        emit finished(code, status == QProcess::CrashExit && reason.isEmpty(), reason);
    });

    Log::setGameLogFile(logFile());
    Log::info(QStringLiteral("starting %1 %2").arg(exe, m_process->arguments().join(' ')));
    m_process->start();
    if (!m_process->waitForStarted(5000)) {
        Log::info("the game could not be started: " + m_process->errorString());
        m_process->deleteLater();
        m_process = nullptr;
        return false;
    }
    Platform::killWithLauncher(m_process->processId());
    m_pollTimer.start();
    return true;
}

void OnlineGame::kill(const QString &reason)
{
    if (!isRunning())
        return;
    m_killReason = reason;
    Log::info("ends the game: " + reason);
    m_process->kill();
}

void OnlineGame::sendCommand(const QString &line)
{
    if (m_cmdFile.isEmpty())
        return;
    QFile f(m_cmdFile);
    if (f.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
        f.write(line.toUtf8() + '\n');
        Log::info("game <- " + line);
    }
}

void OnlineGame::showWindow(bool show)
{
    if (show == m_windowShown || !isRunning())
        return;
    m_windowShown = show;
    Platform::showProcessWindows(pid(), show, m_settings.borderless);
}

void OnlineGame::poll()
{
    QFile f(m_statusFile);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    GameStatus st;
    for (const QString &raw : QString::fromUtf8(f.readAll()).split('\n')) {
        const QString line = raw.trimmed();
        if (line.startsWith("state "))
            st.state = line.mid(6);
        else if (line.startsWith("round "))
            st.round = line.mid(6);
        else if (line.startsWith("winner "))
            st.winner = line.mid(7);
        else if (line.startsWith("slow "))
            st.slow = line.mid(5).toInt();
        else if (line.startsWith("lag ")) {
            const QStringList n = line.mid(4).split(' ');
            st.lag = n.value(0).toInt();
            st.behind = n.value(1, "-1").toInt();
            st.lagPing = n.value(2, "-1").toInt();
        } else if (line == "disconnected")
            st.disconnected = true;
        else if (line.startsWith("statehash "))
            st.stateHash = line.mid(10);
        else if (line.startsWith("heaphash "))
            st.heapHash = line.mid(9);
    }
    emit status(st);
}
