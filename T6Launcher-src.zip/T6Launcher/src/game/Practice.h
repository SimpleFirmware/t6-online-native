#pragma once

#include <QObject>

class QProcess;
struct Settings;

// Practice mode: a separate game process with T6_PRACTICE=1 that goes straight into a fight
// against a standing opponent (characters/stage from the Practice tab).
class Practice : public QObject {
    Q_OBJECT
public:
    Practice(Settings &settings, QObject *parent = nullptr);
    ~Practice() override;

    bool start();
    void stop();
    bool isRunning() const;

signals:
    void runningChanged(bool running);

private:
    Settings &m_settings;
    QProcess *m_process = nullptr;
};
