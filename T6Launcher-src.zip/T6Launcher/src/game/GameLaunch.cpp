#include "game/GameLaunch.h"

#include "core/GameData.h"
#include "core/Log.h"
#include "core/Paths.h"
#include "core/Settings.h"
#include "game/Platform.h"
#include "net/NetUtil.h"

#include <QDir>
#include <QDirIterator>
#include <QFile>
#include <QFileInfo>
#include <QProcess>
#include <QSaveFile>
#include <QSet>

namespace {

// Shader cache files are a header followed by records. Records the package ships are merged
// into the run's cache so the first start compiles fewer shaders.
struct CacheFile {
    const char *name;
    int headerSize;
    int recordSize;   // 0 = variable: 12-byte record header, dword count at +8
};
const CacheFile kCacheFiles[] = {{"4E4D07FC.xsh", 8, 0}, {"4E4D07FC.rov.d3d12.xpso", 12, 0x48}};

QList<QByteArray> splitRecords(const QByteArray &data, int offset, int fixedSize)
{
    QList<QByteArray> out;
    qsizetype pos = offset;
    const int minimum = fixedSize ? fixedSize : 12;
    while (pos + minimum <= data.size()) {
        qsizetype len = fixedSize;
        if (!fixedSize) {
            quint32 words;
            memcpy(&words, data.constData() + pos + 8, 4);
            len = qsizetype(words & 0x7fffffff) * 4 + 12;
            if (pos + len > data.size())
                break;
        }
        out << data.mid(pos, len);
        pos += len;
    }
    return out;
}

void mergeShaderCache(const QString &runDir)
{
    if (qEnvironmentVariableIsSet("T6_NO_SHADER_CACHE"))
        return;
    const QString target = QDir(runDir).filePath("cache/shaders/shareable");
    for (const CacheFile &cf : kCacheFiles) {
        QFile shipped(Paths::file(QStringLiteral("tools/shader_cache/") + cf.name));
        if (!shipped.open(QIODevice::ReadOnly))
            continue;
        const QByteArray pkg = shipped.readAll();
        if (pkg.size() <= cf.headerSize)
            continue;
        const QList<QByteArray> pkgRecords = splitRecords(pkg, cf.headerSize, cf.recordSize);

        QByteArray existing;
        QFile current(QDir(target).filePath(cf.name));
        if (current.open(QIODevice::ReadOnly))
            existing = current.readAll();
        current.close();
        QList<QByteArray> oldRecords;
        if (existing.left(cf.headerSize) == pkg.left(cf.headerSize))
            oldRecords = splitRecords(existing, cf.headerSize, cf.recordSize);

        const QSet<QByteArray> have(oldRecords.begin(), oldRecords.end());
        bool allPresent = true;
        for (const QByteArray &r : pkgRecords)
            if (!have.contains(r)) {
                allPresent = false;
                break;
            }
        if (allPresent)
            continue;

        QDir().mkpath(target);
        QSaveFile out(QDir(target).filePath(cf.name));
        if (!out.open(QIODevice::WriteOnly))
            continue;
        out.write(pkg.left(cf.headerSize));
        const QSet<QByteArray> shippedSet(pkgRecords.begin(), pkgRecords.end());
        for (const QByteArray &r : pkgRecords)
            out.write(r);
        for (const QByteArray &r : oldRecords)
            if (!shippedSet.contains(r))
                out.write(r);
        out.commit();
    }
}

QString onOff(bool b) { return b ? QStringLiteral("true") : QStringLiteral("false"); }

// The original uses "rov" on Windows and "rtv" under Wine. A launcher built for Linux can
// only run the game through Wine, so it always uses "rtv". T6_RENDER_PATH overrides it.
QString renderTargetPath()
{
    const QString forced = qEnvironmentVariable("T6_RENDER_PATH");
    if (!forced.isEmpty())
        return forced;
#ifdef Q_OS_WIN
    return NetUtil::runningUnderWine() ? QStringLiteral("rtv") : QStringLiteral("rov");
#else
    return QStringLiteral("rtv");
#endif
}

}  // namespace

namespace GameLaunch {

bool prepareRunDir(const QString &runDir)
{
    QDir().mkpath(runDir);
    const QString user = QDir(runDir).filePath("user");
    QDir(user).removeRecursively();
    bool ok = QDir().mkpath(user);

    const QString profile = Paths::profileDir();
    QDirIterator it(profile, QDir::Files, QDirIterator::Subdirectories);
    while (it.hasNext()) {
        const QString src = it.next();
        const QString dst = QDir(user).filePath(QDir(profile).relativeFilePath(src));
        QDir().mkpath(QFileInfo(dst).absolutePath());
        ok = QFile::copy(src, dst) && ok;
    }
    mergeShaderCache(runDir);
    return ok;
}

QString keyboardMap()
{
    QStringList parts;
    for (const GameData::KeyAction &a : GameData::keyActions()) {
        const int vk = Settings::intValue(QStringLiteral("kb_") + a.id, a.defaultVk);
        if (vk != 0)
            parts << QStringLiteral("%1:%2").arg(vk, 0, 16).arg(a.mask, 0, 16);
    }
    return parts.join(',');
}

QString padMap()
{
    QStringList parts;
    for (const GameData::PadButton &b : GameData::padButtons()) {
        const int to = Settings::intValue(QStringLiteral("pad_") + b.id, -1);
        if (to >= 0)
            parts << QStringLiteral("%1=%2").arg(QLatin1String(b.id)).arg(to, 0, 16);
    }
    return parts.join(',');
}

QProcessEnvironment environment(const Settings &s, const QString &runDir)
{
    QProcessEnvironment env = QProcessEnvironment::systemEnvironment();
    // Never inherit match parameters from the launcher's own environment.
    for (const char *k : {"T6_NET_PLAYER", "T6_NET_REMOTE", "T6_NET_LOCAL_PORT", "T6_NET_SEED",
                          "T6_CHAR_P1", "T6_CHAR_P2", "T6_STAGE", "T6_ROUNDS"})
        env.remove(k);

    env.insert("T6_NET_STATUS", QDir::toNativeSeparators(QDir(runDir).filePath("status.txt")));
    env.insert("T6_PLAY", QDir::toNativeSeparators(Paths::file("tools/menu_vs.bin")));
    env.insert("T6_FIX_SEED", "1");
    env.insert("T6_VIRTUAL_TB", "1");
    env.insert("REX_GPU_VSYNC", "1");

    // Memory regions left out of the rollback snapshots.
    const QString exclude = Paths::file("tools/netplay_exclude.txt");
    env.insert("T6_SNAP_EXCLUDE_FILE",
               QDir::toNativeSeparators(QFile::exists(exclude) ? exclude
                                                               : Paths::file("runs/exclude_jobpool.txt")));

    const char *internal = s.render3d == 2 ? "640x360" : s.render3d == 1 ? "768x432" : "1024x576";
    env.insert("TEKKEN6_INTERNAL_RESOLUTION", internal);
    env.insert("TEKKEN6_OFFSCREEN_RESOLUTION", s.smallShadows ? "512x512" : "1024x1024");

    env.insert("T6_KEYMAP", keyboardMap());
    env.insert("T6_PAD_MAP", padMap());
    if (!s.blur)
        env.insert("T6_NO_BLUR", "1");
    if (!s.vibration)
        env.insert("T6_NO_VIBRATION", "1");
    if (!s.stageMusic)
        env.insert("T6_NO_MUSIC", "1");
    return env;
}

QStringList arguments(const Settings &s, const QString &runDir)
{
    const QDir run(runDir);
    int adapter = -1;
    if (!s.gpu.isEmpty())
        adapter = int(Platform::graphicsAdapters().indexOf(s.gpu));

    QStringList args = {
        "--game_data_root=" + QDir::toNativeSeparators(Paths::gameDataDir()),
        "--user_data_root=" + QDir::toNativeSeparators(run.filePath("user")),
        "--cache_root=" + QDir::toNativeSeparators(run.filePath("cache")),
        "--log_file=" + QDir::toNativeSeparators(run.filePath("tekken6.log")),
        "--fullscreen=" + onOff(s.fullscreen),
        "--d3d12_allow_variable_refresh_rate_and_tearing=false",
        "--async_shader_compilation=true",
        // Rasterizer-ordered views are faster but missing in Wine's D3D12 translation.
        QStringLiteral("--render_target_path_d3d12=") + renderTargetPath(),
        QStringLiteral("--draw_resolution_scale_x=%1").arg(s.resolutionScale),
        QStringLiteral("--draw_resolution_scale_y=%1").arg(s.resolutionScale),
        QStringLiteral("--d3d12_adapter=%1").arg(adapter),
        "--input_backend=" + s.padBackend,
    };
    // Arcade sticks through the old Windows joystick API need a mapping file. This rebuild
    // doesn't have the capture screen for it; put controls_mmjoystick.ini next to the
    // launcher (the original writes it from Profile -> CONTROLS).
    const QString mmConfig = Paths::file("controls_mmjoystick.ini");
    if (s.padBackend == "mmjoystick" && QFile::exists(mmConfig))
        args << "--mmjoystick_config=" + QDir::toNativeSeparators(mmConfig);
    // Extra game settings for experiments, e.g.
    //   T6_GAME_ARGS="--d3d12_tiled_shared_memory=false"
    // Later values win, so this can also override anything above.
    args << QProcess::splitCommand(qEnvironmentVariable("T6_GAME_ARGS"));
    return args;
}

}
