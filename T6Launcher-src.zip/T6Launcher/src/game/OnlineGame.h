#pragma once

#include <QObject>
#include <QTimer>

class QProcess;
struct Settings;

// What the game writes to status.txt, read ten times a second.
struct GameStatus {
    QString state;        // "loading", "ready" (parked, waiting), "menu", "result", "error ...", ...
    QString round;        // e.g. "2"
    QString winner;       // "0" draw, "1"/"2" player side; set once a fight ended
    int slow = -1;        // % of the fight below 60 FPS
    int lag = -1;         // three numbers from "lag a b c": frames-behind statistics
    int behind = -1;
    int lagPing = -1;
    bool disconnected = false;   // the opponent's game stopped answering
    QString stateHash;           // "statehash ..." while parked: both PCs must match
    QString heapHash;
};

// The game process used for online matches. It is started as soon as the launcher opens and
// "parked" (T6_NET_HOLD=1): it loads, compiles shaders and waits invisibly in a menu, so a
// found match starts in seconds. The launcher then writes
//   start player=<1|2> port=<local udp> remote=<ip>:<port> delay=<n> seed=<n> char1=<id> ...
// into cmd.txt; "park" sends it back to waiting after a match, "quit" ends it.
class OnlineGame : public QObject {
    Q_OBJECT
public:
    OnlineGame(Settings &settings, QObject *parent = nullptr);
    ~OnlineGame() override;

    bool start();                       // launch parked; false if not built / already running
    void kill(const QString &reason);
    void sendCommand(const QString &line);

    bool isRunning() const;
    qint64 pid() const;
    QString runDir() const { return m_runDir; }
    QString logFile() const;

    void showWindow(bool show);

signals:
    void status(const GameStatus &status);
    void finished(int exitCode, bool crashed, const QString &killReason);

private:
    void poll();

    Settings &m_settings;
    QProcess *m_process = nullptr;
    QTimer m_pollTimer;
    QString m_runDir;
    QString m_cmdFile;
    QString m_statusFile;
    QString m_killReason;
    bool m_windowShown = false;
};
