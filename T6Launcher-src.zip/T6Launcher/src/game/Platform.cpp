#include "game/Platform.h"

#include <QApplication>
#include <QDir>
#include <QFileInfo>
#include <QProcess>
#include <QWidget>

#ifdef Q_OS_WIN
#include <windows.h>
#include <dxgi.h>
#include <mmsystem.h>
#include <tlhelp32.h>
#endif

namespace Platform {

#ifdef Q_OS_WIN

void startHidden(QProcess *process)
{
    process->setCreateProcessArgumentsModifier([](QProcess::CreateProcessArguments *args) {
        args->startupInfo->dwFlags |= STARTF_USESHOWWINDOW;
        args->startupInfo->wShowWindow = SW_HIDE;
    });
}

void startWithoutConsole(QProcess *process)
{
    process->setCreateProcessArgumentsModifier([](QProcess::CreateProcessArguments *args) {
        args->flags |= CREATE_NO_WINDOW;
    });
}

void killWithLauncher(qint64 pid)
{
    static HANDLE job = [] {
        HANDLE h = CreateJobObjectW(nullptr, nullptr);
        if (!h)
            return HANDLE(nullptr);
        JOBOBJECT_EXTENDED_LIMIT_INFORMATION info = {};
        info.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
        if (!SetInformationJobObject(h, JobObjectExtendedLimitInformation, &info, sizeof(info))) {
            CloseHandle(h);
            return HANDLE(nullptr);
        }
        return h;
    }();
    if (!job || pid <= 0)
        return;
    HANDLE process = OpenProcess(PROCESS_SET_QUOTA | PROCESS_TERMINATE, FALSE, DWORD(pid));
    if (process) {
        AssignProcessToJobObject(job, process);
        CloseHandle(process);
    }
}

namespace {
struct ShowRequest {
    DWORD pid;
    bool show;
    bool borderless;
};

BOOL CALLBACK showWindowsOfProcess(HWND hwnd, LPARAM param)
{
    const auto *req = reinterpret_cast<const ShowRequest *>(param);
    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    // Only real top-level windows with a title (skip owned windows and helpers).
    if (pid != req->pid || GetWindow(hwnd, GW_OWNER) != nullptr || GetWindowTextLengthW(hwnd) == 0)
        return TRUE;

    if (!req->show) {
        if (IsWindowVisible(hwnd))
            ShowWindow(hwnd, SW_HIDE);
        return TRUE;
    }
    if (IsWindowVisible(hwnd))
        return TRUE;

    if (req->borderless) {
        const LONG_PTR style = GetWindowLongPtrW(hwnd, GWL_STYLE);
        if ((style & (WS_POPUP | WS_CAPTION)) != WS_POPUP) {
            MONITORINFO mi = {sizeof(mi)};
            if (GetMonitorInfoW(MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST), &mi)) {
                SetWindowLongPtrW(hwnd, GWL_STYLE,
                                  (style & ~(WS_CAPTION | WS_THICKFRAME | WS_SYSMENU)) | WS_POPUP);
                const LONG_PTR ex = GetWindowLongPtrW(hwnd, GWL_EXSTYLE);
                SetWindowLongPtrW(hwnd, GWL_EXSTYLE,
                                  ex & ~(WS_EX_DLGMODALFRAME | WS_EX_CLIENTEDGE | WS_EX_STATICEDGE));
                const RECT &r = mi.rcMonitor;
                SetWindowPos(hwnd, nullptr, r.left, r.top, r.right - r.left, r.bottom - r.top,
                             SWP_NOZORDER | SWP_FRAMECHANGED);
            }
        }
    }
    if (qEnvironmentVariableIsSet("T6_LAUNCHER_NOFOCUS")) {
        ShowWindow(hwnd, SW_SHOWNOACTIVATE);
    } else {
        ShowWindow(hwnd, SW_SHOW);
        SetForegroundWindow(hwnd);
    }
    return TRUE;
}
}  // namespace

void showProcessWindows(qint64 pid, bool show, bool borderless)
{
    if (pid <= 0)
        return;
    ShowRequest req{DWORD(pid), show, borderless};
    EnumWindows(showWindowsOfProcess, reinterpret_cast<LPARAM>(&req));
}

int killStaleGameProcesses(const QString &exePath)
{
    const QString wanted = QDir::toNativeSeparators(QFileInfo(exePath).absoluteFilePath()).toLower();
    int ended = 0;
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE)
        return 0;
    PROCESSENTRY32W entry = {sizeof(entry)};
    for (BOOL ok = Process32FirstW(snap, &entry); ok; ok = Process32NextW(snap, &entry)) {
        if (_wcsicmp(entry.szExeFile, L"tekken6.exe") != 0)
            continue;
        HANDLE p = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | PROCESS_TERMINATE, FALSE,
                               entry.th32ProcessID);
        if (!p)
            continue;
        wchar_t path[MAX_PATH * 2];
        DWORD len = DWORD(std::size(path));
        if (QueryFullProcessImageNameW(p, 0, path, &len) &&
            QString::fromWCharArray(path, int(len)).toLower() == wanted) {
            TerminateProcess(p, 1);
            ++ended;
        }
        CloseHandle(p);
    }
    CloseHandle(snap);
    return ended;
}

void bringToFront(QWidget *window)
{
    window->showNormal();
    window->raise();
    const HWND hwnd = HWND(window->winId());
    const HWND fg = GetForegroundWindow();
    const DWORD fgThread = fg ? GetWindowThreadProcessId(fg, nullptr) : 0;
    const DWORD self = GetCurrentThreadId();
    // Windows only lets the foreground thread change focus; borrow its input state briefly.
    if (fgThread && fgThread != self && AttachThreadInput(self, fgThread, TRUE)) {
        SetForegroundWindow(hwnd);
        SetActiveWindow(hwnd);
        AttachThreadInput(self, fgThread, FALSE);
    } else {
        SetForegroundWindow(hwnd);
        SetActiveWindow(hwnd);
    }
    window->activateWindow();
}

void flashTaskbar(QWidget *window)
{
    if (window->isActiveWindow())
        return;
    FLASHWINFO fi = {sizeof(fi)};
    fi.hwnd = HWND(window->winId());
    fi.dwFlags = FLASHW_TRAY | FLASHW_TIMERNOFG;
    FlashWindowEx(&fi);
}

void playSound(const QString &wavFile)
{
    if (wavFile.isEmpty())
        MessageBeep(MB_ICONASTERISK);
    else
        PlaySoundW(reinterpret_cast<LPCWSTR>(wavFile.utf16()), nullptr,
                   SND_FILENAME | SND_ASYNC | SND_NODEFAULT);
}

QStringList graphicsAdapters()
{
    QStringList names;
    IDXGIFactory1 *factory = nullptr;
    if (FAILED(CreateDXGIFactory1(__uuidof(IDXGIFactory1), reinterpret_cast<void **>(&factory))))
        return names;
    IDXGIAdapter1 *adapter = nullptr;
    for (UINT i = 0; factory->EnumAdapters1(i, &adapter) == S_OK; ++i) {
        DXGI_ADAPTER_DESC1 desc;
        if (SUCCEEDED(adapter->GetDesc1(&desc)))
            names << ((desc.Flags & DXGI_ADAPTER_FLAG_SOFTWARE)
                          ? QString()   // keep indexes aligned with what the game sees
                          : QString::fromWCharArray(desc.Description));
        adapter->Release();
    }
    factory->Release();
    return names;
}

#else  // not Windows

void startHidden(QProcess *) {}
void startWithoutConsole(QProcess *) {}
void killWithLauncher(qint64) {}
void showProcessWindows(qint64, bool, bool) {}
int killStaleGameProcesses(const QString &) { return 0; }
void bringToFront(QWidget *window)
{
    window->showNormal();
    window->raise();
    window->activateWindow();
}
void flashTaskbar(QWidget *window) { QApplication::alert(window); }
void playSound(const QString &) { QApplication::beep(); }
QStringList graphicsAdapters() { return {}; }

#endif

}
