#include "game/Practice.h"

#include "core/GameData.h"
#include "core/Log.h"
#include "core/Paths.h"
#include "core/Settings.h"
#include "game/GameLaunch.h"
#include "game/Platform.h"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QProcess>
#include <QRandomGenerator>

Practice::Practice(Settings &settings, QObject *parent) : QObject(parent), m_settings(settings) {}

Practice::~Practice() { stop(); }

bool Practice::isRunning() const { return m_process && m_process->state() != QProcess::NotRunning; }

bool Practice::start()
{
    if (m_process)
        return false;
    const QString exe = Paths::builtGameExe();
    if (!QFile::exists(exe))
        return false;

    const QString runDir = Paths::runDir("practice");
    GameLaunch::prepareRunDir(runDir);

    const Settings &s = m_settings;
    const int me = s.practiceCharacter >= 0 ? s.practiceCharacter : s.character;
    const int opponent = s.practiceOpponent >= 0 ? s.practiceOpponent : me;

    QProcessEnvironment env = GameLaunch::environment(s, runDir);
    for (const char *k : {"T6_NET", "T6_NET_HOLD", "T6_NET_CMD", "T6_SNAP_EXCLUDE_FILE"})
        env.remove(k);
    env.insert("T6_PRACTICE", "1");
    env.insert("T6_PLAY_UNTIL", "1630");   // stop the scripted menu input at the fight
    env.insert("T6_CHAR_P1", QString::number(GameData::gameCharacterId(me, s.costumeFor(me))));
    env.insert("T6_CHAR_P2", QString::number(GameData::gameCharacterId(opponent, 0)));
    const QString look = s.customLookFor(me, s.costumeFor(me));
    if (look.size() == 160)
        env.insert("T6_CUSTOM_P1", look);
    if (s.practiceFrameData)
        env.insert("T6_FRAME_DATA", "1");

    int stage = s.practiceStage;
    if (stage < 0) {
        const auto &stages = GameData::stages();
        stage = stages.at(QRandomGenerator::global()->bounded(int(stages.size()))).gameId;
    }
    env.insert("T6_STAGE", QString::number(stage));
    env.insert("T6_NET_KEYS", QString::number(s.keyboardLayout));

    m_process = new QProcess(this);
    m_process->setProcessEnvironment(env);
    m_process->setProgram(exe);
    m_process->setWorkingDirectory(QFileInfo(exe).absolutePath());
    m_process->setArguments(GameLaunch::arguments(s, runDir));
    connect(m_process, &QProcess::finished, this, [this](int code, QProcess::ExitStatus) {
        Log::info(QStringLiteral("practice finished: code %1").arg(code));
        m_process->deleteLater();
        m_process = nullptr;
        emit runningChanged(false);
    });
    m_process->start();
    if (!m_process->waitForStarted(5000)) {
        Log::info("practice could not be started: " + m_process->errorString());
        m_process->deleteLater();
        m_process = nullptr;
        return false;
    }
    Platform::killWithLauncher(m_process->processId());
    emit runningChanged(true);
    return true;
}

void Practice::stop()
{
    if (!isRunning())
        return;
    Log::info("practice stopped by the launcher");
    m_process->kill();
    m_process->waitForFinished(2000);
}
