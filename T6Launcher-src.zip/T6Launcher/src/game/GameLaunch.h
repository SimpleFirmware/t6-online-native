#pragma once

#include <QProcessEnvironment>
#include <QString>
#include <QStringList>

struct Settings;

// What every game start has in common (online match, practice): the run folder, environment
// variables and command line of native\tekken6.exe.
//
// The game is a recompiled Xbox 360 executable plus the "rex" runtime; it is steered by
// T6_* environment variables and by two small text files in the run folder:
//   cmd.txt     commands from the launcher ("start player=1 port=... ", "park", "quit")
//   status.txt  the game's state, rewritten continuously ("state ready", "round 2", ...)
namespace GameLaunch {

// Creates/cleans runDir and copies the player's save profile into runDir/user and the shared
// shader cache into runDir/cache, so every run starts from the same files on both PCs.
bool prepareRunDir(const QString &runDir);

// Environment shared by online and practice runs.
QProcessEnvironment environment(const Settings &s, const QString &runDir);

// Command line shared by online and practice runs.
QStringList arguments(const Settings &s, const QString &runDir);

// "57:1,53:2,..." - Windows virtual-key code : Xbox button mask, for T6_KEYMAP.
QString keyboardMap();
// "A=3,B=1" - remapped gamepad buttons, for T6_PAD_MAP.
QString padMap();

}
