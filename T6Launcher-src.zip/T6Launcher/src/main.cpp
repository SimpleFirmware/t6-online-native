// Tekken 6 Native Online launcher - readable rebuild.
//
// Start-up order (same as the original):
//   1. "--instance N" picks the settings file and UDP port (for two launchers on one PC);
//   2. only one launcher per instance (lock file);
//   3. tidy up after an update (*.old files, update_tmp);
//   4. load settings, open the window, connect to the lobby server and park the game.

#include "MatchController.h"
#include "core/Log.h"
#include "core/Paths.h"
#include "core/Settings.h"
#include "ui/MainWindow.h"
#include "update/Updater.h"

#include <QApplication>
#include <QDir>
#include <QDirIterator>
#include <QFile>
#include <QLockFile>
#include <QMessageBox>
#include <QStandardPaths>

namespace {

int instanceFromArguments(const QStringList &args)
{
    for (int i = 1; i < args.size(); ++i) {
        if (args[i] == "--instance" && i + 1 < args.size())
            return args[i + 1].toInt();
        if (args[i].startsWith("--instance="))
            return args[i].mid(11).toInt();
    }
    return 1;
}

// After a self-update the replaced launcher was renamed to *.old (a running exe can't be
// deleted on Windows); now it isn't running any more.
void cleanUpAfterUpdate()
{
    const QDir root(Paths::packageRoot());
    QDirIterator it(root.absolutePath(), {"*.old"}, QDir::Files);
    while (it.hasNext())
        QFile::remove(it.next());
    QDir(root.filePath("update_tmp")).removeRecursively();

    QFile result(root.filePath("update_result.txt"));
    if (result.open(QIODevice::ReadOnly | QIODevice::Text)) {
        Log::info("last update: " + QString::fromUtf8(result.readAll()).trimmed());
        result.close();
        result.remove();
    }
}

}  // namespace

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QApplication::setApplicationName("T6Launcher");
    QApplication::setApplicationVersion(Updater::currentVersion());

    Paths::setInstance(instanceFromArguments(QApplication::arguments()));

    // One launcher per instance: two would fight over the game's UDP port and run folder.
    QLockFile lock(QDir(QStandardPaths::writableLocation(QStandardPaths::TempLocation))
                       .filePath(QStringLiteral("t6launcher_%1.lock").arg(Paths::instance())));
    lock.setStaleLockTime(0);
    if (!lock.tryLock(100)) {
        QMessageBox::information(nullptr, "Tekken 6 Online",
                                 QObject::tr("The launcher is already running. Use --instance 2 to "
                                             "start a second one."));
        return 0;
    }

    cleanUpAfterUpdate();

    Settings settings;
    settings.load();
    settings.save();   // writes defaults (client id, region guess) the first time

    MatchController controller(settings);
    MainWindow window(settings, controller);
    window.show();

    Log::info(QStringLiteral("launcher %1, instance %2, package %3")
                  .arg(Updater::currentVersion())
                  .arg(Paths::instance())
                  .arg(QDir::toNativeSeparators(Paths::packageRoot())));
    controller.startup();

    QObject::connect(&app, &QApplication::aboutToQuit, &controller, &MatchController::shutdown);
    return app.exec();
}
