#include "MatchController.h"

#include "core/GameData.h"
#include "core/Identity.h"
#include "core/Log.h"
#include "core/Paths.h"
#include "core/Settings.h"
#include "game/Platform.h"
#include "game/Practice.h"
#include "net/LobbyClient.h"
#include "net/LobbyProbe.h"
#include "net/NetUtil.h"
#include "net/PeerLink.h"
#include "net/Upnp.h"
#include "update/Updater.h"

#include <QCoreApplication>
#include <QRegularExpression>
#include <QTimer>

namespace {

// A saved custom look is 80 bytes as 160 hex characters; only send it if any of the first
// 22 slots is actually set.
bool isValidCustomLook(const QString &hex)
{
    if (hex.size() != 160)
        return false;
    const QByteArray bytes = QByteArray::fromHex(hex.toLatin1());
    if (bytes.size() != 80)
        return false;
    for (int i = 0; i < 44; i += 2) {
        const quint16 slot = quint16((quint8(bytes[i]) << 8) | quint8(bytes[i + 1]));
        if (slot != 0 && slot != 0xFFFF)
            return true;
    }
    return false;
}

QString nameHex(const QJsonObject &player)
{
    return QString::fromLatin1(player.value("name").toString().left(15).toLatin1().toHex());
}

}  // namespace

MatchController::MatchController(Settings &settings, QObject *parent)
    : QObject(parent),
      m_settings(settings),
      m_lobby(new LobbyClient(this)),
      m_peer(new PeerLink(this)),
      m_probe(new LobbyProbe(this)),
      m_game(new OnlineGame(settings, this)),
      m_practice(new Practice(settings, this)),
      m_upnp(new Upnp(this))
{
    connect(m_lobby, &LobbyClient::connected, this, &MatchController::onConnected);
    connect(m_lobby, &LobbyClient::disconnected, this, &MatchController::onDisconnected);
    connect(m_lobby, &LobbyClient::message, this, &MatchController::onServerMessage);

    connect(m_peer, &PeerLink::sendToServer, m_lobby, qOverload<const QJsonObject &>(&LobbyClient::send));
    connect(m_peer, &PeerLink::opponentSeen, this, &MatchController::changed);
    connect(m_peer, &PeerLink::pingReported, this, [this](int ping, bool) {
        statusLine = ping < 0 ? tr("Connected") : tr("Ping %1 ms").arg(ping);
        emit changed();
    });
    connect(m_peer, &PeerLink::failed, this, [this](const QString &why) {
        m_lobby->send("leave");
        statusLine = tr("MATCH DID NOT START");
        infoText = why == "port_in_use" ? tr("The game's UDP port is in use.") : explainUdpBlocked();
        handshaking = false;
        emit changed();
    });
    connect(m_probe, &LobbyProbe::changed, this, &MatchController::changed);

    connect(m_game, &OnlineGame::status, this, &MatchController::onGameStatus);
    connect(m_game, &OnlineGame::finished, this, &MatchController::onGameFinished);
    connect(m_practice, &Practice::runningChanged, this, &MatchController::changed);

    connect(m_upnp, &Upnp::finished, this, [this](bool, const QString &summary) {
        upnpSummary = summary;
        emit changed();
    });

    m_reconnectTimer.setSingleShot(true);
    connect(&m_reconnectTimer, &QTimer::timeout, m_lobby, &LobbyClient::connectToServer);
}

MatchController::~MatchController() = default;

bool MatchController::gameRunning() const { return m_game->isRunning(); }
bool MatchController::practiceRunning() const { return m_practice->isRunning(); }

void MatchController::startup()
{
    m_buildFingerprint = Identity::buildFingerprint();
    m_lobby->connectToServer();
    m_upnp->forward(quint16(m_settings.gamePort));
    if (Platform::killStaleGameProcesses(Paths::builtGameExe()) > 0)
        Log::info("ended game process(es) left by an earlier launcher");
    // Pre-launch ("park") the game so a found match starts within seconds.
    m_game->start();
}

void MatchController::shutdown()
{
    m_shuttingDown = true;
    m_upnp->removeMapping();
    m_game->kill("the launcher closes");
    m_practice->stop();
    m_lobby->disconnectFromServer();
}

void MatchController::restartGame()
{
    if (inMatch)
        return;
    m_deliberateRestart = true;
    if (m_game->isRunning()) {
        m_game->sendCommand("quit");
        m_game->kill("restart of the parked game");
    } else {
        gameFailed = false;
        m_crashCount = 0;
        m_game->start();
    }
}

bool MatchController::sendRaw(const QJsonObject &message)
{
    if (!m_lobby->isConnected())
        return false;
    m_lobby->send(message);
    return true;
}

// ------------------------------------------------------------------------------------------
// Connection and account

void MatchController::onConnected()
{
    Log::info("connected to the lobby server, certificate verified");
    sendHello();
}

void MatchController::sendHello()
{
    const int c = m_settings.character;
    const int costume = m_settings.costumeFor(c);
    m_lobby->send({
        {"t", "hello"},
        {"proto", 2},
        {"private_lobbies", true},
        {"version", Updater::currentVersion()},
        {"client_id", m_settings.clientId},
        {"machine", Identity::machineId()},
        {"char", c},
        {"costume", costume},
        {"custom", m_settings.customLookFor(c, costume)},
        {"side", m_settings.side},
        {"region", m_settings.region},
        {"region_lock", m_settings.regionLock},
        {"strict", m_settings.strictMatchmaking},
        {"build", m_buildFingerprint},
    });
}

void MatchController::onDisconnected()
{
    const bool wasConnected = connected;
    connected = loggedIn = false;
    searching = inLobby = false;
    m_probe->stop();
    if (!inMatch)
        handshaking = false;
    lobbies = {};
    emit changed();
    if (m_shuttingDown)
        return;
    // Reconnect: quickly after losing a working connection, slower when the server is down.
    m_reconnectTimer.start(wasConnected ? 2000 : 5000);
}

void MatchController::login(const QString &name, const QString &password, bool createAccount)
{
    if (!connected) {
        emit message(tr("Account"), tr("Not connected to the server."));
        return;
    }
    m_lobby->send(createAccount ? "register" : "login",
                  {{"name", name.trimmed()}, {"password", password}});
}

void MatchController::playAsGuest()
{
    m_lobby->send("guest", {{"name", m_settings.name}});
}

void MatchController::logout()
{
    m_lobby->send("logout", {{"session", m_settings.session}});
}

void MatchController::onAccount(const QJsonObject &msg)
{
    const bool firstTime = !loggedIn;
    loggedIn = true;
    guest = msg.value("guest").toBool();
    accountName = msg.value("name").toString();
    elo = msg.value("elo").toInt(500);
    games = msg.value("games").toInt();
    wins = msg.value("wins").toInt();
    rank = msg.value("rank").toInt(15);
    rankNames = msg.value("rank_names").toArray();
    onlinePlayers = msg.value("online").toInt(onlinePlayers);
    notice = msg.value("notice").toObject().value("text").toString();
    // "admin" is also sent; the original stores it but never uses it.

    if (msg.contains("session")) {
        m_settings.session = msg.value("session").toString();
        m_settings.accountName = accountName;
        m_settings.save();
    }
    if (firstTime) {
        // Settings kept on the server for accounts (not guests) win over local ones.
        if (!guest) {
            const QJsonObject s = msg.value("settings").toObject();
            if (s.contains("char_index"))
                m_settings.character = s.value("char_index").toInt(m_settings.character);
            if (s.contains("costumes"))
                m_settings.costumes = s.value("costumes").toObject();
            if (s.contains("delay"))
                m_settings.delay = s.value("delay").toInt(m_settings.delay);
            if (s.contains("keys"))
                m_settings.keyboardLayout = s.value("keys").toInt(m_settings.keyboardLayout);
            if (s.contains("max_ping"))
                m_settings.maxPing = s.value("max_ping").toInt(m_settings.maxPing);
            if (s.contains("side"))
                m_settings.side = s.value("side").toInt(m_settings.side);
            if (s.contains("region"))
                m_settings.region = s.value("region").toString(m_settings.region);
            if (s.contains("region_lock"))
                m_settings.regionLock = s.value("region_lock").toBool();
            if (s.contains("strict"))
                m_settings.strictMatchmaking = s.value("strict").toBool();
            m_settings.save();
        }
        const int c = m_settings.character;
        const int costume = m_settings.costumeFor(c);
        m_lobby->send("profile", {{"char", c},
                                  {"costume", costume},
                                  {"custom", m_settings.customLookFor(c, costume)},
                                  {"side", m_settings.side},
                                  {"region", m_settings.region},
                                  {"region_lock", m_settings.regionLock},
                                  {"strict", m_settings.strictMatchmaking}});
    }
    emit changed();
}

void MatchController::sendProfile()
{
    if (!loggedIn)
        return;
    const int c = m_settings.character;
    const int costume = m_settings.costumeFor(c);
    m_lobby->send("profile", {{"char", c},
                              {"costume", costume},
                              {"custom", m_settings.customLookFor(c, costume)},
                              {"side", m_settings.side},
                              {"region", m_settings.region},
                              {"region_lock", m_settings.regionLock},
                              {"strict", m_settings.strictMatchmaking}});
    sendSettings();
}

void MatchController::sendSettings()
{
    if (!loggedIn || guest)
        return;
    m_lobby->send("settings", {{"data", QJsonObject{{"char_index", m_settings.character},
                                                    {"costumes", m_settings.costumes},
                                                    {"delay", m_settings.delay},
                                                    {"keys", m_settings.keyboardLayout},
                                                    {"max_ping", m_settings.maxPing},
                                                    {"side", m_settings.side},
                                                    {"region", m_settings.region},
                                                    {"region_lock", m_settings.regionLock},
                                                    {"strict", m_settings.strictMatchmaking}}}});
}

// ------------------------------------------------------------------------------------------
// Server messages

void MatchController::onServerMessage(const QJsonObject &msg)
{
    emit serverMessage(msg);
    const QString t = msg.value("t").toString();

    if (t == "welcome") {
        connected = true;
        m_wasConnected = true;
        // Log in again with the stored session; otherwise wait for the player.
        if (!m_settings.session.isEmpty())
            m_lobby->send("auth", {{"session", m_settings.session}});
        else if (qEnvironmentVariableIsSet("T6_AUTO_LOGIN"))
            // Test hook: T6_AUTO_LOGIN=name:password (registers the account if it doesn't exist).
            login(qEnvironmentVariable("T6_AUTO_LOGIN").section(':', 0, 0),
                  qEnvironmentVariable("T6_AUTO_LOGIN").section(':', 1), false);
        else if (QCoreApplication::arguments().contains("--auto"))
            playAsGuest();
    } else if (t == "account") {
        onAccount(msg);
    } else if (t == "logged_out") {
        loggedIn = false;
        m_settings.session.clear();
        m_settings.save();
    } else if (t == "rated") {
        onRated(msg);
    } else if (t == "blocked") {
        infoText = tr("%1 is blocked: you will not be matched with them again.")
                       .arg(msg.value("name").toString());
    } else if (t == "blocks") {
        blockList = msg.value("list").toArray();
    } else if (t == "lobbies") {
        lobbies = msg.value("lobbies").toArray();
    } else if (t == "queued") {
        searching = true;
        searchingRanked = msg.value("ranked").toBool();
    } else if (t == "lobby") {
        lobby = msg.value("lobby").toObject();
        inLobby = true;
        searching = false;
        if (lobby.value("guest").toObject().isEmpty()) {
            // Alone in the lobby: nothing to test yet.
            m_probe->stop();
        }
        if (msg.value("quick").toBool())
            sendReady();   // quick match: the server put us in a lobby, ready right away
    } else if (t == "lag_warn") {
        infoText = tr("Ping %1 ms should mean about %2 frames behind, it was %3. %4 lagged.")
                       .arg(msg.value("ping").toInt())
                       .arg(msg.value("expected10").toInt() / 10.0)
                       .arg(msg.value("behind10").toInt() / 10.0)
                       .arg(msg.value("who").toVariant().toStringList().join(", "));
    } else if (t == "slow_end" || t == "set_over") {
        if (t == "set_over" && msg.value("why").toString() == "next_timeout")
            infoText = tr("Nobody pressed Next game in time - the set ended.");
        else if (t == "slow_end")
            infoText = tr("A game ran too slowly for most of the fight - no rematch.");
        setOver = true;
        nextGameSeconds = 0;
        if (qEnvironmentVariableIsSet("T6_AUTO_NEXT"))   // test hook: "Back to menu"
            QTimer::singleShot(500, this, [this] { if (inMatch && setOver) acceptMatch(); });
        inLobby = false;
        handshaking = false;
        m_peer->stop();
        m_probe->stop();
    } else if (t == "left") {
        if (inMatch && msg.value("reason").toString() == "host_left")
            m_opponentGone = true;
        inLobby = false;
        handshaking = false;
        m_peer->stop();
        m_probe->stop();
        searching = false;
    } else if (t == "set") {
        const QJsonArray w = msg.value("wins").toArray();
        infoText = tr("Set %1 - %2  ·  first to %3")
                       .arg(w.at(0).toInt()).arg(w.at(1).toInt()).arg(msg.value("target").toInt(2));
        nextGameSeconds = msg.value("next_seconds").toInt();
        if (nextGameSeconds > 0)
            nextGameClock.start();
        if (qEnvironmentVariableIsSet("T6_AUTO_NEXT"))   // test hook: press "Next game"
            QTimer::singleShot(500, this, [this] { if (inMatch && !setOver) acceptMatch(); });
    } else if (t == "log_saved") {
        infoText = msg.value("ok").toBool() ? tr("Log sent. Thank you!") : tr("The log was not accepted.");
    } else if (t == "history") {
        emit historyReceived(msg.value("name").toString(), msg.value("matches").toArray());
    } else if (t == "leaderboard") {
        leaderboard = msg;
    } else if (t == "confirm") {
        onConfirm(msg);
    } else if (t == "accepted") {
        if (confirmPending && sameMatch(msg))
            opponentAccepted = true;
    } else if (t == "go") {
        onGo(msg);
    } else if (t == "cancel") {
        onCancel(msg);
    } else if (t == "start") {
        onMatchFound(msg);
    } else if (t == "peer") {
        onPeer(msg);
    } else if (t == "probe") {
        if (!inMatch && !handshaking && inLobby)
            m_probe->start(msg, quint16(m_settings.gamePort),
                           NetUtil::resolveIPv4(NetUtil::lobbyServer().host));
    } else if (t == "probe_peer") {
        m_probe->onProbePeer(msg);
    } else if (t == "notice") {
        notice = msg.value("text").toString();
    } else if (t == "online") {
        onlinePlayers = msg.value("n").toInt();
    } else if (t == "error") {
        onError(msg.value("msg").toString(), msg);
    }
    autoPlay();
    emit changed();
}

void MatchController::autoPlay()
{
    static const QString mode = qEnvironmentVariable("T6_AUTO_SEARCH");
    if (mode.isEmpty() || m_autoSearched || !loggedIn || !gameReady || searching || inLobby ||
        inMatch || handshaking)
        return;
    m_autoSearched = true;
    Log::info("auto search (" + mode + ")");
    searchQuick(mode == "ranked");
}

void MatchController::onError(const QString &code, const QJsonObject &msg)
{
    if (code == "bad_login" && qEnvironmentVariableIsSet("T6_AUTO_LOGIN") && !m_autoRegisterTried) {
        m_autoRegisterTried = true;
        login(qEnvironmentVariable("T6_AUTO_LOGIN").section(':', 0, 0),
              qEnvironmentVariable("T6_AUTO_LOGIN").section(':', 1), true);
        return;
    }
    static const QHash<QString, const char *> texts = {
        {"bad_login", "Wrong name or password."},
        {"name_taken", "This name is already taken."},
        {"name_invalid", "This name is not allowed."},
        {"password_short", "The password needs at least 6 characters."},
        {"too_many_attempts", "Too many attempts, try again later."},
        {"insecure", "The connection to the server is not encrypted, login refused."},
        {"guests_off", "The server requires an account."},
        {"session_expired", "The login has expired, log in again."},
        {"logged_in_elsewhere", "The account was logged in somewhere else."},
        {"lobby_not_found", "The lobby does not exist or is full."},
        {"wrong_code", "Wrong code for this private lobby."},
        {"ranked_needs_account", "Ranked needs an account."},
        {"same_network", "No ranked match between two players on the same PC or network."},
        {"state_mismatch", "The two games are not in the same state, the match did not start. Try again."},
        {"protocol", "The launcher is outdated, download the new version."},
        {"char_locked_set", "You can't change your character in the middle of a ranked set."},
    };

    if (code == "login first" || code == "session_expired" || code == "logged_in_elsewhere") {
        if (code == "session_expired") {
            m_settings.session.clear();
            m_settings.save();
        }
        loggedIn = false;
    }
    if (code == "lobby_not_found" || code == "wrong_code")
        requestLobbies(true);

    if (code == "version_mismatch") {
        const QString yours = msg.value("yours").toString(), theirs = msg.value("theirs").toString();
        emit message(tr("Tekken 6 Online"),
                     theirs.isEmpty() || theirs == yours
                         ? tr("You and the opponent have the same launcher version, but your game "
                              "files differ. Both of you: rebuild the game (Profile -> BUILD GAME).")
                         : tr("The opponent has another version of the launcher (%1, you have %2).")
                               .arg(theirs, yours));
        return;
    }
    const auto it = texts.constFind(code);
    emit message(tr("Tekken 6 Online"), it != texts.constEnd() ? tr(it.value()) : code);
}

void MatchController::onRated(const QJsonObject &msg)
{
    const int delta = msg.value("elo_delta").toInt();
    elo = msg.value("elo").toInt(elo);
    QString text = tr("MMR %1%2 (%3)").arg(delta >= 0 ? "+" : "").arg(delta).arg(elo);
    const int quit = msg.value("quit").toInt();
    const int left = msg.value("left").toInt();
    if (quit == 1)
        text = tr("You left the match: double loss") + "   ·   " + text;
    else if (quit == 2)
        text = tr("The opponent left: you win") + "   ·   " + text;
    else if (left == 1)
        text = tr("You left the set: loss") + "   ·   " + text;
    else if (left == 2)
        text = tr("The opponent left the set: you win") + "   ·   " + text;
    else if (msg.value("set").toArray().size() == 2) {
        const QJsonArray set = msg.value("set").toArray();
        text = tr("Set %1 - %2").arg(set.at(0).toInt()).arg(set.at(1).toInt()) + "   ·   " + text;
    }
    infoText = text;
    if (quit == 2 && inMatch && m_game->isRunning()) {
        m_opponentGone = true;
        m_game->kill("the opponent left (server)");
    }
    rank = msg.value("rank").toInt(rank);
}

// ------------------------------------------------------------------------------------------
// Matchmaking

void MatchController::searchQuick(bool ranked)
{
    if (searching)
        return;
    infoText.clear();
    m_lobby->send("quick", ranked ? QJsonObject{{"ranked", true}} : QJsonObject{});
}

void MatchController::cancelSearch()
{
    m_lobby->send("quick_cancel");
    searching = false;
    emit changed();
}

void MatchController::requestLobbies(bool force)
{
    if (!loggedIn)
        return;
    if (!force && m_lobbyListClock.isValid() && m_lobbyListClock.elapsed() < 2000)
        return;
    m_lobbyListClock.start();
    m_lobby->send("list", {{"private", m_settings.showPrivateLobbies}});
}

void MatchController::createLobby(bool isPublic, bool ranked)
{
    m_lobby->send("create", {{"public", isPublic}, {"ranked", ranked}});
}

void MatchController::joinLobby(const QString &id, const QString &code)
{
    QJsonObject o{{"id", id}};
    if (!code.isEmpty())
        o.insert("code", code.trimmed().toUpper());
    m_lobby->send("join", o);
}

void MatchController::joinByCode(const QString &code)
{
    m_lobby->send("join", {{"code", code.trimmed().toUpper()}});
}

void MatchController::setLobbyStage(int stage) { m_lobby->send("stage", {{"stage", stage}}); }

void MatchController::requestLeaderboard(const QString &region)
{
    m_lobby->send("leaderboard", {{"region", region}});
}

void MatchController::requestBlockList() { m_lobby->send("blocks"); }
void MatchController::unblock(int id) { m_lobby->send("unblock", {{"id", id}}); }
void MatchController::requestHistory(const QString &name) { m_lobby->send("history", {{"name", name}}); }
void MatchController::blockOpponent() { m_lobby->send("block"); }

void MatchController::sendReady()
{
    // While the game is parked it reports hashes of its state; the server compares both
    // players' hashes to refuse matches that would desync.
    QString state;
    if (!inMatch && !game.stateHash.isEmpty() && !m_settings.blur && m_settings.render3d == 0 &&
        !m_settings.smallShadows)
        state = game.stateHash + "/" + game.heapHash;
    m_lobby->send("ready", {{"local_ip", NetUtil::localIPv4()},
                            {"local_port", m_settings.gamePort},
                            {"state", state},
                            {"random_stage", false}});
}

void MatchController::onMatchFound(const QJsonObject &msg)
{
    // A match (or the next game of a set) was found.
    if (!match.value("queue").toBool())
        m_practice->stop();
    if (m_settings.matchSoundMode != 0 && (!inMatch || !m_rematchRequested)) {
        Platform::playSound(m_settings.matchSoundMode == 2 ? m_settings.matchSoundFile : QString());
        emit bringToFront();
    }

    // Rematch: send the running game back to its parked state first.
    if (inMatch && m_game->isRunning() && m_rematchRequested && !m_opponentGone) {
        m_game->sendCommand("park");
        m_game->showWindow(false);
        inMatch = false;
        gameReady = false;
        m_startPending = false;
        m_matchStarted = m_windowWanted = m_errorHandled = false;
        m_parkClock.start();
        m_parkWatch = true;
        m_waitForPark = true;
    }
    match = msg;
    m_rematchRequested = false;
    m_goWhileWaiting = false;
    m_reportedPlaying = false;
    m_gameOver = m_resultSent = false;
    confirmPending = accepted = opponentAccepted = false;
    setOver = false;
    infoText.clear();
    searching = false;
    handshaking = true;
    m_probe->stop();
    statusLine = tr("Connecting to the opponent…");

    const NetUtil::ServerAddress server = NetUtil::lobbyServer();
    PeerLink::Options o;
    o.gamePort = quint16(m_settings.gamePort);
    o.role = msg.value("role").toInt();
    o.matchId = msg.value("match_id").toString();
    o.token = msg.value("token").toString();
    o.server = NetUtil::resolveIPv4(server.host);
    o.serverUdpPort = quint16(msg.value("udp_port").toInt(7701));
    o.queue = msg.value("queue").toBool() || lobby.value("queue").toBool();
    o.maxPing = m_settings.maxPing;
    o.wifi = NetUtil::connectedOverWifi(o.server);
    o.underWine = NetUtil::runningUnderWine();
    m_peer->start(o);
    emit changed();
}

void MatchController::onPeer(const QJsonObject &msg)
{
    if (!sameMatch(msg))
        return;
    QVector<QPair<QHostAddress, quint16>> candidates;
    const QJsonArray pub = msg.value("public").toArray();
    const QJsonArray loc = msg.value("local").toArray();
    if (msg.value("same_nat").toBool() && loc.size() == 2)
        candidates.append({QHostAddress(loc.at(0).toString()), quint16(loc.at(1).toInt())});
    if (pub.size() == 2)
        candidates.append({QHostAddress(pub.at(0).toString()), quint16(pub.at(1).toInt())});
    m_peer->setCandidates(candidates);
    statusLine = tr("Punching through…");
}

void MatchController::onConfirm(const QJsonObject &msg)
{
    if (!sameMatch(msg))
        return;
    confirmPending = true;
    accepted = opponentAccepted = false;
    confirmPing = msg.value("ping").toInt();
    confirmMs = qint64(msg.value("seconds").toInt(15)) * 1000;
    confirmClock.start();
    emit bringToFront();
    if (qEnvironmentVariableIsSet("T6_AUTO_ACCEPT"))
        acceptMatch();
}

void MatchController::onGo(const QJsonObject &msg)
{
    confirmPending = false;
    if (!handshaking || !sameMatch(msg))
        return;
    if (msg.contains("ping"))
        confirmPing = msg.value("ping").toInt();
    // After a rematch the game may still be on its way back to the parked state.
    if (!m_waitForPark || gameReady)
        startOnlineMatch();
    else
        m_goWhileWaiting = true;
}

void MatchController::onCancel(const QJsonObject &msg)
{
    if (!sameMatch(msg))
        return;
    m_peer->stop();
    handshaking = false;
    confirmPending = false;
    const QString reason = msg.value("reason").toString();
    const bool mine = msg.value("you").toBool();

    if (reason == "declined" || reason == "timeout") {
        infoText = mine ? (reason == "declined" ? tr("You declined the match.")
                                                : tr("You did not accept the match in time."))
                        : tr("The opponent did not accept – searching again.");
    } else if (reason == "left" && !mine) {
        // The opponent never got through: say why if our own UDP looked blocked.
        if (m_peer->seenPublicPort() < 0 || m_peer->seenPublicPort() != m_settings.gamePort)
            infoText = tr("The last match did not start: %1").arg(explainUdpBlocked());
        else
            infoText = tr("The opponent could not connect or left – searching again.");
    } else {
        infoText = tr("Ping %1 ms is above the limit – the match did not start.")
                       .arg(msg.value("ping").toInt());
    }
    statusLine.clear();
}

QString MatchController::explainUdpBlocked() const
{
    QString text = tr("Your PC or router blocks the game's UDP traffic: allow the launcher and "
                      "native\\tekken6.exe in the firewall.");
    if (!upnpSummary.contains("forwarded"))
        text += tr(" Turning on UPnP in your router lets the launcher open the game's port by itself.");
    return text;
}

bool MatchController::sameMatch(const QJsonObject &msg) const
{
    return msg.value("match_id").toString() == matchId();
}

void MatchController::acceptMatch()
{
    if (confirmPending) {
        if (!accepted) {
            accepted = true;
            m_lobby->send("accept", {{"match_id", matchId()}, {"yes", true}});
        }
    } else if (!inMatch) {
        if (inLobby)
            sendReady();
    } else if (setOver) {
        leaveToMenu();
    } else if (!m_game->isRunning() || m_opponentGone) {
        // The game is gone (opponent disconnected): restart it, then ready again.
        m_readyAfterRestart = true;
        m_game->sendCommand("quit");
        m_game->kill("rematch after a disconnect");
    } else {
        m_rematchRequested = true;   // "Next game" in a set
        sendReady();
    }
    emit changed();
}

void MatchController::declineOrLeave()
{
    if (confirmPending) {
        if (!accepted)
            m_lobby->send("accept", {{"match_id", matchId()}, {"yes", false}});
        return;
    }
    if (!inMatch) {
        m_lobby->send("leave");
        inLobby = false;
        searching = false;
        m_peer->stop();
        m_probe->stop();
        handshaking = false;
    } else if (!m_game->isRunning() || !m_gameOver) {
        // Leaving during a fight: end the game (counts as a loss on the server).
        m_game->sendCommand("quit");
        m_game->kill("leaving the match");
    } else {
        leaveToMenu();
    }
    emit changed();
}

void MatchController::leaveToMenu()
{
    m_game->sendCommand("park");
    m_game->showWindow(false);
    resetMatchFlags();
    inLobby = false;
    lobby = {};
    m_parkClock.start();
    m_parkWatch = true;
    m_lobby->send("leave");
}

void MatchController::resetMatchFlags()
{
    inMatch = false;
    gameReady = false;
    setOver = false;
    handshaking = false;
    confirmPending = accepted = opponentAccepted = false;
    m_startPending = m_matchStarted = m_windowWanted = m_errorHandled = false;
    m_resultSent = m_gameOver = m_rematchRequested = m_opponentGone = false;
    nextGameSeconds = 0;
}

// ------------------------------------------------------------------------------------------
// Starting the match in the game

void MatchController::startOnlineMatch()
{
    m_practice->stop();
    handshaking = false;
    const QHostAddress remote = m_peer->opponentAddress();
    const quint16 remotePort = m_peer->opponentPort();
    m_peer->stop();   // free the UDP port for the game

    const QJsonObject p1 = match.value("p1").toObject();
    const QJsonObject p2 = match.value("p2").toObject();
    const int char1 = GameData::gameCharacterId(p1.value("char").toInt(), p1.value("costume").toInt());
    const int char2 = GameData::gameCharacterId(p2.value("char").toInt(), p2.value("costume").toInt());

    // Ranked matches always use at least 1 frame of delay.
    int delay = m_settings.delay;
    if (match.value("ranked").toBool())
        delay = qMax(1, delay);

    QString cmd = QStringLiteral("start player=%1 port=%2 remote=%3:%4 delay=%5 seed=%6 char1=%7 char2=%8 rounds=%9")
                      .arg(match.value("role").toInt())
                      .arg(m_settings.gamePort)
                      .arg(remote.toString())
                      .arg(remotePort)
                      .arg(delay)
                      .arg(match.value("seed").toInt())
                      .arg(char1)
                      .arg(char2)
                      .arg(qEnvironmentVariable("T6_ROUNDS", "3"));
    cmd += QStringLiteral(" input=%1 keys=%2")
               .arg(qEnvironmentVariable("T6_NET_INPUT", "live"))
               .arg(m_settings.keyboardLayout);
    // Names are passed hex-encoded (Latin-1, max 15 chars) so spaces can't break the line.
    cmd += QStringLiteral(" name1=%1 name2=%2").arg(nameHex(p1), nameHex(p2));
    cmd += QStringLiteral(" rank1=%1 rank2=%2").arg(p1.value("rank").toInt()).arg(p2.value("rank").toInt());
    if (match.contains("promo"))
        cmd += QStringLiteral(" promo=%1").arg(match.value("promo").toInt());
    if (match.value("stage").toInt(-1) >= 0)
        cmd += QStringLiteral(" stage=%1").arg(match.value("stage").toInt());
    const QString custom1 = p1.value("custom").toString(), custom2 = p2.value("custom").toString();
    if (isValidCustomLook(custom1))
        cmd += " custom1=" + custom1;
    if (isValidCustomLook(custom2))
        cmd += " custom2=" + custom2;
    if (qEnvironmentVariableIsSet("T6_ROUND_TIME"))
        cmd += " time=" + qEnvironmentVariable("T6_ROUND_TIME");

    m_startCommand = cmd;
    m_startError.clear();
    inMatch = true;
    m_matchStarted = m_windowWanted = m_errorHandled = false;
    m_startPending = !gameReady;
    if (m_startPending) {
        statusLine = tr("Preparing the game…");
        if (!m_game->isRunning())
            m_game->start();
    } else {
        sendStartCommand();
        statusLine = tr("Match found – loading…");
    }
    emit changed();
}

void MatchController::sendStartCommand()
{
    m_startPending = false;
    m_startRetries = 1;
    m_startClock.start();
    m_game->sendCommand(m_startCommand);
}

void MatchController::onGameStatus(const GameStatus &st)
{
    game = st;

    if (!inMatch) {
        if (st.state == "ready" && !gameReady) {
            gameReady = true;
            m_parkWatch = false;
            m_crashCount = 0;
            if (m_waitForPark) {
                m_waitForPark = false;
                if (m_goWhileWaiting && handshaking) {
                    m_goWhileWaiting = false;
                    startOnlineMatch();
                }
            } else if (m_readyAfterRestart) {
                m_readyAfterRestart = false;
                sendReady();
            }
            autoPlay();
            emit changed();
        } else if (m_parkWatch && m_parkClock.elapsed() > 30000 && m_game->isRunning()) {
            m_parkWatch = false;
            m_game->kill("park took over 30 s");
        }
        if (!qEnvironmentVariableIsSet("T6_LAUNCHER_SHOW_GAME"))
            m_game->showWindow(false);
        return;
    }

    if (m_startPending) {
        if (st.state == "ready") {
            gameReady = true;
            sendStartCommand();
        }
        return;
    }

    if (st.state.startsWith("error") && !m_errorHandled) {
        m_errorHandled = true;
        const QString err = st.state.mid(6);
        m_startError = err.startsWith("no connection to the opponent")
                           ? tr("No connection to the opponent's game (their firewall or router blocks it).")
                           : QString(err).replace(QRegularExpression("\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?"), "").simplified();
        m_game->kill("start failed: game error");
        return;
    }

    if (!m_matchStarted) {
        if (st.state.isEmpty() || st.state == "ready") {
            // The game may have missed the command: repeat it every few seconds.
            if (m_startClock.elapsed() > m_startRetries * 3000) {
                ++m_startRetries;
                m_game->sendCommand(m_startCommand);
            }
        } else if (st.state != "loading") {
            m_matchStarted = true;
            m_windowWanted = true;
            if (!m_reportedPlaying) {
                m_reportedPlaying = true;
                m_lobby->send("playing", {{"match_id", matchId()}});
            }
        }
        if (!m_matchStarted && m_startClock.elapsed() > 90000 && m_game->isRunning()) {
            m_errorHandled = true;
            m_game->kill("start took over 90 s");
            return;
        }
    }

    // Hide the game again on the result screen / menu and show the launcher (Next game...).
    if (m_matchStarted && m_windowWanted &&
        (st.state == "menu" || (!st.winner.isEmpty() && st.state == "result"))) {
        m_windowWanted = false;
        m_game->showWindow(false);
        emit bringToFront();
    }
    m_game->showWindow(m_windowWanted);

    QString line = m_matchStarted ? st.state : tr("Match found – loading…");
    if (match.value("state_warning").toBool())
        line = tr("⚠ Different game state – a desync is possible  ·  ") + line;
    if (m_matchStarted && !st.winner.isEmpty()) {
        const QString winnerName = match.value(st.winner == "1" ? "p1" : "p2").toObject().value("name").toString();
        line = st.winner == "0" ? tr("Draw") : tr("Winner: %1").arg(winnerName);
    }
    if (!st.round.isEmpty())
        line += tr("  ·  rounds ") + st.round;
    if (confirmPing > 0)
        line += tr("  ·  ping %1 ms").arg(confirmPing);
    if (st.disconnected)
        line += tr("  ·  the opponent disconnected");
    statusLine = line;
    m_opponentGone = st.disconnected;

    if (st.disconnected) {
        if (st.winner.isEmpty() && m_game->isRunning()) {
            m_opponentGone = true;
            m_game->kill("the opponent left (server)");
        }
    } else if (st.state == "result" || !st.winner.isEmpty()) {
        if (!m_resultSent && !st.winner.isEmpty()) {
            m_resultSent = true;
            m_lobby->send("result", {{"match_id", matchId()},
                                     {"winner", st.winner.toInt()},
                                     {"slow", st.slow},
                                     {"lag", st.lag},
                                     {"behind", st.behind},
                                     {"ping", st.lagPing}});
        }
        m_gameOver = true;
    }
    emit changed();
}

void MatchController::onGameFinished(int exitCode, bool crashed, const QString &killReason)
{
    const bool wasInMatch = inMatch;
    const bool killedByUs = !killReason.isEmpty();

    // The game ended during a fight we were really playing: tell the server it's lost.
    if (wasInMatch && m_reportedPlaying && !m_gameOver && !m_opponentGone && !killedByUs)
        m_lobby->send("forfeit", {{"match_id", matchId()}});

    const bool opponentGone = m_opponentGone;
    const bool readyAfter = m_readyAfterRestart;
    const QString startError = m_startError;
    resetMatchFlags();
    m_game->showWindow(false);

    if (m_shuttingDown)
        return;

    if (wasInMatch) {
        if (!readyAfter) {
            m_lobby->send("leave");
            inLobby = false;
            if (opponentGone) {
                statusLine = tr("OPPONENT DISCONNECTED");
                infoText = tr("The opponent left the match or lost the connection.");
            } else if (!startError.isEmpty()) {
                statusLine = tr("MATCH DID NOT START");
                infoText = startError;
            } else if (!m_matchStarted && killReason.startsWith("start")) {
                statusLine = tr("MATCH DID NOT START");
                infoText = tr("The game did not get into the match, log: %1").arg(m_game->logFile());
            } else {
                statusLine = tr("GAME ENDED");
                infoText = exitCode ? tr("Code %1, log: %2").arg(exitCode).arg(m_game->logFile()) : QString();
            }
        }
    } else if (!m_deliberateRestart && crashed) {
        // Don't loop forever on a game that can't start.
        if (++m_crashCount > 1) {
            gameFailed = true;
            infoText = tr("The game failed to start. See %1").arg(m_game->logFile());
            emit changed();
            return;
        }
    }
    m_deliberateRestart = false;
    m_game->start();   // park a fresh game for the next match
    emit changed();
}

// ------------------------------------------------------------------------------------------
// Practice

bool MatchController::startPractice()
{
    if (inMatch || handshaking)
        return false;
    return m_practice->start();
}

void MatchController::stopPractice() { m_practice->stop(); }
