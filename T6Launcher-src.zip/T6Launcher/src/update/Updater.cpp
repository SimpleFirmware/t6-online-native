#include "update/Updater.h"

#include "core/Log.h"
#include "core/Paths.h"

#include <QCoreApplication>
#include <QCryptographicHash>
#include <QDir>
#include <QDirIterator>
#include <QFile>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QProcess>

#include <algorithm>

namespace {

const char *const kReleasesApi =
    "https://api.github.com/repos/Ekspym/Tekken6-native-online/releases/latest";
const char *const kAssetName = "tekken6_native_online_patch.zip";

QNetworkRequest githubRequest(const QUrl &url, const char *accept)
{
    QNetworkRequest req(url);
    req.setHeader(QNetworkRequest::UserAgentHeader, "Tekken6NativeOnlineLauncher");
    req.setRawHeader("Accept", accept);
    req.setAttribute(QNetworkRequest::RedirectPolicyAttribute, QNetworkRequest::NoLessSafeRedirectPolicy);
    return req;
}

QList<int> versionNumbers(QString tag)
{
    if (tag.startsWith('v') || tag.startsWith('V'))
        tag = tag.mid(1);
    tag = tag.section('-', 0, 0);
    QList<int> out;
    for (const QString &part : tag.split('.'))
        out << part.toInt();
    return out;
}

}  // namespace

Updater::Updater(QObject *parent) : QObject(parent), m_http(new QNetworkAccessManager(this)) {}

QString Updater::currentVersion()
{
    const QString overridden = qEnvironmentVariable("T6_VERSION_OVERRIDE");
    return overridden.isEmpty() ? QStringLiteral(T6_LAUNCHER_VERSION) : overridden;
}

bool Updater::isNewer(const QString &tag, const QString &than)
{
    const QList<int> a = versionNumbers(tag), b = versionNumbers(than);
    for (int i = 0; i < qMax(a.size(), b.size()); ++i) {
        const int x = a.value(i), y = b.value(i);
        if (x != y)
            return x > y;
    }
    return false;
}

void Updater::check()
{
    const QString api = qEnvironmentVariable("T6_UPDATE_API", QString::fromLatin1(kReleasesApi));
    QNetworkReply *reply = m_http->get(githubRequest(QUrl(api), "application/vnd.github+json"));
    connect(reply, &QNetworkReply::finished, this, [this, reply] {
        reply->deleteLater();
        m_downloadUrl.clear();
        m_sha256.clear();
        if (reply->error() != QNetworkReply::NoError) {
            emit failed("Could not check for updates: " + reply->errorString());
            return;
        }
        const QJsonObject release = QJsonDocument::fromJson(reply->readAll()).object();
        m_latest = release.value("tag_name").toString();
        const QString notes = release.value("body").toString();
        if (release.value("draft").toBool() || !isNewer(m_latest, currentVersion())) {
            emit checked(false, m_latest, notes);
            return;
        }
        for (const QJsonValue &v : release.value("assets").toArray()) {
            const QJsonObject asset = v.toObject();
            if (asset.value("name").toString() != QLatin1String(kAssetName))
                continue;
            m_downloadUrl = QUrl(asset.value("browser_download_url").toString());
            const QString digest = asset.value("digest").toString();
            if (digest.startsWith("sha256:"))
                m_sha256 = digest.mid(7).toLatin1().toLower();
        }
        if (m_sha256.isEmpty())
            m_downloadUrl.clear();   // never install something we can't verify
        emit checked(updateAvailable(), m_latest, notes);
    });
}

void Updater::downloadAndInstall()
{
    if (!updateAvailable())
        return;
    QNetworkReply *reply = m_http->get(githubRequest(m_downloadUrl, "application/octet-stream"));
    connect(reply, &QNetworkReply::downloadProgress, this, [this](qint64 got, qint64 total) {
        if (total > 0)
            emit progress(int(got * 100 / total));
    });
    connect(reply, &QNetworkReply::finished, this, [this, reply] {
        reply->deleteLater();
        if (reply->error() != QNetworkReply::NoError) {
            emit failed("The download failed: " + reply->errorString());
            return;
        }
        const QByteArray zip = reply->readAll();
        const QByteArray actual = QCryptographicHash::hash(zip, QCryptographicHash::Sha256).toHex();
        if (actual != m_sha256) {
            emit failed("The downloaded file is damaged (checksum mismatch).");
            return;
        }
        if (install(zip))
            emit installed(m_latest);
    });
}

bool Updater::install(const QByteArray &zip)
{
    const QDir root(Paths::packageRoot());
    const QString tmp = root.filePath("update_tmp");
    QDir(tmp).removeRecursively();
    const QString filesDir = QDir(tmp).filePath("files");
    if (!QDir().mkpath(filesDir)) {
        emit failed("Cannot write into the launcher's folder.");
        return false;
    }
    QFile zipFile(QDir(tmp).filePath("patch.zip"));
    if (!zipFile.open(QIODevice::WriteOnly) || zipFile.write(zip) != zip.size()) {
        emit failed("Cannot write into the launcher's folder.");
        return false;
    }
    zipFile.close();

    // Windows 10+ ships bsdtar, which unpacks .zip files.
    const QString tar = QDir(qEnvironmentVariable("SystemRoot", "C:/Windows")).filePath("System32/tar.exe");
    const QString tarProgram = QFile::exists(tar) ? tar : QStringLiteral("tar");
    if (QProcess::execute(tarProgram, {"-xf", zipFile.fileName(), "-C", filesDir}) != 0) {
        emit failed("Extracting the update failed.");
        return false;
    }

    const QString self = QFileInfo(QCoreApplication::applicationFilePath()).canonicalFilePath();
    const QStringList keep = {"game/", "native/", "runs/", "user/", "user2/", "update_tmp/"};
    QDirIterator it(filesDir, QDir::Files, QDirIterator::Subdirectories);
    while (it.hasNext()) {
        const QString src = it.next();
        const QString rel = QDir::fromNativeSeparators(QDir(filesDir).relativeFilePath(src));
        const QString lower = rel.toLower();
        if (std::any_of(keep.begin(), keep.end(), [&](const QString &k) { return lower.startsWith(k); }) ||
            (lower.startsWith("launcher_native") && lower.endsWith(".ini")))
            continue;

        const QString dst = root.filePath(rel);
        QDir().mkpath(QFileInfo(dst).absolutePath());
        if (QFileInfo(dst).canonicalFilePath() == self) {
            // A running exe can't be overwritten but can be renamed.
            QFile::remove(dst + ".old");
            if (!QFile::rename(dst, dst + ".old")) {
                emit failed("Cannot replace the launcher.");
                return false;
            }
        } else if (QFile::exists(dst) && !QFile::remove(dst)) {
            emit failed(QStringLiteral("%1 is in use - close the game and try again.").arg(rel));
            return false;
        }
        if (!QFile::copy(src, dst)) {
            emit failed(QStringLiteral("Copying %1 failed.").arg(rel));
            return false;
        }
    }
    QDir(tmp).removeRecursively();

    QFile result(root.filePath("update_result.txt"));
    if (result.open(QIODevice::WriteOnly | QIODevice::Text))
        result.write(("ok " + m_latest).toUtf8());
    Log::info("updated to " + m_latest);
    return true;
}
