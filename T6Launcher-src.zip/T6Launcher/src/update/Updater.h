#pragma once

#include <QObject>
#include <QUrl>

class QNetworkAccessManager;

// Looks for a newer release of the original project on GitHub and installs its patch zip.
//
// Check:    GET api.github.com/repos/Ekspym/Tekken6-native-online/releases/latest, find the asset
//           "tekken6_native_online_patch.zip", its download URL and the "sha256:..." digest that
//           GitHub computes for every uploaded asset.
// Install:  download, verify SHA-256 against that digest (refuse on mismatch), unpack with
//           Windows' own tar.exe into update_tmp\files, copy over the package - never touching
//           game\, native\, runs\, user\, user2\ or the settings - then restart.
//
// Note: a new release usually means the server expects a new launcher version in "hello";
// this rebuild still reports T6_LAUNCHER_VERSION until you change it (or set
// T6_VERSION_OVERRIDE).
class Updater : public QObject {
    Q_OBJECT
public:
    explicit Updater(QObject *parent = nullptr);

    void check();
    void downloadAndInstall();

    QString latestVersion() const { return m_latest; }
    bool updateAvailable() const { return !m_downloadUrl.isEmpty(); }

    static QString currentVersion();
    // "v2.2.10-test1" -> 2.2.10 > 2.2.6 ?
    static bool isNewer(const QString &tag, const QString &than);

signals:
    void checked(bool available, const QString &version, const QString &notes);
    void progress(int percent);
    void failed(const QString &message);
    void installed(const QString &version);   // the launcher should restart now

private:
    bool install(const QByteArray &zip);

    QNetworkAccessManager *m_http;
    QString m_latest;
    QUrl m_downloadUrl;
    QByteArray m_sha256;   // expected digest, lowercase hex
};
