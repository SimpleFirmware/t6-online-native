#pragma once

#include "game/OnlineGame.h"

#include <QElapsedTimer>
#include <QJsonArray>
#include <QJsonObject>
#include <QObject>
#include <QTimer>

class LobbyClient;
class LobbyProbe;
class PeerLink;
class Practice;
class Upnp;
struct Settings;

// The launcher's brain: reacts to lobby-server messages, runs the UDP handshake with the
// opponent and drives the parked game process through a match. Everything the window shows
// is read from the public fields below; changed() is emitted whenever one of them changes.
//
// The happy path of a match:
//   client                          server
//   {"t":"quick","ranked":true} -->
//                               <-- {"t":"queued"}
//                               <-- {"t":"start", match_id, role, token, p1, p2, seed, ...}
//   UDP punch / hi / pp (PeerLink)
//                               <-- {"t":"peer", public:[ip,port], local:[ip,port]}
//   {"t":"ping_report",...}     -->
//                               <-- {"t":"confirm", match_id, ping, seconds}
//   {"t":"accept","yes":true}   -->
//                               <-- {"t":"accepted"}  /  {"t":"go"}
//   cmd.txt: "start player=1 port=7002 remote=1.2.3.4:7002 delay=1 seed=... char1=.. char2=.."
//   {"t":"playing"}             -->   (once the game left the loading screen)
//   {"t":"result","winner":1,...} -->
//                               <-- {"t":"rated", elo, elo_delta, ...}  /  "set"  /  "set_over"
class MatchController : public QObject {
    Q_OBJECT
public:
    MatchController(Settings &settings, QObject *parent = nullptr);
    ~MatchController() override;

    void startup();      // connect, pre-launch the game, UPnP
    void shutdown();     // remove port mapping, stop the game

    // --- account ---
    void login(const QString &name, const QString &password, bool createAccount);
    void playAsGuest();
    void logout();

    // --- matchmaking ---
    void searchQuick(bool ranked);
    void cancelSearch();
    void acceptMatch();          // Accept / Ready / Next game, depending on the situation
    void declineOrLeave();       // Decline / Leave
    void blockOpponent();

    // --- lobbies ---
    void requestLobbies(bool force = false);
    void createLobby(bool isPublic, bool ranked);
    void joinLobby(const QString &id, const QString &code = {});
    void joinByCode(const QString &code);
    void setLobbyStage(int stage);     // -1 random

    // --- other requests ---
    void requestLeaderboard(const QString &region);
    void requestBlockList();
    void unblock(int id);
    void requestHistory(const QString &name);
    void sendProfile();          // character, costume, region...: call after changing them
    void sendSettings();

    // --- practice ---
    bool startPractice();
    void stopPractice();
    bool practiceRunning() const;

    // Restart the parked game, e.g. after changing graphics settings.
    void restartGame();

    bool sendRaw(const QJsonObject &message);   // for experiments from the Log tab

    // ---- state shown in the window ----
    bool connected = false;
    bool loggedIn = false;
    bool guest = false;
    QString accountName;
    int elo = 500, games = 0, wins = 0, rank = 15;
    QJsonArray rankNames;
    int onlinePlayers = 0;
    QString notice;                 // server notice banner

    bool searching = false;
    bool searchingRanked = false;
    bool inLobby = false;
    QJsonObject lobby;              // current lobby: host, guest, code, ranked, public, stage...
    QJsonArray lobbies;             // lobby list
    QJsonObject leaderboard;        // last "leaderboard" message
    QJsonArray blockList;

    bool handshaking = false;       // UDP handshake with the opponent running
    QJsonObject match;              // last "start" message
    bool confirmPending = false;    // "confirm" received, waiting for Accept
    bool accepted = false;
    bool opponentAccepted = false;
    int confirmPing = 0;
    QElapsedTimer confirmClock;
    qint64 confirmMs = 0;

    bool inMatch = false;
    bool setOver = false;
    int nextGameSeconds = 0;
    QElapsedTimer nextGameClock;
    GameStatus game;                // last status.txt contents
    bool gameRunning() const;
    bool gameReady = false;         // parked game says "state ready"
    bool gameFailed = false;        // crashed repeatedly, not restarted

    QString statusLine;             // one-line status ("Searching…", "Ping 23 ms", ...)
    QString infoText;               // last result / explanation
    QString upnpSummary;

signals:
    void changed();
    void message(const QString &title, const QString &text);   // show as a dialog
    void serverMessage(const QJsonObject &message);            // raw, for the Log tab
    void historyReceived(const QString &name, const QJsonArray &matches);
    void bringToFront();

private:
    void onConnected();
    void onDisconnected();
    void onServerMessage(const QJsonObject &msg);
    void onError(const QString &code, const QJsonObject &msg);
    void onAccount(const QJsonObject &msg);
    void onMatchFound(const QJsonObject &msg);
    void onPeer(const QJsonObject &msg);
    void onConfirm(const QJsonObject &msg);
    void onGo(const QJsonObject &msg);
    void onCancel(const QJsonObject &msg);
    void onRated(const QJsonObject &msg);
    void sendHello();
    void sendReady();
    void startOnlineMatch();
    void sendStartCommand();
    void onGameStatus(const GameStatus &st);
    void onGameFinished(int exitCode, bool crashed, const QString &killReason);
    void leaveToMenu();          // park the game and leave lobby/queue
    void resetMatchFlags();
    bool sameMatch(const QJsonObject &msg) const;
    QString matchId() const { return match.value("match_id").toString(); }
    QString explainUdpBlocked() const;
    void autoPlay();             // T6_AUTO_SEARCH: start searching once logged in and ready

    Settings &m_settings;
    LobbyClient *m_lobby;
    PeerLink *m_peer;
    LobbyProbe *m_probe;
    OnlineGame *m_game;
    Practice *m_practice;
    Upnp *m_upnp;
    QTimer m_reconnectTimer;
    QElapsedTimer m_lobbyListClock;
    QString m_buildFingerprint;
    bool m_shuttingDown = false;
    bool m_wasConnected = false;
    bool m_autoSearched = false;
    bool m_autoRegisterTried = false;

    // Match-in-progress details (field names of the original in comments).
    bool m_startPending = false;      // 6cf: start command waits until the game is ready
    bool m_waitForPark = false;       // 432: rematch - wait for the game to be parked again
    bool m_goWhileWaiting = false;    // 431: "go" arrived while waiting
    bool m_matchStarted = false;      // 6d0: the game left the loading screen
    bool m_windowWanted = false;      // 6d7
    bool m_errorHandled = false;      // 6d1
    bool m_resultSent = false;        // 6c8
    bool m_gameOver = false;          // 6cc / 6c7: a result is known
    bool m_rematchRequested = false;  // 6d4
    bool m_opponentGone = false;      // 6d6
    bool m_reportedPlaying = false;   // 193
    bool m_readyAfterRestart = false; // 6cb
    bool m_deliberateRestart = false; // 2e8
    int m_crashCount = 0;
    int m_startRetries = 1;
    QElapsedTimer m_startClock;
    QElapsedTimer m_parkClock;
    bool m_parkWatch = false;
    QString m_startCommand;
    QString m_startError;
};
