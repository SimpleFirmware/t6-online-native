#include "core/GameData.h"

#include <QTimeZone>
#include <algorithm>

namespace GameData {

namespace {

const char *const kNames[kCharacterCount] = {
    "PAUL", "LAW", "LEI", "KING", "YOSHIMITSU", "NINA", "HWOARANG", "XIAOYU", "CHRISTIE",
    "JIN", "JULIA", "KUMA", "PANDA", "BRYAN", "HEIHACHI", "KAZUYA", "LEE", "STEVE", "MARDUK",
    "MOKUJIN", "JACK-6", "ROGER Jr.", "ANNA", "WANG", "GANRYU", "ASUKA", "BRUCE", "BAEK",
    "DEVIL JIN", "RAVEN", "FENG", "ARMOR KING", "LILI", "DRAGUNOV", "EDDY", "BOB", "ZAFINA",
    "MIGUEL", "LEO", "AZAZEL", "NANCY-M1847J", "LARS", "ALISA"};

// Game ID of the *second* costume of each character; the first costume is this minus one.
// (Table at 0x14006c8f0 in the original.)
const int kSecondCostumeId[kCharacterCount] = {
    1, 3, 5, 7, 9, 11, 13, 15, 17, 21, 23, 24, 25, 27, 29, 31, 33, 35, 37, 39, 41, 43,
    45, 47, 49, 51, 53, 55, 57, 59, 61, 63, 65, 67, 19, 71, 73, 75, 77, 69, 83, 79, 81};

// Game ID of the third costume, 0 = the character has none. (Jump table in the original.)
const int kThirdCostumeId[kCharacterCount] = {
    0, 0, 0, 97, 94, 0, 0, 100, 0, 86, 0, 0, 0, 98, 0, 87, 0, 0, 99, 0, 0, 88,
    89, 0, 0, 90, 0, 95, 0, 0, 0, 96, 91, 0, 0, 0, 92, 0, 0, 0, 0, 93, 0};

}  // namespace

QString characterName(int index)
{
    if (index < 0 || index >= kCharacterCount)
        return QStringLiteral("?");
    return QString::fromLatin1(kNames[index]);
}

QVector<int> charactersByName()
{
    QVector<int> order(kCharacterCount);
    for (int i = 0; i < kCharacterCount; ++i)
        order[i] = i;
    std::sort(order.begin(), order.end(), [](int a, int b) {
        return QString::compare(characterName(a), characterName(b)) < 0;
    });
    return order;
}

bool hasThirdCostume(int index)
{
    return index >= 0 && index < kCharacterCount && kThirdCostumeId[index] != 0;
}

int gameCharacterId(int index, int costume)
{
    if (index < 0 || index >= kCharacterCount)
        return 33;  // what the original falls back to
    if (costume == 2 && hasThirdCostume(index))
        return kThirdCostumeId[index];
    const bool oneCostumeOnly = index == kKuma || index == kPanda;
    if (oneCostumeOnly || costume != 0)
        return kSecondCostumeId[index];
    return kSecondCostumeId[index] - 1;
}

const QVector<Stage> &stages()
{
    static const QVector<Stage> list = {
        {19, "Anger of the Earth"}, {13, "Azazel's Chamber"},  {3, "Cemetery"},
        {4, "City After Dark"},     {18, "Electric Fountain"}, {9, "Fallen Colony"},
        {5, "Fiesta Del Tomate"},   {11, "Gargoyle's Perch"},  {20, "Hidden Retreat"},
        {1, "High Roller's Club"},  {16, "Lightning Storm"},   {7, "Manji Valley"},
        {0, "Mystical Forest"},     {8, "Noh Theater"},        {6, "Rustic Asia"},
        {2, "Temple Grounds"},      {17, "Tunnel Disaster"},   {10, "Urban War Zone"},
    };
    return list;
}

const QVector<KeyAction> &keyActions()
{
    // VK codes: W S A D, U I J K, Enter, Backspace (the "WASD + UIJK" preset).
    static const QVector<KeyAction> list = {
        {"up", "Up", 0x0001, 0x57},           {"down", "Down", 0x0002, 0x53},
        {"left", "Left", 0x0004, 0x41},       {"right", "Right", 0x0008, 0x44},
        {"lp", "1  Left punch", 0x4000, 0x55}, {"rp", "2  Right punch", 0x8000, 0x49},
        {"lk", "3  Left kick", 0x1000, 0x4A},  {"rk", "4  Right kick", 0x2000, 0x4B},
        {"lprp", "1+2", 0xC000, 0},            {"lkrk", "3+4", 0x3000, 0},
        {"all", "1+2+3+4", 0xF000, 0},         {"start", "Start", 0x0010, 0x0D},
        {"select", "Select / Back", 0x0020, 0x08},
    };
    return list;
}

const QVector<PadButton> &padButtons()
{
    static const QVector<PadButton> list = {
        {"A", "A / Cross"},   {"B", "B / Circle"},     {"X", "X / Square"},
        {"Y", "Y / Triangle"}, {"LB", "LB / L1"},       {"RB", "RB / R1"},
        {"LT", "LT / L2"},     {"RT", "RT / R2"},       {"LS", "LS / L3"},
        {"RS", "RS / R3"},     {"BACK", "Back / Share"}, {"START", "Start / Options"},
    };
    return list;
}

const QVector<Region> &regions()
{
    static const QVector<Region> list = {
        {"EU", "Europe"},     {"USA", "North America"},  {"SA", "South America"},
        {"ASIA", "Asia"},     {"SEA", "Southeast Asia"}, {"OCE", "Oceania"},
        {"ME", "Middle East"}, {"AF", "Africa"},
    };
    return list;
}

QString guessRegionFromTimeZone()
{
    const QString tz = QString::fromLatin1(QTimeZone::systemTimeZoneId());
    auto startsWithAny = [&tz](std::initializer_list<const char *> prefixes) {
        for (const char *p : prefixes)
            if (tz.startsWith(QLatin1String(p)))
                return true;
        return false;
    };
    if (startsWithAny({"America/Sao_Paulo", "America/Argentina", "America/Buenos_Aires",
                       "America/Santiago", "America/Bogota", "America/Lima", "America/Caracas",
                       "America/Montevideo", "America/Asuncion", "America/La_Paz",
                       "America/Guayaquil", "America/Manaus", "America/Bahia",
                       "America/Fortaleza", "America/Recife", "America/Belem",
                       "America/Cayenne", "America/Paramaribo", "America/Guyana"}))
        return "SA";
    if (startsWithAny({"Asia/Dubai", "Asia/Riyadh", "Asia/Qatar", "Asia/Kuwait", "Asia/Bahrain",
                       "Asia/Muscat", "Asia/Aden", "Asia/Tehran", "Asia/Baghdad",
                       "Asia/Jerusalem", "Asia/Tel_Aviv", "Asia/Gaza", "Asia/Hebron",
                       "Asia/Amman", "Asia/Beirut", "Asia/Damascus"}))
        return "ME";
    if (startsWithAny({"Asia/Singapore", "Asia/Kuala_Lumpur", "Asia/Kuching", "Asia/Bangkok",
                       "Asia/Jakarta", "Asia/Pontianak", "Asia/Makassar", "Asia/Jayapura",
                       "Asia/Manila", "Asia/Ho_Chi_Minh", "Asia/Saigon", "Asia/Phnom_Penh",
                       "Asia/Vientiane", "Asia/Yangon", "Asia/Rangoon", "Asia/Brunei",
                       "Asia/Dili"}))
        return "SEA";
    if (startsWithAny({"Europe/", "Atlantic/"}))
        return "EU";
    if (startsWithAny({"America/", "US/", "Canada/"}))
        return "USA";
    if (startsWithAny({"Asia/", "Indian/"}))
        return "ASIA";
    if (startsWithAny({"Australia/", "Pacific/"}))
        return "OCE";
    if (startsWithAny({"Africa/"}))
        return "AF";
    return "EU";
}

}
