#pragma once

#include <QJsonObject>
#include <QString>

// Everything the launcher remembers, stored in launcher_native.ini next to the exe.
// Key names match the original launcher, so an existing .ini file keeps working.
struct Settings {
    // Identity / account
    QString name;          // player name (defaults to the Windows user name)
    QString session;       // login token from the server ("auth" next time)
    QString accountName;   // name the session belongs to
    QString clientId;      // random UUID created on first start

    // Fighter
    int character = 16;          // char_index 0..42
    QJsonObject costumes;        // { "<char index>": costume 0..2 }
    QJsonObject customLooks;     // { "<char>_<costume>": 160 hex chars } made in Customize
    QJsonObject customLooksOff;  // { "<char>_<costume>": true } custom look switched off

    // Online
    int delay = 1;          // frames of input delay (rollback starts after this)
    int keyboardLayout = 1; // "keys": 0 controller only, 1 WASD+UIJK, 2 arrows+numpad, 3 custom
    int gamePort = 7002;    // local UDP port of the game
    int maxPing = 150;
    int side = 0;           // 0 any, 1 left, 2 right
    QString region;
    bool regionLock = false;
    bool strictMatchmaking = false;
    QString boardRegion;
    bool onlyOpenLobbies = false;
    bool showPrivateLobbies = false;

    // Game options
    bool blur = true;
    bool vibration = true;
    bool stageMusic = true;
    bool fullscreen = true;
    bool borderless = false;
    int resolutionScale = 1;    // res_scale
    int render3d = 0;           // 0 = 1024x576, 1 = 768x432, 2 = 640x360 internal resolution
    bool smallShadows = false;
    QString gpu;                // adapter name, empty = default
    QString padBackend = QStringLiteral("sdl");  // sdl | mmjoystick

    // Sound when a match is found: 0 off, 1 built-in, 2 own file
    int matchSoundMode = 1;
    QString matchSoundFile;

    // Practice
    int practiceCharacter = -1;
    int practiceOpponent = -1;
    int practiceStage = -1;     // -1 random
    bool practiceFrameData = true;

    // Build info written after BUILD GAME
    QString builtFrom;
    QString builtVersion;

    void load();
    void save() const;

    // Single values, for the per-key bindings (kb_up, pad_A, ...).
    static int intValue(const QString &key, int defaultValue);
    static void setIntValue(const QString &key, int value);

    int costumeFor(int character) const;
    void setCostumeFor(int character, int costume);
    // Custom look (160 hex chars) for the current character/costume, or empty.
    QString customLookFor(int character, int costume) const;
};
