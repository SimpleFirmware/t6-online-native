#pragma once

#include <QString>
#include <QVector>

// Static game tables copied from the original launcher (character list, game-internal
// character IDs, stages, default key bindings, gamepad buttons, regions).
namespace GameData {

constexpr int kCharacterCount = 43;
constexpr int kKuma = 11;
constexpr int kPanda = 12;
constexpr int kDefaultCharacter = 16;  // LEE

// Display name of character index 0..42 (the index the launcher and server use).
QString characterName(int index);

// Characters sorted by name, for drop-downs.
QVector<int> charactersByName();

// The ID the game itself uses for a character + costume (0 = first, 1 = second,
// 2 = third costume if the character has one). Kuma/Panda have one costume.
int gameCharacterId(int index, int costume);
bool hasThirdCostume(int index);

struct Stage {
    int gameId;
    const char *name;
};
const QVector<Stage> &stages();

// Keyboard actions the game understands. `mask` is the Xbox 360 button bit the key is mapped
// to, `defaultVk` the Windows virtual-key code used when the player didn't choose one.
struct KeyAction {
    const char *id;      // settings key suffix: kb_<id>
    const char *label;
    int mask;
    int defaultVk;
};
const QVector<KeyAction> &keyActions();

// Gamepad buttons that can be remapped (settings pad_<id>, -1 = default).
struct PadButton {
    const char *id;
    const char *label;
};
const QVector<PadButton> &padButtons();

struct Region {
    const char *code;   // sent to the server
    const char *label;
};
const QVector<Region> &regions();

// Rough region from the PC's time zone, used as the default the first time.
QString guessRegionFromTimeZone();

}
