#include "core/Log.h"

#include <QDateTime>
#include <QFile>

Log &Log::instance()
{
    static Log log;
    return log;
}

void Log::info(const QString &text)
{
    const QString stamped = QDateTime::currentDateTime().toString("HH:mm:ss.zzz ") + text;
    emit instance().line(stamped);

    const QString &file = instance().m_gameLogFile;
    if (!file.isEmpty()) {
        QFile f(file);
        if (f.open(QIODevice::Append | QIODevice::Text))
            f.write(QStringLiteral("[%1] [launcher] %2\n")
                        .arg(QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss.zzz"), text)
                        .toUtf8());
    }
}

void Log::net(const QString &direction, const QByteArray &json)
{
    QByteArray shown = json.trimmed();
    // Never show passwords in the log window.
    const int pw = shown.indexOf("\"password\"");
    if (pw >= 0)
        shown = shown.left(pw) + "\"password\":\"***\"}";
    emit instance().line(QDateTime::currentDateTime().toString("HH:mm:ss.zzz ") + direction + ' ' +
                         QString::fromUtf8(shown));
}

void Log::setGameLogFile(const QString &path) { instance().m_gameLogFile = path; }
