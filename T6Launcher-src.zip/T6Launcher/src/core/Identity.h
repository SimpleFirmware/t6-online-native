#pragma once

#include <QString>

namespace Identity {

// Anonymous device ID sent in "hello": the first 32 hex chars of SHA-256("t6:" + the Windows
// MachineGuid). The GUID itself never leaves the PC. Empty if it can't be read.
QString machineId();

// Short fingerprint (16 hex chars, SHA-1) of the files both players must have identical for a
// netplay match: the built game exe, the two runtime DLLs, tools/menu_vs.bin,
// tools/netplay_exclude.txt and the save profile. Sent as "build" in "hello"; the server uses
// it to refuse matches between different builds ("state_mismatch").
QString buildFingerprint();

}
