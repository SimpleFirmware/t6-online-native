#pragma once

#include <QObject>
#include <QString>

// One place for diagnostic output. Everything also goes to the "Log" tab in the window, which
// is the easiest way to watch the lobby protocol while experimenting.
class Log : public QObject {
    Q_OBJECT
public:
    static Log &instance();

    static void info(const QString &text);
    static void net(const QString &direction, const QByteArray &json);  // ">>" sent, "<<" received

    // When set, info() lines are also appended to this file (the current game run's log).
    static void setGameLogFile(const QString &path);

signals:
    void line(const QString &text);

private:
    QString m_gameLogFile;
};
