#include "core/Identity.h"

#include "core/Paths.h"

#include <QCryptographicHash>
#include <QDir>
#include <QDirIterator>
#include <QFile>
#include <QFileInfo>
#include <QSettings>

namespace {

QByteArray readMachineGuid()
{
#ifdef Q_OS_WIN
    QSettings reg("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Cryptography", QSettings::NativeFormat);
    return reg.value("MachineGuid").toString().toUtf8();
#else
    // Not part of the original (Windows only); keeps the ID stable on Linux test machines.
    QFile f("/etc/machine-id");
    if (f.open(QIODevice::ReadOnly))
        return f.readAll().trimmed();
    return {};
#endif
}

// Adds "<label><file contents>" (or "<label>missing") to the hash, like the original.
void addFile(QCryptographicHash &hash, const QString &label, const QString &path)
{
    hash.addData(label.toUtf8());
    QFile f(path);
    if (f.open(QIODevice::ReadOnly))
        hash.addData(&f);
    else
        hash.addData(QByteArrayView("missing"));
}

QStringList filesUnder(const QString &dir)
{
    QStringList out;
    QDirIterator it(dir, QDir::Files, QDirIterator::Subdirectories);
    while (it.hasNext())
        out << QDir(dir).relativeFilePath(it.next());
    out.sort(Qt::CaseSensitive);
    return out;
}

}  // namespace

namespace Identity {

QString machineId()
{
    const QByteArray guid = readMachineGuid();
    if (guid.isEmpty())
        return {};
    const QByteArray digest = QCryptographicHash::hash("t6:" + guid, QCryptographicHash::Sha256);
    return QString::fromLatin1(digest.toHex().left(32));
}

QString buildFingerprint()
{
    QCryptographicHash hash(QCryptographicHash::Sha1);
    const QString exe = Paths::builtGameExe();
    const QDir exeDir = QFileInfo(exe).absoluteDir();

    addFile(hash, "exe", exe);
    for (const char *dll : {"rexruntime.dll", "rexgpu-xenos.dll"})
        addFile(hash, QString::fromLatin1(dll), exeDir.filePath(dll));
    addFile(hash, "menu", Paths::file("tools/menu_vs.bin"));
    addFile(hash, "exclude", Paths::file("tools/netplay_exclude.txt"));

    const QString profile = Paths::profileDir();
    for (const QString &rel : filesUnder(profile))
        addFile(hash, "profile/" + rel, QDir(profile).filePath(rel));

    return QString::fromLatin1(hash.result().toHex().left(16));
}

}
