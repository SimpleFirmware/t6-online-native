#include "core/Settings.h"

#include "core/GameData.h"
#include "core/Paths.h"

#include <QJsonDocument>
#include <QSettings>
#include <QUuid>

namespace {

QSettings openIni() { return QSettings(Paths::settingsFile(), QSettings::IniFormat); }

QJsonObject jsonObject(const QSettings &s, const char *key)
{
    return QJsonDocument::fromJson(s.value(key).toByteArray()).object();
}

void setJsonObject(QSettings &s, const char *key, const QJsonObject &o)
{
    s.setValue(key, QString::fromUtf8(QJsonDocument(o).toJson(QJsonDocument::Compact)));
}

}  // namespace

void Settings::load()
{
    QSettings s = openIni();
    const int inst = Paths::instance();

    QString defaultName = qEnvironmentVariable("USERNAME", qEnvironmentVariable("USER"));
    if (inst > 1)
        defaultName += QString::number(inst);
    name = s.value("name", defaultName).toString();
    session = s.value("session").toString();
    accountName = s.value("account").toString();

    clientId = s.value("client_id").toString();
    if (clientId.isEmpty()) {
        clientId = QUuid::createUuid().toString(QUuid::WithoutBraces);
        s.setValue("client_id", clientId);
    }

    character = s.value("char_index", GameData::kDefaultCharacter).toInt();
    if (character < 0 || character >= GameData::kCharacterCount)
        character = GameData::kDefaultCharacter;
    costumes = jsonObject(s, "costumes");
    customLooks = jsonObject(s, "custom_looks");
    customLooksOff = jsonObject(s, "custom_looks_off");

    delay = s.value("delay", 1).toInt();
    keyboardLayout = qBound(0, s.value("keys", 1).toInt(), 3);
    gamePort = s.value("game_port", 7000 + 2 * inst).toInt();
    maxPing = s.value("max_ping", 150).toInt();
    side = qBound(0, s.value("side", 0).toInt(), 2);
    region = s.value("region", GameData::guessRegionFromTimeZone()).toString();
    regionLock = s.value("region_lock", false).toBool();
    strictMatchmaking = s.value("strict_mm", false).toBool();
    boardRegion = s.value("board_region", region).toString();
    onlyOpenLobbies = s.value("only_open_lobbies", false).toBool();
    showPrivateLobbies = s.value("show_private_lobbies_222", false).toBool();

    blur = s.value("blur", true).toBool();
    vibration = s.value("vibration", true).toBool();
    stageMusic = s.value("stage_music", true).toBool();
    fullscreen = s.value("fullscreen", true).toBool();
    borderless = s.value("borderless", false).toBool();
    resolutionScale = qBound(1, s.value("res_scale", 1).toInt(), 4);
    render3d = qBound(0, s.value("render_3d", 0).toInt(), 2);
    smallShadows = s.value("small_shadows", false).toBool();
    gpu = s.value("gpu").toString();
    padBackend = s.value("pad_backend", "sdl").toString();

    matchSoundMode = s.value("match_sound_mode", 1).toInt();
    matchSoundFile = s.value("match_sound_file").toString();

    practiceCharacter = s.value("practice_char", -1).toInt();
    practiceOpponent = s.value("practice_opp", -1).toInt();
    practiceStage = s.value("practice_stage", -1).toInt();
    practiceFrameData = s.value("practice_frame_data", true).toBool();

    builtFrom = s.value("built_from").toString();
    builtVersion = s.value("built_version").toString();
}

void Settings::save() const
{
    QSettings s = openIni();
    s.setValue("name", name);
    if (session.isEmpty())
        s.remove("session");
    else
        s.setValue("session", session);
    s.setValue("account", accountName);
    s.setValue("client_id", clientId);

    s.setValue("char_index", character);
    setJsonObject(s, "costumes", costumes);
    setJsonObject(s, "custom_looks", customLooks);
    setJsonObject(s, "custom_looks_off", customLooksOff);

    s.setValue("delay", delay);
    s.setValue("keys", keyboardLayout);
    s.setValue("game_port", gamePort);
    s.setValue("max_ping", maxPing);
    s.setValue("side", side);
    s.setValue("region", region);
    s.setValue("region_lock", regionLock);
    s.setValue("strict_mm", strictMatchmaking);
    s.setValue("board_region", boardRegion);
    s.setValue("only_open_lobbies", onlyOpenLobbies);
    s.setValue("show_private_lobbies_222", showPrivateLobbies);

    s.setValue("blur", blur);
    s.setValue("vibration", vibration);
    s.setValue("stage_music", stageMusic);
    s.setValue("fullscreen", fullscreen);
    s.setValue("borderless", borderless);
    s.setValue("res_scale", resolutionScale);
    s.setValue("render_3d", render3d);
    s.setValue("small_shadows", smallShadows);
    s.setValue("gpu", gpu);
    s.setValue("pad_backend", padBackend);

    s.setValue("match_sound_mode", matchSoundMode);
    s.setValue("match_sound_file", matchSoundFile);

    s.setValue("practice_char", practiceCharacter);
    s.setValue("practice_opp", practiceOpponent);
    s.setValue("practice_stage", practiceStage);
    s.setValue("practice_frame_data", practiceFrameData);

    s.setValue("built_from", builtFrom);
    s.setValue("built_version", builtVersion);
}

int Settings::intValue(const QString &key, int defaultValue)
{
    return openIni().value(key, defaultValue).toInt();
}

void Settings::setIntValue(const QString &key, int value)
{
    QSettings s = openIni();
    s.setValue(key, value);
}

int Settings::costumeFor(int c) const
{
    if (c == GameData::kKuma || c == GameData::kPanda)
        return 0;
    const int costume = costumes.value(QString::number(c)).toInt(0);
    if (costume == 2 && !GameData::hasThirdCostume(c))
        return 1;
    return qBound(0, costume, 2);
}

void Settings::setCostumeFor(int c, int costume) { costumes[QString::number(c)] = costume; }

QString Settings::customLookFor(int c, int costume) const
{
    const QString key = QStringLiteral("%1_%2").arg(c).arg(costume);
    if (customLooksOff.contains(key))
        return {};
    return customLooks.value(key).toString();
}
