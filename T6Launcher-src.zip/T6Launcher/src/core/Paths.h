#pragma once

#include <QString>

// Where things live inside the package folder (the folder that contains the launcher,
// builder\, tools\, native\ ...). Same layout as the original release zip.
namespace Paths {

// 1 for the first launcher, 2.. for extra copies started with "--instance N" (used to run two
// launchers on one PC for testing). Selects the settings file and the default UDP port.
int instance();
void setInstance(int n);

QString packageRoot();                    // folder of the package
QString file(const QString &relative);    // packageRoot()/relative

QString builtGameExe();                   // native/tekken6.exe (or a dev-build fallback)
QString gameDataDir();                    // native/game   (data extracted from the ISO)
QString profileDir();                     // profile/ or user/  (save data copied into each run)
QString builderScript();                  // builder/build_native.py
QString bundledPython();                  // builder/python/python.exe
QString settingsFile();                   // launcher_native.ini / launcher_native_N.ini

// A fresh working folder for one game run, e.g. runs/online_1, runs/practice_1.
QString runDir(const QString &kind);

}
