#include "core/Paths.h"

#include <QCoreApplication>
#include <QDir>
#include <QFile>

namespace {
int g_instance = 1;
}

namespace Paths {

int instance() { return g_instance; }
void setInstance(int n) { g_instance = n < 1 ? 1 : n; }

QString packageRoot()
{
    // The exe normally sits in the package folder. In development builds it sits one level
    // below, so walk up once if nothing of the package is found next to it.
    QDir dir(QCoreApplication::applicationDirPath());
    for (int i = 0; i < 2; ++i) {
        if (QFile::exists(dir.filePath("build/tekken6.exe")) ||
            QFile::exists(dir.filePath("tekken6.exe")) ||
            QFile::exists(dir.filePath("builder/build_native.py")) ||
            QFile::exists(dir.filePath("native/tekken6.exe")))
            return dir.absolutePath();
        if (!dir.cdUp())
            break;
    }
    return QCoreApplication::applicationDirPath();
}

QString file(const QString &relative) { return QDir(packageRoot()).filePath(relative); }

QString builtGameExe()
{
    for (const char *candidate : {"native/tekken6.exe", "build/tekken6.exe", "tekken6.exe"}) {
        const QString path = file(candidate);
        if (QFile::exists(path))
            return path;
    }
    return file("native/tekken6.exe");
}

QString gameDataDir() { return file("native/game"); }

QString profileDir()
{
    const QString profile = file("profile");
    return QDir(profile).exists() ? profile : file("user");
}

QString builderScript() { return file("builder/build_native.py"); }
QString bundledPython() { return file("builder/python/python.exe"); }

QString settingsFile()
{
    return file(g_instance == 1 ? QStringLiteral("launcher_native.ini")
                                : QStringLiteral("launcher_native_%1.ini").arg(g_instance));
}

QString runDir(const QString &kind)
{
    return file(QStringLiteral("runs/%1_%2").arg(kind).arg(g_instance));
}

}
