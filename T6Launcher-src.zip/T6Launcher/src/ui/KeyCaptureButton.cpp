#include "ui/KeyCaptureButton.h"

#include <QKeyEvent>

KeyCaptureButton::KeyCaptureButton(int virtualKey, QWidget *parent)
    : QPushButton(parent), m_vk(virtualKey)
{
    setFocusPolicy(Qt::StrongFocus);
    setMinimumWidth(90);
    connect(this, &QPushButton::clicked, this, &KeyCaptureButton::startCapture);
    updateText();
}

void KeyCaptureButton::setVirtualKey(int vk)
{
    m_vk = vk;
    updateText();
}

void KeyCaptureButton::startCapture()
{
    m_capturing = true;
    setText(tr("press a key…"));
    setFocus();
    grabKeyboard();
}

void KeyCaptureButton::keyPressEvent(QKeyEvent *event)
{
    if (!m_capturing) {
        QPushButton::keyPressEvent(event);
        return;
    }
    releaseKeyboard();
    m_capturing = false;
    if (event->key() != Qt::Key_Escape) {
        const int vk = virtualKeyFromEvent(event);
        if (vk > 0 && vk != m_vk) {
            m_vk = vk;
            emit keyChanged(vk);
        }
    }
    updateText();
}

void KeyCaptureButton::focusOutEvent(QFocusEvent *event)
{
    if (m_capturing) {
        releaseKeyboard();
        m_capturing = false;
        updateText();
    }
    QPushButton::focusOutEvent(event);
}

void KeyCaptureButton::updateText() { setText(keyName(m_vk)); }

// On Windows Qt hands us the real virtual-key code. Elsewhere (for testing the UI on Linux)
// translate the common keys by hand.
int KeyCaptureButton::virtualKeyFromEvent(const QKeyEvent *event)
{
#ifdef Q_OS_WIN
    if (event->nativeVirtualKey() != 0)
        return int(event->nativeVirtualKey());
#endif
    const int k = event->key();
    const bool keypad = event->modifiers() & Qt::KeypadModifier;
    if (keypad && k >= Qt::Key_0 && k <= Qt::Key_9)
        return 0x60 + (k - Qt::Key_0);           // VK_NUMPAD0..9
    if (k >= Qt::Key_A && k <= Qt::Key_Z)
        return 'A' + (k - Qt::Key_A);
    if (k >= Qt::Key_0 && k <= Qt::Key_9)
        return '0' + (k - Qt::Key_0);
    if (k >= Qt::Key_F1 && k <= Qt::Key_F12)
        return 0x70 + (k - Qt::Key_F1);
    switch (k) {
    case Qt::Key_Left: return 0x25;
    case Qt::Key_Up: return 0x26;
    case Qt::Key_Right: return 0x27;
    case Qt::Key_Down: return 0x28;
    case Qt::Key_Space: return 0x20;
    case Qt::Key_Return:
    case Qt::Key_Enter: return 0x0D;
    case Qt::Key_Tab: return 0x09;
    case Qt::Key_Backspace: return 0x08;
    case Qt::Key_Shift: return 0x10;
    case Qt::Key_Control: return 0x11;
    case Qt::Key_Alt: return 0x12;
    case Qt::Key_Insert: return 0x2D;
    case Qt::Key_Delete: return 0x2E;
    case Qt::Key_Home: return 0x24;
    case Qt::Key_End: return 0x23;
    case Qt::Key_PageUp: return 0x21;
    case Qt::Key_PageDown: return 0x22;
    case Qt::Key_Comma: return 0xBC;
    case Qt::Key_Period: return 0xBE;
    case Qt::Key_Semicolon: return 0xBA;
    case Qt::Key_Slash: return 0xBF;
    case Qt::Key_Minus: return 0xBD;
    case Qt::Key_Equal: return 0xBB;
    case Qt::Key_BracketLeft: return 0xDB;
    case Qt::Key_BracketRight: return 0xDD;
    case Qt::Key_Backslash: return 0xDC;
    case Qt::Key_Apostrophe: return 0xDE;
    default: return 0;
    }
}

QString KeyCaptureButton::keyName(int vk)
{
    if (vk <= 0)
        return tr("(none)");
    if ((vk >= 'A' && vk <= 'Z') || (vk >= '0' && vk <= '9'))
        return QString(QChar(vk));
    if (vk >= 0x60 && vk <= 0x69)
        return QStringLiteral("Num %1").arg(vk - 0x60);
    if (vk >= 0x70 && vk <= 0x7B)
        return QStringLiteral("F%1").arg(vk - 0x6F);
    switch (vk) {
    case 0x25: return tr("Left");
    case 0x26: return tr("Up");
    case 0x27: return tr("Right");
    case 0x28: return tr("Down");
    case 0x20: return tr("Space");
    case 0x0D: return tr("Enter");
    case 0x09: return tr("Tab");
    case 0x08: return tr("Backspace");
    case 0x10: case 0xA0: return tr("Shift");
    case 0xA1: return tr("Right Shift");
    case 0x11: case 0xA2: return tr("Ctrl");
    case 0xA3: return tr("Right Ctrl");
    case 0x12: case 0xA4: return tr("Alt");
    case 0x2D: return tr("Insert");
    case 0x2E: return tr("Delete");
    case 0x24: return tr("Home");
    case 0x23: return tr("End");
    case 0x21: return tr("Page Up");
    case 0x22: return tr("Page Down");
    case 0x6A: return tr("Num *");
    case 0x6B: return tr("Num +");
    case 0x6D: return tr("Num -");
    case 0x6E: return tr("Num .");
    case 0x6F: return tr("Num /");
    case 0xBC: return ",";
    case 0xBE: return ".";
    case 0xBA: return ";";
    case 0xBF: return "/";
    case 0xBD: return "-";
    case 0xBB: return "=";
    case 0xDB: return "[";
    case 0xDD: return "]";
    case 0xDC: return "\\";
    case 0xDE: return "'";
    default: return QStringLiteral("0x%1").arg(vk, 2, 16, QChar('0'));
    }
}
