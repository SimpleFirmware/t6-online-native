#pragma once

#include <QPushButton>

// A button that shows a keyboard binding. Click it, press a key, and it stores the key as a
// Windows virtual-key code (what the game's T6_KEYMAP expects). Esc cancels.
class KeyCaptureButton : public QPushButton {
    Q_OBJECT
public:
    explicit KeyCaptureButton(int virtualKey, QWidget *parent = nullptr);

    int virtualKey() const { return m_vk; }
    void setVirtualKey(int vk);

    // Readable name of a virtual-key code ("W", "Up", "Num 4" ...).
    static QString keyName(int vk);

signals:
    void keyChanged(int vk);

protected:
    void keyPressEvent(QKeyEvent *event) override;
    void focusOutEvent(QFocusEvent *event) override;

private:
    void startCapture();
    void updateText();
    static int virtualKeyFromEvent(const QKeyEvent *event);

    int m_vk;
    bool m_capturing = false;
};
