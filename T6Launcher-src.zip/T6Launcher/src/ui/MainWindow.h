#pragma once

#include <QJsonArray>
#include <QJsonObject>
#include <QMainWindow>
#include <QTimer>

class Builder;
class MatchController;
class Updater;
struct Settings;

class QCheckBox;
class QComboBox;
class QLabel;
class QLineEdit;
class QPlainTextEdit;
class QProgressBar;
class QPushButton;
class QSpinBox;
class QTabWidget;
class QTreeWidget;

// The launcher window. Deliberately plain Qt widgets (the original draws its own styled UI):
// every tab only calls MatchController / Builder / Updater and redraws itself from their state
// in refresh(), so the logic stays in one place and is easy to follow.
//
// Tabs: Play · Lobbies · Practice · Leaderboard · Profile · Build · Update · Log
class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    MainWindow(Settings &settings, MatchController &controller, QWidget *parent = nullptr);
    ~MainWindow() override;

protected:
    void closeEvent(QCloseEvent *event) override;

private:
    QWidget *createPlayTab();
    QWidget *createLobbiesTab();
    QWidget *createPracticeTab();
    QWidget *createLeaderboardTab();
    QWidget *createProfileTab();
    QWidget *createBuildTab();
    QWidget *createUpdateTab();
    QWidget *createLogTab();

    void refresh();                 // redraw everything from the controller's state
    void refreshLobbyList();
    void refreshLeaderboard();
    void loadProfileWidgets();
    void saveProfile();
    void appendLog(const QString &line);
    void sendRawJson();
    void fillCostumes();

    Settings &m_settings;
    MatchController &m;
    Builder *m_builder;
    Updater *m_updater;
    QTimer m_tick;                  // countdowns (accept timer, next game)
    QJsonArray m_shownLobbies;
    QJsonObject m_shownLeaderboard;

    QTabWidget *m_tabs = nullptr;
    QLabel *m_header = nullptr;
    QLabel *m_notice = nullptr;

    // Play
    QWidget *m_loginBox = nullptr;
    QLineEdit *m_loginName = nullptr;
    QLineEdit *m_loginPassword = nullptr;
    QWidget *m_accountBox = nullptr;
    QLabel *m_accountLabel = nullptr;
    QPushButton *m_rankedButton = nullptr;
    QPushButton *m_playerButton = nullptr;
    QPushButton *m_cancelButton = nullptr;
    QLabel *m_vsLabel = nullptr;
    QLabel *m_statusLabel = nullptr;
    QLabel *m_infoLabel = nullptr;
    QLabel *m_countdownLabel = nullptr;
    QPushButton *m_acceptButton = nullptr;
    QPushButton *m_leaveButton = nullptr;
    QPushButton *m_blockButton = nullptr;
    QLabel *m_gameStateLabel = nullptr;

    // Lobbies
    QTreeWidget *m_lobbyList = nullptr;
    QCheckBox *m_onlyOpen = nullptr;
    QCheckBox *m_showPrivate = nullptr;
    QLineEdit *m_joinCode = nullptr;
    QLabel *m_lobbyLabel = nullptr;
    QComboBox *m_lobbyStage = nullptr;
    QPushButton *m_lobbyReady = nullptr;
    QPushButton *m_lobbyLeave = nullptr;

    // Practice
    QComboBox *m_practiceChar = nullptr;
    QComboBox *m_practiceOpponent = nullptr;
    QComboBox *m_practiceStage = nullptr;
    QCheckBox *m_practiceFrameData = nullptr;
    QPushButton *m_practiceButton = nullptr;

    // Leaderboard / history
    QComboBox *m_boardRegion = nullptr;
    QTreeWidget *m_board = nullptr;
    QLabel *m_boardInfo = nullptr;
    QLineEdit *m_historyName = nullptr;
    QTreeWidget *m_history = nullptr;
    QTreeWidget *m_blocks = nullptr;

    // Profile
    QLineEdit *m_name = nullptr;
    QComboBox *m_char = nullptr;
    QComboBox *m_costume = nullptr;
    QComboBox *m_side = nullptr;
    QComboBox *m_region = nullptr;
    QCheckBox *m_regionLock = nullptr;
    QCheckBox *m_strict = nullptr;
    QSpinBox *m_delay = nullptr;
    QSpinBox *m_maxPing = nullptr;
    QSpinBox *m_port = nullptr;
    QComboBox *m_keys = nullptr;
    QCheckBox *m_fullscreen = nullptr;
    QCheckBox *m_borderless = nullptr;
    QCheckBox *m_blur = nullptr;
    QCheckBox *m_vibration = nullptr;
    QCheckBox *m_stageMusic = nullptr;
    QCheckBox *m_smallShadows = nullptr;
    QSpinBox *m_resScale = nullptr;
    QComboBox *m_render3d = nullptr;
    QComboBox *m_gpu = nullptr;
    QComboBox *m_padBackend = nullptr;
    QComboBox *m_sound = nullptr;

    // Build
    QLineEdit *m_buildSource = nullptr;
    QLabel *m_buildState = nullptr;
    QProgressBar *m_buildProgress = nullptr;
    QPlainTextEdit *m_buildLog = nullptr;
    QPushButton *m_buildButton = nullptr;
    QPushButton *m_buildCancel = nullptr;

    // Update
    QLabel *m_updateLabel = nullptr;
    QPushButton *m_updateInstall = nullptr;
    QProgressBar *m_updateProgress = nullptr;

    // Log
    QPlainTextEdit *m_log = nullptr;
    QLineEdit *m_rawJson = nullptr;
    QCheckBox *m_logTraffic = nullptr;
};
