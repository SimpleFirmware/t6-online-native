#include "ui/MainWindow.h"

#include "MatchController.h"
#include "build/Builder.h"
#include "core/GameData.h"
#include "core/Log.h"
#include "core/Paths.h"
#include "core/Settings.h"
#include "game/Platform.h"
#include "ui/KeyCaptureButton.h"
#include "update/Updater.h"

#include <QApplication>
#include <QCheckBox>
#include <QCloseEvent>
#include <QComboBox>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFormLayout>
#include <QGridLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QJsonDocument>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QPlainTextEdit>
#include <QProcess>
#include <QProgressBar>
#include <QPushButton>
#include <QScrollArea>
#include <QSpinBox>
#include <QTabWidget>
#include <QTreeWidget>
#include <QVBoxLayout>

namespace {

QString playerText(const QJsonObject &p)
{
    if (p.isEmpty())
        return QObject::tr("(free)");
    QString s = p.value("name").toString();
    if (p.contains("char"))
        s += "  ·  " + GameData::characterName(p.value("char").toInt());
    if (p.contains("rank_name"))
        s += "  ·  " + p.value("rank_name").toString();
    if (p.contains("elo"))
        s += QStringLiteral("  ·  %1").arg(p.value("elo").toInt());
    if (p.contains("region"))
        s += "  ·  " + p.value("region").toString();
    return s;
}

void fillCharacters(QComboBox *box, bool withDefault)
{
    if (withDefault)
        box->addItem(QObject::tr("(same as profile)"), -1);
    for (int c : GameData::charactersByName())
        box->addItem(GameData::characterName(c), c);
}

void fillStages(QComboBox *box)
{
    box->addItem(QObject::tr("Random"), -1);
    for (const auto &s : GameData::stages())
        box->addItem(QString::fromUtf8(s.name), s.gameId);
}

void selectData(QComboBox *box, const QVariant &value)
{
    const int i = box->findData(value);
    if (i >= 0)
        box->setCurrentIndex(i);
}

QString compact(const QJsonValue &v)
{
    if (v.isObject())
        return QString::fromUtf8(QJsonDocument(v.toObject()).toJson(QJsonDocument::Compact));
    if (v.isArray())
        return QString::fromUtf8(QJsonDocument(v.toArray()).toJson(QJsonDocument::Compact));
    return v.toVariant().toString();
}

}  // namespace

MainWindow::MainWindow(Settings &settings, MatchController &controller, QWidget *parent)
    : QMainWindow(parent),
      m_settings(settings),
      m(controller),
      m_builder(new Builder(this)),
      m_updater(new Updater(this))
{
    setWindowTitle(Paths::instance() > 1
                       ? tr("Tekken 6 Online (rebuild) - instance %1").arg(Paths::instance())
                       : tr("Tekken 6 Online (rebuild)"));
    resize(980, 680);

    auto *central = new QWidget;
    auto *layout = new QVBoxLayout(central);
    m_header = new QLabel;
    m_header->setTextFormat(Qt::RichText);
    m_notice = new QLabel;
    m_notice->setWordWrap(true);
    m_notice->setStyleSheet("background:#fff3c4;color:#333;padding:4px;border-radius:3px");
    layout->addWidget(m_header);
    layout->addWidget(m_notice);

    m_tabs = new QTabWidget;
    m_tabs->addTab(createPlayTab(), tr("Play"));
    m_tabs->addTab(createLobbiesTab(), tr("Lobbies"));
    m_tabs->addTab(createPracticeTab(), tr("Practice"));
    m_tabs->addTab(createLeaderboardTab(), tr("Leaderboard"));
    m_tabs->addTab(createProfileTab(), tr("Profile"));
    m_tabs->addTab(createBuildTab(), tr("Build"));
    m_tabs->addTab(createUpdateTab(), tr("Update"));
    m_tabs->addTab(createLogTab(), tr("Log"));
    layout->addWidget(m_tabs, 1);
    setCentralWidget(central);

    connect(&m, &MatchController::changed, this, &MainWindow::refresh);
    connect(&m, &MatchController::message, this, [this](const QString &title, const QString &text) {
        QMessageBox::information(this, title, text);
    });
    connect(&m, &MatchController::bringToFront, this, [this] {
        Platform::bringToFront(this);
        Platform::flashTaskbar(this);
    });
    connect(&m, &MatchController::historyReceived, this, [this](const QString &name, const QJsonArray &matches) {
        m_history->clear();
        for (const QJsonValue &v : matches) {
            const QJsonObject o = v.toObject();
            auto *item = new QTreeWidgetItem(m_history);
            item->setText(0, name);
            item->setText(1, compact(o));
        }
    });
    connect(&Log::instance(), &Log::line, this, &MainWindow::appendLog);

    connect(m_tabs, &QTabWidget::currentChanged, this, [this](int index) {
        const QString title = m_tabs->tabText(index);
        if (title == tr("Lobbies"))
            m.requestLobbies(true);
        else if (title == tr("Leaderboard")) {
            m.requestLeaderboard(m_boardRegion->currentData().toString());
            m.requestBlockList();
        }
    });

    m_tick.setInterval(250);
    connect(&m_tick, &QTimer::timeout, this, &MainWindow::refresh);
    m_tick.start();

    loadProfileWidgets();
    refresh();
}

MainWindow::~MainWindow() = default;

void MainWindow::closeEvent(QCloseEvent *event)
{
    if (m.inMatch &&
        QMessageBox::question(this, windowTitle(),
                              tr("A match is running. Closing counts as leaving it. Close anyway?")) !=
            QMessageBox::Yes) {
        event->ignore();
        return;
    }
    if (m_builder->isRunning())
        m_builder->cancel();
    event->accept();
}

// ------------------------------------------------------------------------------------------
// Play

QWidget *MainWindow::createPlayTab()
{
    auto *page = new QWidget;
    auto *v = new QVBoxLayout(page);

    // Not logged in: log in / register / guest.
    m_loginBox = new QGroupBox(tr("Account"));
    auto *lf = new QFormLayout(m_loginBox);
    m_loginName = new QLineEdit(m_settings.accountName.isEmpty() ? m_settings.name : m_settings.accountName);
    m_loginPassword = new QLineEdit;
    m_loginPassword->setEchoMode(QLineEdit::Password);
    lf->addRow(tr("Name"), m_loginName);
    lf->addRow(tr("Password"), m_loginPassword);
    auto *lb = new QHBoxLayout;
    auto *loginBtn = new QPushButton(tr("Log in"));
    auto *registerBtn = new QPushButton(tr("Create account"));
    auto *guestBtn = new QPushButton(tr("Play as guest"));
    lb->addWidget(loginBtn);
    lb->addWidget(registerBtn);
    lb->addWidget(guestBtn);
    lb->addStretch();
    lf->addRow(lb);
    connect(loginBtn, &QPushButton::clicked, this, [this] {
        m.login(m_loginName->text(), m_loginPassword->text(), false);
        m_loginPassword->clear();
    });
    connect(m_loginPassword, &QLineEdit::returnPressed, loginBtn, &QPushButton::click);
    connect(registerBtn, &QPushButton::clicked, this, [this] {
        m.login(m_loginName->text(), m_loginPassword->text(), true);
        m_loginPassword->clear();
    });
    connect(guestBtn, &QPushButton::clicked, this, [this] { m.playAsGuest(); });
    v->addWidget(m_loginBox);

    // Logged in.
    m_accountBox = new QGroupBox(tr("Account"));
    auto *ah = new QHBoxLayout(m_accountBox);
    m_accountLabel = new QLabel;
    auto *logoutBtn = new QPushButton(tr("Log out"));
    ah->addWidget(m_accountLabel, 1);
    ah->addWidget(logoutBtn);
    connect(logoutBtn, &QPushButton::clicked, this, [this] { m.logout(); });
    v->addWidget(m_accountBox);

    auto *search = new QGroupBox(tr("Matchmaking"));
    auto *sh = new QHBoxLayout(search);
    m_rankedButton = new QPushButton(tr("RANKED MATCH"));
    m_playerButton = new QPushButton(tr("PLAYER MATCH"));
    m_cancelButton = new QPushButton(tr("Cancel search"));
    for (QPushButton *b : {m_rankedButton, m_playerButton})
        b->setMinimumHeight(48);
    sh->addWidget(m_rankedButton);
    sh->addWidget(m_playerButton);
    sh->addWidget(m_cancelButton);
    connect(m_rankedButton, &QPushButton::clicked, this, [this] { m.searchQuick(true); });
    connect(m_playerButton, &QPushButton::clicked, this, [this] { m.searchQuick(false); });
    connect(m_cancelButton, &QPushButton::clicked, this, [this] { m.cancelSearch(); });
    v->addWidget(search);

    auto *matchBox = new QGroupBox(tr("Match"));
    auto *mv = new QVBoxLayout(matchBox);
    m_vsLabel = new QLabel;
    m_vsLabel->setStyleSheet("font-size:15px;font-weight:bold");
    m_vsLabel->setWordWrap(true);
    m_statusLabel = new QLabel;
    m_statusLabel->setStyleSheet("font-size:14px");
    m_countdownLabel = new QLabel;
    m_infoLabel = new QLabel;
    m_infoLabel->setWordWrap(true);
    m_infoLabel->setTextInteractionFlags(Qt::TextSelectableByMouse);
    mv->addWidget(m_vsLabel);
    mv->addWidget(m_statusLabel);
    mv->addWidget(m_countdownLabel);
    mv->addWidget(m_infoLabel);
    auto *mb = new QHBoxLayout;
    m_acceptButton = new QPushButton;
    m_leaveButton = new QPushButton;
    m_blockButton = new QPushButton(tr("Block opponent"));
    m_acceptButton->setMinimumHeight(40);
    m_leaveButton->setMinimumHeight(40);
    mb->addWidget(m_acceptButton);
    mb->addWidget(m_leaveButton);
    mb->addStretch();
    mb->addWidget(m_blockButton);
    mv->addLayout(mb);
    connect(m_acceptButton, &QPushButton::clicked, this, [this] { m.acceptMatch(); });
    connect(m_leaveButton, &QPushButton::clicked, this, [this] { m.declineOrLeave(); });
    connect(m_blockButton, &QPushButton::clicked, this, [this] {
        if (QMessageBox::question(this, tr("Block"), tr("Never be matched with this player again?")) ==
            QMessageBox::Yes)
            m.blockOpponent();
    });
    v->addWidget(matchBox);

    auto *gameBox = new QGroupBox(tr("Background game"));
    auto *gh = new QHBoxLayout(gameBox);
    m_gameStateLabel = new QLabel;
    m_gameStateLabel->setWordWrap(true);
    auto *restartBtn = new QPushButton(tr("Restart game"));
    gh->addWidget(m_gameStateLabel, 1);
    gh->addWidget(restartBtn);
    connect(restartBtn, &QPushButton::clicked, this, [this] { m.restartGame(); });
    v->addWidget(gameBox);
    v->addStretch();
    return page;
}

// ------------------------------------------------------------------------------------------
// Lobbies

QWidget *MainWindow::createLobbiesTab()
{
    auto *page = new QWidget;
    auto *h = new QHBoxLayout(page);

    auto *left = new QVBoxLayout;
    m_lobbyList = new QTreeWidget;
    m_lobbyList->setHeaderLabels({tr("Host"), tr("Guest"), tr("Type"), tr("Stage")});
    m_lobbyList->setRootIsDecorated(false);
    m_lobbyList->header()->setSectionResizeMode(0, QHeaderView::Stretch);
    left->addWidget(m_lobbyList, 1);
    auto *filters = new QHBoxLayout;
    m_onlyOpen = new QCheckBox(tr("Only open lobbies"));
    m_onlyOpen->setChecked(m_settings.onlyOpenLobbies);
    m_showPrivate = new QCheckBox(tr("Show private lobbies"));
    m_showPrivate->setChecked(m_settings.showPrivateLobbies);
    auto *refreshBtn = new QPushButton(tr("Refresh"));
    auto *joinBtn = new QPushButton(tr("Join selected"));
    filters->addWidget(m_onlyOpen);
    filters->addWidget(m_showPrivate);
    filters->addStretch();
    filters->addWidget(refreshBtn);
    filters->addWidget(joinBtn);
    left->addLayout(filters);
    h->addLayout(left, 3);

    connect(m_onlyOpen, &QCheckBox::toggled, this, [this](bool on) {
        m_settings.onlyOpenLobbies = on;
        m_settings.save();
        refreshLobbyList();
    });
    connect(m_showPrivate, &QCheckBox::toggled, this, [this](bool on) {
        m_settings.showPrivateLobbies = on;
        m_settings.save();
        m.requestLobbies(true);
    });
    connect(refreshBtn, &QPushButton::clicked, this, [this] { m.requestLobbies(true); });
    auto join = [this] {
        QTreeWidgetItem *item = m_lobbyList->currentItem();
        if (!item)
            return;
        const QJsonObject l = item->data(0, Qt::UserRole).toJsonObject();
        QString code;
        if (l.value("private").toBool() || !l.value("public").toBool(true))
            code = m_joinCode->text();
        m.joinLobby(l.value("id").toVariant().toString(), code);
    };
    connect(joinBtn, &QPushButton::clicked, this, join);
    connect(m_lobbyList, &QTreeWidget::itemDoubleClicked, this, join);

    auto *right = new QVBoxLayout;
    auto *create = new QGroupBox(tr("Create"));
    auto *cv = new QVBoxLayout(create);
    auto *pub = new QPushButton(tr("Public lobby"));
    auto *priv = new QPushButton(tr("Private lobby (with code)"));
    auto *ranked = new QPushButton(tr("Ranked lobby"));
    cv->addWidget(pub);
    cv->addWidget(priv);
    cv->addWidget(ranked);
    connect(pub, &QPushButton::clicked, this, [this] { m.createLobby(true, false); });
    connect(priv, &QPushButton::clicked, this, [this] { m.createLobby(false, false); });
    connect(ranked, &QPushButton::clicked, this, [this] { m.createLobby(true, true); });
    right->addWidget(create);

    auto *code = new QGroupBox(tr("Join with a code"));
    auto *ch = new QHBoxLayout(code);
    m_joinCode = new QLineEdit;
    m_joinCode->setPlaceholderText(tr("CODE"));
    auto *codeBtn = new QPushButton(tr("Join"));
    ch->addWidget(m_joinCode);
    ch->addWidget(codeBtn);
    connect(codeBtn, &QPushButton::clicked, this, [this] { m.joinByCode(m_joinCode->text()); });
    right->addWidget(code);

    auto *current = new QGroupBox(tr("Your lobby"));
    auto *lv = new QVBoxLayout(current);
    m_lobbyLabel = new QLabel;
    m_lobbyLabel->setWordWrap(true);
    m_lobbyLabel->setTextInteractionFlags(Qt::TextSelectableByMouse);
    m_lobbyStage = new QComboBox;
    fillStages(m_lobbyStage);
    m_lobbyReady = new QPushButton(tr("READY"));
    m_lobbyLeave = new QPushButton(tr("Leave lobby"));
    lv->addWidget(m_lobbyLabel);
    lv->addWidget(new QLabel(tr("Stage (host):")));
    lv->addWidget(m_lobbyStage);
    lv->addWidget(m_lobbyReady);
    lv->addWidget(m_lobbyLeave);
    connect(m_lobbyStage, &QComboBox::activated, this, [this] {
        m.setLobbyStage(m_lobbyStage->currentData().toInt());
    });
    connect(m_lobbyReady, &QPushButton::clicked, this, [this] { m.acceptMatch(); });
    connect(m_lobbyLeave, &QPushButton::clicked, this, [this] { m.declineOrLeave(); });
    right->addWidget(current);
    right->addStretch();
    h->addLayout(right, 2);
    return page;
}

void MainWindow::refreshLobbyList()
{
    m_shownLobbies = m.lobbies;
    const QString selectedId = m_lobbyList->currentItem()
                                   ? m_lobbyList->currentItem()->data(0, Qt::UserRole).toJsonObject().value("id").toVariant().toString()
                                   : QString();
    m_lobbyList->clear();
    for (const QJsonValue &v : m.lobbies) {
        const QJsonObject l = v.toObject();
        const bool full = !l.value("guest").toObject().isEmpty();
        if (m_onlyOpen->isChecked() && full)
            continue;
        auto *item = new QTreeWidgetItem(m_lobbyList);
        item->setText(0, playerText(l.value("host").toObject()));
        item->setText(1, playerText(l.value("guest").toObject()));
        QStringList type;
        type << (l.value("ranked").toBool() ? tr("ranked") : tr("player"));
        if (l.value("private").toBool() || !l.value("public").toBool(true))
            type << tr("private");
        item->setText(2, type.join(", "));
        const int stage = l.value("stage").toInt(-1);
        QString stageName = tr("Random");
        for (const auto &s : GameData::stages())
            if (s.gameId == stage)
                stageName = QString::fromUtf8(s.name);
        item->setText(3, stageName);
        item->setData(0, Qt::UserRole, l);
        if (l.value("id").toVariant().toString() == selectedId)
            m_lobbyList->setCurrentItem(item);
    }
    if (m_lobbyList->topLevelItemCount() == 0) {
        auto *item = new QTreeWidgetItem(m_lobbyList);
        item->setText(0, tr("No lobbies here yet. Create one on the right."));
        item->setFlags(Qt::NoItemFlags);
    }
}

// ------------------------------------------------------------------------------------------
// Practice

QWidget *MainWindow::createPracticeTab()
{
    auto *page = new QWidget;
    auto *f = new QFormLayout(page);
    m_practiceChar = new QComboBox;
    fillCharacters(m_practiceChar, true);
    m_practiceOpponent = new QComboBox;
    fillCharacters(m_practiceOpponent, true);
    m_practiceStage = new QComboBox;
    fillStages(m_practiceStage);
    m_practiceFrameData = new QCheckBox(tr("Show frame data"));
    m_practiceButton = new QPushButton;
    m_practiceButton->setMinimumHeight(44);
    f->addRow(tr("You"), m_practiceChar);
    f->addRow(tr("Opponent"), m_practiceOpponent);
    f->addRow(tr("Stage"), m_practiceStage);
    f->addRow(QString(), m_practiceFrameData);
    f->addRow(QString(), m_practiceButton);
    auto *note = new QLabel(tr("Practice runs a second game process. It is stopped automatically "
                               "when a match is found."));
    note->setWordWrap(true);
    f->addRow(note);

    selectData(m_practiceChar, m_settings.practiceCharacter);
    selectData(m_practiceOpponent, m_settings.practiceOpponent);
    selectData(m_practiceStage, m_settings.practiceStage);
    m_practiceFrameData->setChecked(m_settings.practiceFrameData);

    connect(m_practiceButton, &QPushButton::clicked, this, [this] {
        if (m.practiceRunning()) {
            m.stopPractice();
            return;
        }
        m_settings.practiceCharacter = m_practiceChar->currentData().toInt();
        m_settings.practiceOpponent = m_practiceOpponent->currentData().toInt();
        m_settings.practiceStage = m_practiceStage->currentData().toInt();
        m_settings.practiceFrameData = m_practiceFrameData->isChecked();
        m_settings.save();
        if (!m.startPractice())
            QMessageBox::information(this, tr("Practice"),
                                     tr("Practice could not start (is the game built? is a match running?)."));
    });
    return page;
}

// ------------------------------------------------------------------------------------------
// Leaderboard, history, block list

QWidget *MainWindow::createLeaderboardTab()
{
    auto *page = new QWidget;
    auto *v = new QVBoxLayout(page);
    auto *top = new QHBoxLayout;
    m_boardRegion = new QComboBox;
    m_boardRegion->addItem(tr("World"), QString());
    for (const auto &r : GameData::regions())
        m_boardRegion->addItem(QString::fromUtf8(r.label), QString::fromLatin1(r.code));
    selectData(m_boardRegion, m_settings.boardRegion);
    auto *refreshBtn = new QPushButton(tr("Refresh"));
    top->addWidget(new QLabel(tr("Region")));
    top->addWidget(m_boardRegion);
    top->addWidget(refreshBtn);
    top->addStretch();
    v->addLayout(top);
    auto request = [this] {
        m_settings.boardRegion = m_boardRegion->currentData().toString();
        m_settings.save();
        m.requestLeaderboard(m_settings.boardRegion);
    };
    connect(m_boardRegion, &QComboBox::activated, this, request);
    connect(refreshBtn, &QPushButton::clicked, this, request);

    m_board = new QTreeWidget;
    m_board->setHeaderLabels({"#", tr("Name"), tr("Character"), tr("Rank"), tr("MMR"), tr("Region")});
    m_board->setRootIsDecorated(false);
    m_board->header()->setSectionResizeMode(1, QHeaderView::Stretch);
    v->addWidget(m_board, 3);
    m_boardInfo = new QLabel(tr("Players by the MMR of their best character. The MMR is per character "
                                "and moves only in ranked matches and ranked lobbies."));
    m_boardInfo->setWordWrap(true);
    v->addWidget(m_boardInfo);

    auto *hist = new QHBoxLayout;
    m_historyName = new QLineEdit;
    m_historyName->setPlaceholderText(tr("Player name (double-click a row above)"));
    auto *histBtn = new QPushButton(tr("Match history"));
    hist->addWidget(m_historyName);
    hist->addWidget(histBtn);
    v->addLayout(hist);
    connect(histBtn, &QPushButton::clicked, this, [this] { m.requestHistory(m_historyName->text().trimmed()); });
    connect(m_board, &QTreeWidget::itemDoubleClicked, this, [this](QTreeWidgetItem *item) {
        m_historyName->setText(item->text(1));
        m.requestHistory(item->text(1));
    });
    m_history = new QTreeWidget;
    m_history->setHeaderLabels({tr("Player"), tr("Match (raw)")});
    m_history->setRootIsDecorated(false);
    v->addWidget(m_history, 2);

    auto *blocks = new QHBoxLayout;
    m_blocks = new QTreeWidget;
    m_blocks->setHeaderLabels({tr("Blocked players")});
    m_blocks->setRootIsDecorated(false);
    m_blocks->setMaximumHeight(110);
    auto *unblockBtn = new QPushButton(tr("Unblock"));
    blocks->addWidget(m_blocks, 1);
    blocks->addWidget(unblockBtn, 0, Qt::AlignTop);
    v->addLayout(blocks);
    connect(unblockBtn, &QPushButton::clicked, this, [this] {
        if (QTreeWidgetItem *item = m_blocks->currentItem()) {
            m.unblock(item->data(0, Qt::UserRole).toInt());
            m.requestBlockList();
        }
    });
    return page;
}

void MainWindow::refreshLeaderboard()
{
    m_shownLeaderboard = m.leaderboard;
    m_board->clear();
    const QJsonArray players = m.leaderboard.value("players").toArray();
    int place = m.leaderboard.value("top").toInt(1);
    if (place < 1)
        place = 1;
    for (const QJsonValue &v : players) {
        const QJsonObject p = v.toObject();
        auto *item = new QTreeWidgetItem(m_board);
        item->setText(0, QString::number(p.value("place").toInt(place++)));
        item->setText(1, p.value("name").toString());
        item->setText(2, GameData::characterName(p.value("char").toInt()));
        item->setText(3, p.value("rank_name").toString());
        item->setText(4, QString::number(p.value("elo").toInt()));
        item->setText(5, p.value("region").toString());
    }
    QString info = tr("%1 players").arg(m.leaderboard.value("total").toInt(players.size()));
    if (m.leaderboard.contains("you"))
        info += tr("  ·  you: %1").arg(compact(m.leaderboard.value("you")));
    if (m.leaderboard.contains("updated"))
        info += tr("  ·  updated %1").arg(compact(m.leaderboard.value("updated")));
    m_boardInfo->setText(info);

    m_blocks->clear();
    for (const QJsonValue &v : m.blockList) {
        const QJsonObject b = v.toObject();
        auto *item = new QTreeWidgetItem(m_blocks);
        item->setText(0, b.value("name").toString());
        item->setData(0, Qt::UserRole, b.value("id").toInt());
    }
}

// ------------------------------------------------------------------------------------------
// Profile and settings

QWidget *MainWindow::createProfileTab()
{
    auto *inner = new QWidget;
    auto *grid = new QHBoxLayout(inner);

    auto *fighter = new QGroupBox(tr("Fighter and matchmaking"));
    auto *f = new QFormLayout(fighter);
    m_name = new QLineEdit;
    m_name->setMaxLength(15);
    m_char = new QComboBox;
    fillCharacters(m_char, false);
    m_costume = new QComboBox;
    m_side = new QComboBox;
    m_side->addItems({tr("Any"), tr("Left (1P)"), tr("Right (2P)")});
    m_region = new QComboBox;
    for (const auto &r : GameData::regions())
        m_region->addItem(QString::fromUtf8(r.label), QString::fromLatin1(r.code));
    m_regionLock = new QCheckBox(tr("Only my region"));
    m_strict = new QCheckBox(tr("Strict ping limit"));
    m_delay = new QSpinBox;
    m_delay->setRange(0, 8);
    m_maxPing = new QSpinBox;
    m_maxPing->setRange(30, 400);
    m_maxPing->setSingleStep(10);
    m_maxPing->setSuffix(" ms");
    m_port = new QSpinBox;
    m_port->setRange(1024, 65535);
    m_sound = new QComboBox;
    m_sound->addItems({tr("Off"), tr("Beep"), tr("Own .wav file")});
    f->addRow(tr("Guest name"), m_name);
    f->addRow(tr("Character"), m_char);
    f->addRow(tr("Costume"), m_costume);
    f->addRow(tr("Side"), m_side);
    f->addRow(tr("Region"), m_region);
    f->addRow(QString(), m_regionLock);
    f->addRow(QString(), m_strict);
    f->addRow(tr("Input delay (frames)"), m_delay);
    f->addRow(tr("Max ping"), m_maxPing);
    f->addRow(tr("Game UDP port"), m_port);
    f->addRow(tr("Sound on match"), m_sound);
    connect(m_char, &QComboBox::currentIndexChanged, this, &MainWindow::fillCostumes);

    auto *right = new QVBoxLayout;
    auto *gfx = new QGroupBox(tr("Game"));
    auto *g = new QFormLayout(gfx);
    m_fullscreen = new QCheckBox(tr("Fullscreen"));
    m_borderless = new QCheckBox(tr("Borderless window"));
    m_blur = new QCheckBox(tr("Motion blur"));
    m_vibration = new QCheckBox(tr("Vibration"));
    m_stageMusic = new QCheckBox(tr("Stage music"));
    m_smallShadows = new QCheckBox(tr("Small shadows"));
    m_resScale = new QSpinBox;
    m_resScale->setRange(1, 3);
    m_resScale->setSuffix("x");
    m_render3d = new QComboBox;
    m_render3d->addItems({"1024x576", "768x432", "640x360"});
    m_gpu = new QComboBox;
    m_gpu->addItem(tr("Default"), QString());
    for (const QString &a : Platform::graphicsAdapters())
        if (!a.isEmpty())
            m_gpu->addItem(a, a);
    m_padBackend = new QComboBox;
    m_padBackend->addItem("SDL", "sdl");
    m_padBackend->addItem("Windows joystick (mmjoystick)", "mmjoystick");
    g->addRow(m_fullscreen);
    g->addRow(m_borderless);
    g->addRow(m_blur);
    g->addRow(m_vibration);
    g->addRow(m_stageMusic);
    g->addRow(m_smallShadows);
    g->addRow(tr("Resolution scale"), m_resScale);
    g->addRow(tr("3D resolution"), m_render3d);
    g->addRow(tr("Graphics card"), m_gpu);
    g->addRow(tr("Gamepad"), m_padBackend);
    auto *gnote = new QLabel(tr("Blur, 3D resolution and small shadows change the game's state "
                                "hash: with them changed, the server can't check that both games match."));
    gnote->setWordWrap(true);
    g->addRow(gnote);
    right->addWidget(gfx);

    auto *keys = new QGroupBox(tr("Keyboard"));
    auto *kv = new QVBoxLayout(keys);
    m_keys = new QComboBox;
    m_keys->addItems({tr("Controller only"), tr("WASD + U I J K"), tr("Arrows + numpad"), tr("Custom (below)")});
    kv->addWidget(m_keys);
    auto *kg = new QGridLayout;
    int row = 0;
    for (const auto &a : GameData::keyActions()) {
        const QString key = QStringLiteral("kb_") + a.id;
        auto *btn = new KeyCaptureButton(Settings::intValue(key, a.defaultVk));
        connect(btn, &KeyCaptureButton::keyChanged, this, [key](int vk) { Settings::setIntValue(key, vk); });
        kg->addWidget(new QLabel(QString::fromUtf8(a.label)), row / 2, (row % 2) * 2);
        kg->addWidget(btn, row / 2, (row % 2) * 2 + 1);
        ++row;
    }
    kv->addLayout(kg);
    right->addWidget(keys);

    auto *buttons = new QHBoxLayout;
    auto *save = new QPushButton(tr("Save"));
    auto *saveRestart = new QPushButton(tr("Save and restart game"));
    buttons->addStretch();
    buttons->addWidget(save);
    buttons->addWidget(saveRestart);
    right->addLayout(buttons);
    right->addStretch();
    connect(save, &QPushButton::clicked, this, &MainWindow::saveProfile);
    connect(saveRestart, &QPushButton::clicked, this, [this] {
        saveProfile();
        m.restartGame();
    });

    grid->addWidget(fighter, 1);
    grid->addLayout(right, 1);

    auto *scroll = new QScrollArea;
    scroll->setWidgetResizable(true);
    scroll->setWidget(inner);
    return scroll;
}

void MainWindow::fillCostumes()
{
    const int c = m_char->currentData().toInt();
    m_costume->clear();
    m_costume->addItem(tr("Costume 1"), 0);
    if (c != GameData::kKuma && c != GameData::kPanda) {
        m_costume->addItem(tr("Costume 2"), 1);
        if (GameData::hasThirdCostume(c))
            m_costume->addItem(tr("Costume 3"), 2);
    }
    selectData(m_costume, m_settings.costumeFor(c));
}

void MainWindow::loadProfileWidgets()
{
    const Settings &s = m_settings;
    m_name->setText(s.name);
    selectData(m_char, s.character);
    fillCostumes();
    m_side->setCurrentIndex(qBound(0, s.side, 2));
    selectData(m_region, s.region);
    m_regionLock->setChecked(s.regionLock);
    m_strict->setChecked(s.strictMatchmaking);
    m_delay->setValue(s.delay);
    m_maxPing->setValue(s.maxPing);
    m_port->setValue(s.gamePort);
    m_sound->setCurrentIndex(qBound(0, s.matchSoundMode, 2));
    m_keys->setCurrentIndex(qBound(0, s.keyboardLayout, 3));
    m_fullscreen->setChecked(s.fullscreen);
    m_borderless->setChecked(s.borderless);
    m_blur->setChecked(s.blur);
    m_vibration->setChecked(s.vibration);
    m_stageMusic->setChecked(s.stageMusic);
    m_smallShadows->setChecked(s.smallShadows);
    m_resScale->setValue(s.resolutionScale);
    m_render3d->setCurrentIndex(qBound(0, s.render3d, 2));
    selectData(m_gpu, s.gpu);
    selectData(m_padBackend, s.padBackend);
}

void MainWindow::saveProfile()
{
    Settings &s = m_settings;
    s.name = m_name->text().trimmed();
    s.character = m_char->currentData().toInt();
    s.setCostumeFor(s.character, m_costume->currentData().toInt());
    s.side = m_side->currentIndex();
    s.region = m_region->currentData().toString();
    s.regionLock = m_regionLock->isChecked();
    s.strictMatchmaking = m_strict->isChecked();
    s.delay = m_delay->value();
    s.maxPing = m_maxPing->value();
    s.gamePort = m_port->value();
    s.matchSoundMode = m_sound->currentIndex();
    if (s.matchSoundMode == 2) {
        const QString wav = QFileDialog::getOpenFileName(this, tr("Sound"), s.matchSoundFile, "*.wav");
        if (!wav.isEmpty())
            s.matchSoundFile = wav;
    }
    s.keyboardLayout = m_keys->currentIndex();
    s.fullscreen = m_fullscreen->isChecked();
    s.borderless = m_borderless->isChecked();
    s.blur = m_blur->isChecked();
    s.vibration = m_vibration->isChecked();
    s.stageMusic = m_stageMusic->isChecked();
    s.smallShadows = m_smallShadows->isChecked();
    s.resolutionScale = m_resScale->value();
    s.render3d = m_render3d->currentIndex();
    s.gpu = m_gpu->currentData().toString();
    s.padBackend = m_padBackend->currentData().toString();
    s.save();
    m.sendProfile();
    Log::info("settings saved");
}

// ------------------------------------------------------------------------------------------
// Build

QWidget *MainWindow::createBuildTab()
{
    auto *page = new QWidget;
    auto *v = new QVBoxLayout(page);
    auto *intro = new QLabel(tr("The game is built from your own Tekken 6 (Xbox 360) disc image by the "
                                "original project's builder\\build_native.py, which this launcher just runs."));
    intro->setWordWrap(true);
    v->addWidget(intro);
    auto *src = new QHBoxLayout;
    m_buildSource = new QLineEdit(m_settings.builtFrom);
    m_buildSource->setPlaceholderText(tr("ISO file or extracted folder"));
    auto *browseIso = new QPushButton(tr("ISO…"));
    auto *browseDir = new QPushButton(tr("Folder…"));
    src->addWidget(m_buildSource, 1);
    src->addWidget(browseIso);
    src->addWidget(browseDir);
    v->addLayout(src);
    connect(browseIso, &QPushButton::clicked, this, [this] {
        const QString f = QFileDialog::getOpenFileName(this, tr("Tekken 6 disc image"), QString(),
                                                       tr("Disc images (*.iso);;All files (*)"));
        if (!f.isEmpty())
            m_buildSource->setText(QDir::toNativeSeparators(f));
    });
    connect(browseDir, &QPushButton::clicked, this, [this] {
        const QString d = QFileDialog::getExistingDirectory(this, tr("Extracted game folder"));
        if (!d.isEmpty())
            m_buildSource->setText(QDir::toNativeSeparators(d));
    });

    auto *btns = new QHBoxLayout;
    m_buildButton = new QPushButton(tr("BUILD GAME"));
    auto *updateBtn = new QPushButton(tr("Update build"));
    auto *relinkBtn = new QPushButton(tr("Relink"));
    m_buildCancel = new QPushButton(tr("Cancel"));
    btns->addWidget(m_buildButton);
    btns->addWidget(updateBtn);
    btns->addWidget(relinkBtn);
    btns->addStretch();
    btns->addWidget(m_buildCancel);
    v->addLayout(btns);
    m_buildState = new QLabel;
    m_buildProgress = new QProgressBar;
    m_buildProgress->setRange(0, 100);
    m_buildLog = new QPlainTextEdit;
    m_buildLog->setReadOnly(true);
    m_buildLog->setMaximumBlockCount(5000);
    v->addWidget(m_buildState);
    v->addWidget(m_buildProgress);
    v->addWidget(m_buildLog, 1);

    auto run = [this](const QString &arg) {
        if (!m_builder->isAvailable()) {
            QMessageBox::information(this, tr("Build"),
                                     tr("builder\\build_native.py or Python was not found next to the launcher."));
            return;
        }
        m.stopPractice();
        m_buildLog->clear();
        m_buildProgress->setValue(0);
        if (!m_builder->start(arg))
            m_buildState->setText(tr("The builder is already running."));
    };
    connect(m_buildButton, &QPushButton::clicked, this, [this, run] {
        if (m_buildSource->text().trimmed().isEmpty())
            return;
        m_settings.builtFrom = m_buildSource->text().trimmed();
        m_settings.save();
        run(m_settings.builtFrom);
    });
    connect(updateBtn, &QPushButton::clicked, this, [run] { run("--update"); });
    connect(relinkBtn, &QPushButton::clicked, this, [run] { run("--relink"); });
    connect(m_buildCancel, &QPushButton::clicked, m_builder, &Builder::cancel);
    connect(m_builder, &Builder::step, this, [this](const QString &t) { m_buildState->setText(t); });
    connect(m_builder, &Builder::progress, m_buildProgress, &QProgressBar::setValue);
    connect(m_builder, &Builder::line, m_buildLog, &QPlainTextEdit::appendPlainText);
    connect(m_builder, &Builder::finished, this, [this](bool ok, const QString &msg) {
        m_buildState->setText(ok ? tr("Done: %1").arg(msg) : tr("Failed: %1").arg(msg));
        if (ok) {
            m_buildProgress->setValue(100);
            m.restartGame();
        }
        refresh();
    });
    return page;
}

// ------------------------------------------------------------------------------------------
// Update

QWidget *MainWindow::createUpdateTab()
{
    auto *page = new QWidget;
    auto *v = new QVBoxLayout(page);
    auto *note = new QLabel(tr("Checks the original project's GitHub releases. Installing a release "
                               "overwrites files in this folder with the ORIGINAL launcher's files "
                               "(not this rebuild) - see README."));
    note->setWordWrap(true);
    v->addWidget(note);
    m_updateLabel = new QLabel(tr("This launcher reports version %1.").arg(Updater::currentVersion()));
    m_updateLabel->setWordWrap(true);
    auto *checkBtn = new QPushButton(tr("Check for updates"));
    m_updateInstall = new QPushButton(tr("Download and install"));
    m_updateInstall->setEnabled(false);
    m_updateProgress = new QProgressBar;
    m_updateProgress->setRange(0, 100);
    v->addWidget(m_updateLabel);
    auto *h = new QHBoxLayout;
    h->addWidget(checkBtn);
    h->addWidget(m_updateInstall);
    h->addStretch();
    v->addLayout(h);
    v->addWidget(m_updateProgress);
    v->addStretch();

    connect(checkBtn, &QPushButton::clicked, m_updater, &Updater::check);
    connect(m_updateInstall, &QPushButton::clicked, this, [this] {
        if (QMessageBox::question(this, tr("Update"),
                                  tr("This replaces files in the package folder with the original "
                                     "release's files. Continue?")) == QMessageBox::Yes)
            m_updater->downloadAndInstall();
    });
    connect(m_updater, &Updater::checked, this, [this](bool available, const QString &version, const QString &notes) {
        m_updateInstall->setEnabled(available);
        m_updateLabel->setText(available ? tr("Version %1 is available.\n\n%2").arg(version, notes)
                                         : tr("No newer release (latest: %1).").arg(version));
    });
    connect(m_updater, &Updater::progress, m_updateProgress, &QProgressBar::setValue);
    connect(m_updater, &Updater::failed, this, [this](const QString &msg) { m_updateLabel->setText(msg); });
    connect(m_updater, &Updater::installed, this, [this](const QString &version) {
        QMessageBox::information(this, tr("Update"), tr("Installed %1. The launcher will now restart.").arg(version));
        QProcess::startDetached(QCoreApplication::applicationFilePath(), QCoreApplication::arguments().mid(1));
        close();
    });
    return page;
}

// ------------------------------------------------------------------------------------------
// Log

QWidget *MainWindow::createLogTab()
{
    auto *page = new QWidget;
    auto *v = new QVBoxLayout(page);
    m_log = new QPlainTextEdit;
    m_log->setReadOnly(true);
    m_log->setMaximumBlockCount(20000);
    QFont mono("Consolas");
    mono.setStyleHint(QFont::Monospace);
    m_log->setFont(mono);
    v->addWidget(m_log, 1);
    m_logTraffic = new QCheckBox(tr("Show lobby traffic (>> sent, << received)"));
    m_logTraffic->setChecked(true);
    v->addWidget(m_logTraffic);
    auto *h = new QHBoxLayout;
    m_rawJson = new QLineEdit;
    m_rawJson->setFont(mono);
    m_rawJson->setPlaceholderText(R"({"t":"leaderboard","region":"EU"}   - send any JSON to the lobby server)");
    auto *sendBtn = new QPushButton(tr("Send"));
    auto *clearBtn = new QPushButton(tr("Clear"));
    h->addWidget(m_rawJson, 1);
    h->addWidget(sendBtn);
    h->addWidget(clearBtn);
    v->addLayout(h);
    connect(sendBtn, &QPushButton::clicked, this, &MainWindow::sendRawJson);
    connect(m_rawJson, &QLineEdit::returnPressed, this, &MainWindow::sendRawJson);
    connect(clearBtn, &QPushButton::clicked, m_log, &QPlainTextEdit::clear);
    return page;
}

void MainWindow::appendLog(const QString &line)
{
    if (!m_logTraffic->isChecked() && (line.contains(" >> ") || line.contains(" << ")))
        return;
    m_log->appendPlainText(line);
}

void MainWindow::sendRawJson()
{
    QJsonParseError err;
    const QJsonDocument doc = QJsonDocument::fromJson(m_rawJson->text().toUtf8(), &err);
    if (!doc.isObject()) {
        appendLog(tr("not a JSON object: %1").arg(err.errorString()));
        return;
    }
    if (!m.sendRaw(doc.object()))
        appendLog(tr("not connected"));
    else
        m_rawJson->clear();
}

// ------------------------------------------------------------------------------------------
// Redraw from state

void MainWindow::refresh()
{
    // Header: connection and account.
    QString head;
    if (!m.connected)
        head = tr("<b style='color:#b00'>Connecting to the lobby server…</b>");
    else if (!m.loggedIn)
        head = tr("<b>Connected</b> - log in or play as guest");
    else
        head = tr("<b>%1</b>%2  ·  %3 online").arg(m.accountName.toHtmlEscaped(), m.guest ? tr(" (guest)") : QString())
                   .arg(m.onlinePlayers);
    if (!m.upnpSummary.isEmpty())
        head += "  ·  <span style='color:#666'>UPnP: " + m.upnpSummary.toHtmlEscaped() + "</span>";
    m_header->setText(head);
    m_notice->setText(m.notice);
    m_notice->setVisible(!m.notice.isEmpty());

    // Account boxes.
    m_loginBox->setVisible(m.connected && !m.loggedIn);
    m_accountBox->setVisible(m.loggedIn);
    if (m.loggedIn) {
        const QString rankName = m.rankNames.at(m.rank).toString();
        m_accountLabel->setText(m.guest ? tr("Guest <b>%1</b> - ranked needs an account").arg(m.accountName.toHtmlEscaped())
                                        : tr("<b>%1</b>  ·  %2  ·  MMR %3  ·  %4 games, %5 wins")
                                              .arg(m.accountName.toHtmlEscaped(),
                                                   rankName.isEmpty() ? tr("rank %1").arg(m.rank) : rankName)
                                              .arg(m.elo).arg(m.games).arg(m.wins));
    }

    // Matchmaking.
    const bool busy = m.inMatch || m.handshaking || m.inLobby;
    const bool canSearch = m.loggedIn && !m.searching && !busy && m.gameReady;
    m_rankedButton->setEnabled(canSearch && !m.guest);
    m_playerButton->setEnabled(canSearch);
    m_cancelButton->setVisible(m.searching);
    if (m.searching)
        m_rankedButton->setText(m.searchingRanked ? tr("SEARCHING (ranked)…") : tr("RANKED MATCH"));
    else
        m_rankedButton->setText(tr("RANKED MATCH"));
    m_playerButton->setText(m.searching && !m.searchingRanked ? tr("SEARCHING…") : tr("PLAYER MATCH"));

    // Match panel.
    const QJsonObject p1 = m.match.value("p1").toObject(), p2 = m.match.value("p2").toObject();
    const bool showMatch = m.handshaking || m.confirmPending || m.inMatch;
    m_vsLabel->setText(showMatch ? playerText(p1) + "\n   VS\n" + playerText(p2) : QString());
    m_statusLabel->setText(m.searching ? tr("Searching for an opponent…") : m.statusLine);
    m_infoLabel->setText(m.infoText);

    QString countdown;
    if (m.confirmPending) {
        const qint64 left = qMax<qint64>(0, m.confirmMs - m.confirmClock.elapsed());
        countdown = tr("Accept within %1 s  ·  ping %2 ms").arg((left + 999) / 1000).arg(m.confirmPing);
        if (m.accepted)
            countdown += tr("  ·  you accepted");
        if (m.opponentAccepted)
            countdown += tr("  ·  the opponent accepted");
    } else if (m.inMatch && m.nextGameSeconds > 0 && m.nextGameClock.isValid()) {
        const qint64 left = qMax<qint64>(0, m.nextGameSeconds * 1000 - m.nextGameClock.elapsed());
        countdown = tr("Next game: %1 s to press Next game").arg((left + 999) / 1000);
    }
    m_countdownLabel->setText(countdown);

    // Accept / Next game / Leave buttons change meaning with the situation.
    m_acceptButton->setVisible(m.confirmPending || m.inMatch);
    m_leaveButton->setVisible(m.confirmPending || m.inMatch || m.handshaking);
    m_blockButton->setVisible(m.inMatch || m.confirmPending);
    if (m.confirmPending) {
        m_acceptButton->setText(tr("ACCEPT"));
        m_acceptButton->setEnabled(!m.accepted);
        m_leaveButton->setText(tr("Decline"));
        m_leaveButton->setEnabled(!m.accepted);
    } else if (m.inMatch) {
        m_acceptButton->setText(m.setOver ? tr("Back to menu") : tr("NEXT GAME"));
        m_acceptButton->setEnabled(true);
        m_leaveButton->setText(tr("Leave"));
        m_leaveButton->setEnabled(true);
    } else {
        m_leaveButton->setText(tr("Cancel"));
        m_leaveButton->setEnabled(true);
    }

    // Background game.
    QString gameText;
    if (m.gameFailed)
        gameText = tr("The game failed to start twice - see the Log tab, rebuild or press Restart.");
    else if (!QFile::exists(Paths::builtGameExe()))
        gameText = tr("The game is not built yet (Build tab).");
    else if (!m.gameRunning())
        gameText = tr("Not running.");
    else if (!m.gameReady && !m.inMatch)
        gameText = tr("Starting in the background and compiling shaders…");
    else
        gameText = tr("Running: %1").arg(m.game.state.isEmpty() ? tr("(no status yet)") : m.game.state);
    if (!Builder::builtGameIsCurrent() && QFile::exists(Paths::builtGameExe()))
        gameText += tr("  ·  the build is older than this package's builder - update it (Build tab).");
    m_gameStateLabel->setText(gameText);

    // Lobbies.
    if (m.lobbies != m_shownLobbies)
        refreshLobbyList();
    if (m.inLobby) {
        const QJsonObject host = m.lobby.value("host").toObject(), guest = m.lobby.value("guest").toObject();
        QString text = tr("Host: %1\nGuest: %2").arg(playerText(host), playerText(guest));
        if (m.lobby.contains("code"))
            text += tr("\nCode: %1").arg(m.lobby.value("code").toString());
        text += m.lobby.value("ranked").toBool() ? tr("\nRanked") : tr("\nPlayer match");
        m_lobbyLabel->setText(text);
    } else {
        m_lobbyLabel->setText(tr("Not in a lobby."));
    }
    m_lobbyReady->setEnabled(m.inLobby && !m.inMatch && m.gameReady);
    m_lobbyLeave->setEnabled(m.inLobby);
    m_lobbyStage->setEnabled(m.inLobby);

    // Practice.
    m_practiceButton->setText(m.practiceRunning() ? tr("STOP PRACTICE") : tr("START PRACTICE"));
    m_practiceButton->setEnabled(m.practiceRunning() || (!m.inMatch && !m.handshaking));

    // Leaderboard.
    if (m.leaderboard != m_shownLeaderboard || m_blocks->topLevelItemCount() != m.blockList.size())
        refreshLeaderboard();

    // Build.
    m_buildButton->setEnabled(!m_builder->isRunning());
    m_buildCancel->setEnabled(m_builder->isRunning());
}
