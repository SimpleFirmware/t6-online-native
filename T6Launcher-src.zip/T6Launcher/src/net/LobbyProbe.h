#pragma once

#include <QElapsedTimer>
#include <QHostAddress>
#include <QJsonObject>
#include <QObject>
#include <QTimer>
#include <QVector>

class QUdpSocket;

// Connection test inside a lobby, before anyone presses Ready. The server sends "probe" (an id,
// a token and a role) and later "probe_peer" (the other player's addresses). Same idea as
// PeerLink - punch, knock with "hi", measure the ping with "pp"/"pq" - but packets carry
// "probe": id instead of "match": id, and the result is only shown, not reported.
class LobbyProbe : public QObject {
    Q_OBJECT
public:
    explicit LobbyProbe(QObject *parent = nullptr);

    void start(const QJsonObject &probeMessage, quint16 gamePort, const QHostAddress &server);
    void stop();
    void onProbePeer(const QJsonObject &probePeerMessage);

    QString id() const { return m_id; }
    // -2 = testing, -1 = no result, -3 = nothing got through, >= 0 = ping in ms
    int result() const { return m_result; }

signals:
    void changed();

private:
    void tick();
    void onReadyRead();
    void sendJson(const QJsonObject &obj, const QHostAddress &to, quint16 port);

    QUdpSocket *m_socket = nullptr;
    QTimer m_timer;
    QElapsedTimer m_clock;
    QString m_id, m_token;
    int m_role = 0;
    quint16 m_gamePort = 0;
    QHostAddress m_server;
    quint16 m_serverPort = 7701;
    QVector<QPair<QHostAddress, quint16>> m_candidates;
    bool m_seen = false;
    QHostAddress m_peer;
    quint16 m_peerPort = 0;
    int m_ticks = 0;
    int m_samples = 0;
    int m_result = -1;
};
