#pragma once

#include <QJsonObject>
#include <QObject>
#include <QSslCertificate>

class QSslSocket;

// Connection to the lobby server: one JSON object per line, over TLS.
//
// The server uses a self-signed certificate, so normal TLS verification would fail. Instead the
// launcher "pins" it: the connection is accepted only if the server presents exactly the
// certificate built into the program (resources/tls/t6_cert.pem). Anyone else - e.g. someone
// intercepting the connection - is dropped before anything (including the password) is sent.
class LobbyClient : public QObject {
    Q_OBJECT
public:
    explicit LobbyClient(QObject *parent = nullptr);

    void connectToServer();
    void disconnectFromServer();
    bool isConnected() const;

    void send(const QJsonObject &message);

    // Convenience: send({"t": type, ...fields}).
    void send(const QString &type, QJsonObject fields = {});

signals:
    void connected();                         // TLS up and certificate verified
    void message(const QJsonObject &message); // one line from the server
    void disconnected();

private:
    void onReadyRead();
    bool peerIsPinned() const;

    QSslSocket *m_socket = nullptr;
    QSslCertificate m_pinned;
    bool m_tls = true;
    bool m_ready = false;
};
