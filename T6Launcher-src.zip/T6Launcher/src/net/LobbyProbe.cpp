#include "net/LobbyProbe.h"

#include "net/NetUtil.h"

#include <QJsonArray>
#include <QJsonDocument>
#include <QNetworkDatagram>
#include <QUdpSocket>

LobbyProbe::LobbyProbe(QObject *parent) : QObject(parent)
{
    m_timer.setInterval(100);
    connect(&m_timer, &QTimer::timeout, this, &LobbyProbe::tick);
}

void LobbyProbe::start(const QJsonObject &msg, quint16 gamePort, const QHostAddress &server)
{
    stop();
    m_id = msg.value("id").toString();
    m_token = msg.value("token").toString();
    m_role = msg.value("role").toInt();
    m_serverPort = quint16(msg.value("udp_port").toInt(7701));
    m_gamePort = gamePort;
    m_server = server;
    m_candidates.clear();
    m_seen = false;
    m_ticks = m_samples = 0;

    m_socket = new QUdpSocket(this);
    if (!m_socket->bind(QHostAddress::AnyIPv4, gamePort,
                        QUdpSocket::ShareAddress | QUdpSocket::ReuseAddressHint)) {
        stop();
        return;
    }
    connect(m_socket, &QUdpSocket::readyRead, this, &LobbyProbe::onReadyRead);
    m_result = -2;
    m_clock.start();
    m_timer.start();
    emit changed();
}

void LobbyProbe::stop()
{
    m_timer.stop();
    if (m_socket) {
        m_socket->close();
        m_socket->deleteLater();
        m_socket = nullptr;
    }
    m_result = -1;
}

void LobbyProbe::onProbePeer(const QJsonObject &msg)
{
    if (msg.value("id").toString() != m_id)
        return;
    m_candidates.clear();
    const QJsonArray pub = msg.value("public").toArray();
    const QJsonArray loc = msg.value("local").toArray();
    // LAN address only when both players are behind the same router; public address always.
    if (msg.value("same_nat").toBool() && loc.size() == 2)
        m_candidates.append({QHostAddress(loc.at(0).toString()), quint16(loc.at(1).toInt())});
    if (pub.size() == 2)
        m_candidates.append({QHostAddress(pub.at(0).toString()), quint16(pub.at(1).toInt())});
}

void LobbyProbe::sendJson(const QJsonObject &obj, const QHostAddress &to, quint16 port)
{
    if (m_socket && !to.isNull() && port)
        m_socket->writeDatagram(QJsonDocument(obj).toJson(QJsonDocument::Compact), to, port);
}

void LobbyProbe::tick()
{
    if (!m_socket)
        return;
    if (++m_ticks > 120) {
        const int result = m_result >= 0 ? m_result : -3;
        stop();
        m_result = result;
        emit changed();
        return;
    }
    if (m_candidates.isEmpty() && (m_ticks % 2) == 1)
        sendJson({{"t", "punch"},
                  {"token", m_token},
                  {"local", QJsonArray{NetUtil::localIPv4(), int(m_gamePort)}}},
                 m_server, m_serverPort);

    for (const auto &c : std::as_const(m_candidates))
        sendJson({{"t", "hi"}, {"probe", m_id}, {"role", m_role}}, c.first, c.second);

    if (m_seen && m_samples < 6)
        sendJson({{"t", "pp"}, {"probe", m_id}, {"ts", m_clock.elapsed()}}, m_peer, m_peerPort);
}

void LobbyProbe::onReadyRead()
{
    while (m_socket && m_socket->hasPendingDatagrams()) {
        const QNetworkDatagram dg = m_socket->receiveDatagram();
        const QJsonObject msg = QJsonDocument::fromJson(dg.data()).object();
        if (msg.value("probe").toString() != m_id)
            continue;
        const QString type = msg.value("t").toString();
        if (type == "hi") {
            if (msg.value("role").toInt() != m_role && !m_seen) {
                m_seen = true;
                m_peer = QHostAddress(dg.senderAddress().toIPv4Address());
                m_peerPort = quint16(dg.senderPort());
            }
        } else if (type == "pp") {
            sendJson({{"t", "pq"}, {"probe", m_id}, {"ts", msg.value("ts")}}, dg.senderAddress(),
                     quint16(dg.senderPort()));
        } else if (type == "pq") {
            const int rtt = int(m_clock.elapsed() - msg.value("ts").toInteger());
            if (rtt >= 0 && (m_result < 0 || rtt < m_result))
                m_result = rtt;
            if (++m_samples == 1 || m_samples == 6)
                emit changed();
        }
    }
}
