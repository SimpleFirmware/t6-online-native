#include "net/PeerLink.h"

#include "core/Log.h"

#include <QJsonArray>
#include <QJsonDocument>
#include <QNetworkDatagram>
#include <QUdpSocket>

namespace {
constexpr int kTickMs = 100;
constexpr int kGiveUpTicks = 151;        // ~15 s without a ping report
constexpr int kPingSamples = 6;
constexpr int kMaxTicksAfterSeen = 30;
}

PeerLink::PeerLink(QObject *parent) : QObject(parent)
{
    m_timer.setInterval(kTickMs);
    connect(&m_timer, &QTimer::timeout, this, &PeerLink::tick);
}

void PeerLink::start(const Options &options)
{
    stop();
    m_opt = options;
    m_ticks = m_ticksSinceSeen = m_samples = 0;
    m_candidates.clear();
    m_candidatesKnown = m_peerSeen = m_reported = m_peerWifi = m_peerLinux = false;
    m_ping = m_seenPort = -1;
    m_peerAddress = QHostAddress();
    m_peerPort = 0;

    m_socket = new QUdpSocket(this);
    // ShareAddress | ReuseAddressHint, like the original (bind mode 6).
    m_bound = m_socket->bind(QHostAddress::AnyIPv4, m_opt.gamePort,
                             QUdpSocket::ShareAddress | QUdpSocket::ReuseAddressHint);
    connect(m_socket, &QUdpSocket::readyRead, this, &PeerLink::onReadyRead);
    m_clock.start();
    m_timer.start();
}

void PeerLink::stop()
{
    m_timer.stop();
    if (m_socket) {
        m_socket->close();
        m_socket->deleteLater();
        m_socket = nullptr;
    }
}

void PeerLink::setCandidates(const QVector<QPair<QHostAddress, quint16>> &candidates)
{
    m_candidates = candidates;
    m_candidatesKnown = true;
}

void PeerLink::sendJson(const QJsonObject &obj, const QHostAddress &to, quint16 port)
{
    if (m_socket && !to.isNull() && port)
        m_socket->writeDatagram(QJsonDocument(obj).toJson(QJsonDocument::Compact), to, port);
}

void PeerLink::tick()
{
    ++m_ticks;
    if (m_ticks >= kGiveUpTicks && !m_reported) {
        stop();
        emit failed(m_bound ? QStringLiteral("udp_blocked") : QStringLiteral("port_in_use"));
        return;
    }
    if (!m_bound) {
        m_bound = m_socket->bind(QHostAddress::AnyIPv4, m_opt.gamePort,
                                 QUdpSocket::ShareAddress | QUdpSocket::ReuseAddressHint);
        if (!m_bound)
            return;
    }

    // 1. Tell the rendezvous server our public address (every second tick, until it answered
    //    with the opponent's addresses).
    if (!m_candidatesKnown && (m_ticks % 2) == 1)
        sendJson({{"t", "punch"}, {"token", m_opt.token}}, m_opt.server, m_opt.serverUdpPort);

    // 2. Knock on every address the opponent might have.
    QJsonObject hi{{"t", "hi"}, {"match", m_opt.matchId}, {"role", m_opt.role}};
    if (m_opt.wifi)
        hi.insert("wifi", true);
    if (m_opt.underWine)
        hi.insert("linux", true);
    for (const auto &c : std::as_const(m_candidates))
        sendJson(hi, c.first, c.second);

    // 3. Measure the ping once the opponent answered, then report it.
    if (m_peerSeen && !m_reported) {
        sendJson({{"t", "pp"}, {"match", m_opt.matchId}, {"ts", m_clock.elapsed()}}, m_peerAddress,
                 m_peerPort);
        if (m_samples >= kPingSamples || ++m_ticksSinceSeen > kMaxTicksAfterSeen) {
            m_reported = true;
            const bool ok = !(m_opt.queue && m_opt.maxPing != 0 && m_opt.maxPing < m_ping);
            emit sendToServer({{"t", "ping_report"},
                               {"match_id", m_opt.matchId},
                               {"ms", qMax(m_ping, 0)},
                               {"ok", ok}});
            emit pingReported(m_ping, ok);
        }
    }
}

void PeerLink::onReadyRead()
{
    while (m_socket && m_socket->hasPendingDatagrams()) {
        const QNetworkDatagram dg = m_socket->receiveDatagram();
        const QJsonObject msg = QJsonDocument::fromJson(dg.data()).object();
        const QString type = msg.value("t").toString();

        if (type == "seen") {
            // The server's view of our address: "addr": [port, "ip"].
            const QJsonArray addr = msg.value("addr").toArray();
            m_seenPort = addr.at(0).toInt();
        } else if (type == "hi") {
            if (msg.value("match").toString() == m_opt.matchId &&
                msg.value("role").toInt() != m_opt.role && !m_peerSeen) {
                m_peerSeen = true;
                m_ticksSinceSeen = 0;
                m_peerAddress = QHostAddress(dg.senderAddress().toIPv4Address());
                m_peerPort = quint16(dg.senderPort());
                m_peerWifi = msg.value("wifi").toBool();
                m_peerLinux = msg.value("linux").toBool();
                Log::info(QStringLiteral("opponent reachable at %1:%2")
                              .arg(m_peerAddress.toString()).arg(m_peerPort));
                emit opponentSeen();
            }
        } else if (type == "pp") {
            if (msg.value("match").toString() == m_opt.matchId)
                sendJson({{"t", "pq"}, {"match", msg.value("match")}, {"ts", msg.value("ts")}},
                         dg.senderAddress(), quint16(dg.senderPort()));
        } else if (type == "pq") {
            if (msg.value("match").toString() == m_opt.matchId) {
                const int rtt = int(m_clock.elapsed() - msg.value("ts").toInteger());
                if (rtt >= 0 && (m_ping < 0 || rtt < m_ping))
                    m_ping = rtt;
                ++m_samples;
            }
        }
    }
}
