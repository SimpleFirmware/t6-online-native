#include "net/Upnp.h"

#include "core/Log.h"
#include "net/NetUtil.h"

#include <QEventLoop>
#include <QNetworkAccessManager>
#include <QNetworkDatagram>
#include <QNetworkProxy>
#include <QNetworkReply>
#include <QRegularExpression>
#include <QTimer>
#include <QUdpSocket>
#include <QXmlStreamReader>

namespace {

const QHostAddress kSsdpGroup("239.255.255.250");
constexpr quint16 kSsdpPort = 1900;

QString xmlValue(const QByteArray &xml, const QString &tag)
{
    // Matches <tag> or <ns:tag>, like the original's regular expression.
    const QRegularExpression re(QStringLiteral("<(?:\\w+:)?%1>([^<]*)</").arg(tag));
    const auto m = re.match(QString::fromUtf8(xml));
    return m.hasMatch() ? m.captured(1).trimmed() : QString();
}

}  // namespace

Upnp::Upnp(QObject *parent) : QObject(parent), m_http(new QNetworkAccessManager(this))
{
    m_http->setProxy(QNetworkProxy::NoProxy);   // the router is on the LAN
}

Upnp::~Upnp() = default;

void Upnp::forward(quint16 udpPort)
{
    m_port = udpPort;
    if (qEnvironmentVariableIsSet("T6_NO_UPNP")) {
        finish(false, "UPnP: switched off (T6_NO_UPNP)");
        return;
    }

    m_ssdp = new QUdpSocket(this);
    if (!m_ssdp->bind(QHostAddress::AnyIPv4, 0)) {
        finish(false, "UPnP: no UDP socket");
        return;
    }
    connect(m_ssdp, &QUdpSocket::readyRead, this, &Upnp::onSsdpReply);

    for (const char *target : {"urn:schemas-upnp-org:device:InternetGatewayDevice:1",
                               "urn:schemas-upnp-org:device:InternetGatewayDevice:2",
                               "urn:schemas-upnp-org:service:WANIPConnection:1"}) {
        const QByteArray search = QByteArray("M-SEARCH * HTTP/1.1\r\n"
                                             "HOST: 239.255.255.250:1900\r\n"
                                             "MAN: \"ssdp:discover\"\r\n"
                                             "MX: 2\r\n"
                                             "ST: ") + target + "\r\n\r\n";
        m_ssdp->writeDatagram(search, kSsdpGroup, kSsdpPort);
    }

    // Routers answer within MX seconds; then try what was found.
    QTimer::singleShot(2500, this, [this] {
        if (m_ssdp) {
            m_ssdp->deleteLater();
            m_ssdp = nullptr;
        }
        if (m_locations.isEmpty())
            finish(false, "UPnP: no UPnP router answered");
        else
            tryNextLocation();
    });
}

void Upnp::onSsdpReply()
{
    while (m_ssdp && m_ssdp->hasPendingDatagrams()) {
        const QByteArray reply = m_ssdp->receiveDatagram().data();
        for (const QByteArray &line : reply.split('\n')) {
            if (line.toLower().startsWith("location:")) {
                const QString url = QString::fromLatin1(line.mid(9).trimmed());
                if (!m_locations.contains(url)) {
                    m_locations << url;
                    ++m_devicesSeen;
                }
            }
        }
    }
}

void Upnp::tryNextLocation()
{
    if (m_locations.isEmpty()) {
        finish(false, QStringLiteral("UPnP: %1 UPnP device(s), none with a connected WAN service")
                          .arg(m_devicesSeen));
        return;
    }
    const QUrl location(m_locations.takeFirst());
    QNetworkReply *reply = m_http->get(QNetworkRequest(location));
    reply->setProperty("location", location);
    connect(reply, &QNetworkReply::finished, this, [this, reply] {
        reply->deleteLater();
        if (reply->error() != QNetworkReply::NoError) {
            tryNextLocation();
            return;
        }
        onDescription(reply->property("location").toUrl(), reply->readAll());
    });
}

void Upnp::onDescription(const QUrl &location, const QByteArray &xml)
{
    // Walk all <service> elements; take the first WAN connection service.
    QXmlStreamReader reader(xml);
    QString urlBase, serviceType, controlUrl, currentType, currentControl;
    while (!reader.atEnd()) {
        reader.readNext();
        if (reader.isStartElement()) {
            const auto name = reader.name();
            if (name == QLatin1String("URLBase"))
                urlBase = reader.readElementText().trimmed();
            else if (name == QLatin1String("service"))
                currentType.clear(), currentControl.clear();
            else if (name == QLatin1String("serviceType"))
                currentType = reader.readElementText().trimmed();
            else if (name == QLatin1String("controlURL"))
                currentControl = reader.readElementText().trimmed();
        } else if (reader.isEndElement() && reader.name() == QLatin1String("service")) {
            if (serviceType.isEmpty() && (currentType.contains("WANIPConnection") ||
                                          currentType.contains("WANPPPConnection"))) {
                serviceType = currentType;
                controlUrl = currentControl;
            }
        }
    }
    if (serviceType.isEmpty()) {
        tryNextLocation();
        return;
    }

    const QUrl base = urlBase.isEmpty() ? location : QUrl(urlBase);
    m_controlUrl = base.resolved(QUrl(controlUrl));
    m_serviceType = serviceType;
    m_internalClient = localAddressTowards(m_controlUrl.host());
    if (m_internalClient.isEmpty()) {
        finish(false, "UPnP: this PC's address towards the router not found");
        return;
    }

    soap("GetExternalIPAddress", QString(), [this](int, const QByteArray &body) {
        m_externalIp = xmlValue(body, "NewExternalIPAddress");
        const QString args =
            QStringLiteral("<NewRemoteHost></NewRemoteHost><NewExternalPort>%1</NewExternalPort>"
                           "<NewProtocol>UDP</NewProtocol><NewInternalPort>%1</NewInternalPort>"
                           "<NewInternalClient>%2</NewInternalClient><NewEnabled>1</NewEnabled>"
                           "<NewPortMappingDescription>Tekken 6 Online</NewPortMappingDescription>"
                           "<NewLeaseDuration>0</NewLeaseDuration>")
                .arg(m_port)
                .arg(m_internalClient);
        soap("AddPortMapping", args, [this](int status, const QByteArray &body) {
            if (status == 200) {
                m_mapped = true;
                QString line = QStringLiteral("UPnP: UDP %1 forwarded to %2 by the router")
                                   .arg(m_port).arg(m_internalClient);
                if (!m_externalIp.isEmpty()) {
                    line += QStringLiteral(" (its external address %1").arg(m_externalIp);
                    if (NetUtil::isPrivateIPv4(m_externalIp))
                        line += " - private: CGNAT / second router";
                    line += ')';
                }
                finish(true, line);
            } else {
                finish(false, QStringLiteral("UPnP: AddPortMapping: HTTP %1, UPnP error %2 %3")
                                  .arg(status)
                                  .arg(xmlValue(body, "errorCode"), xmlValue(body, "errorDescription")));
            }
        });
    });
}

QNetworkReply *Upnp::soap(const QString &action, const QString &args,
                          std::function<void(int, const QByteArray &)> done)
{
    const QByteArray envelope =
        QStringLiteral("<?xml version=\"1.0\"?><s:Envelope "
                       "xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                       "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body>"
                       "<u:%1 xmlns:u=\"%2\">%3</u:%1></s:Body></s:Envelope>")
            .arg(action, m_serviceType, args)
            .toUtf8();
    QNetworkRequest req(m_controlUrl);
    req.setHeader(QNetworkRequest::ContentTypeHeader, "text/xml; charset=\"utf-8\"");
    req.setRawHeader("SOAPAction", QStringLiteral("\"%1#%2\"").arg(m_serviceType, action).toLatin1());
    req.setTransferTimeout(5000);
    QNetworkReply *reply = m_http->post(req, envelope);
    connect(reply, &QNetworkReply::finished, this, [reply, done] {
        reply->deleteLater();
        if (done)
            done(reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt(), reply->readAll());
    });
    return reply;
}

QString Upnp::localAddressTowards(const QString &host) const
{
    QUdpSocket s;
    s.connectToHost(QHostAddress(host), 1900);
    const QHostAddress local = s.localAddress();
    return local.protocol() == QAbstractSocket::IPv4Protocol ? local.toString() : QString();
}

void Upnp::finish(bool ok, const QString &summary)
{
    m_done = true;
    m_summary = summary;
    Log::info(summary);
    emit finished(ok, summary);
}

void Upnp::removeMapping()
{
    if (!m_mapped)
        return;
    m_mapped = false;
    QNetworkReply *reply =
        soap("DeletePortMapping",
             QStringLiteral("<NewRemoteHost></NewRemoteHost><NewExternalPort>%1</NewExternalPort>"
                            "<NewProtocol>UDP</NewProtocol>")
                 .arg(m_port),
             nullptr);
    QEventLoop loop;
    QTimer::singleShot(1500, &loop, &QEventLoop::quit);
    connect(reply, &QNetworkReply::finished, &loop, &QEventLoop::quit);
    loop.exec();
    if (reply->isRunning())
        reply->abort();
}
