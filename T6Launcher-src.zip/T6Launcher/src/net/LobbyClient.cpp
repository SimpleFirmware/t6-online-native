#include "net/LobbyClient.h"

#include "core/Log.h"
#include "net/NetUtil.h"

#include <QFile>
#include <QJsonDocument>
#include <QSslSocket>

LobbyClient::LobbyClient(QObject *parent) : QObject(parent)
{
    // For experiments with your own server: T6_LOBBY_CERT=path\to\server.pem
    const QString certPath = qEnvironmentVariable("T6_LOBBY_CERT", ":/tls/t6_cert.pem");
    QFile f(certPath);
    if (f.open(QIODevice::ReadOnly))
        m_pinned = QSslCertificate(&f, QSsl::Pem);
    if (m_pinned.isNull())
        Log::info("no pinned lobby certificate loaded - TLS connections will be refused");
}

bool LobbyClient::isConnected() const { return m_socket && m_ready; }

bool LobbyClient::peerIsPinned() const
{
    return !m_pinned.isNull() && m_socket && m_socket->peerCertificate() == m_pinned;
}

void LobbyClient::connectToServer()
{
    disconnectFromServer();

    const NetUtil::ServerAddress server = NetUtil::lobbyServer();
    m_tls = server.tls;
    m_socket = new QSslSocket(this);

    connect(m_socket, &QSslSocket::readyRead, this, &LobbyClient::onReadyRead);
    connect(m_socket, &QSslSocket::disconnected, this, [this] {
        m_ready = false;
        emit disconnected();
    });
    connect(m_socket, &QSslSocket::errorOccurred, this, [this](QAbstractSocket::SocketError) {
        Log::info("lobby connection error: " + m_socket->errorString());
        if (m_socket->state() == QAbstractSocket::UnconnectedState) {
            m_ready = false;
            emit disconnected();
        }
    });

    if (m_tls) {
        // The self-signed certificate always produces TLS errors; ignore them only for the
        // pinned certificate.
        connect(m_socket, &QSslSocket::sslErrors, this, [this](const QList<QSslError> &) {
            if (peerIsPinned())
                m_socket->ignoreSslErrors();
        });
        connect(m_socket, &QSslSocket::encrypted, this, [this] {
            if (!peerIsPinned()) {
                Log::info("lobby server certificate does not match the pinned one - disconnecting");
                m_socket->abort();
                return;
            }
            m_ready = true;
            emit connected();
        });
        Log::info(QStringLiteral("connecting to tls://%1:%2").arg(server.host).arg(server.port));
        m_socket->connectToHostEncrypted(server.host, server.port);
    } else {
        // Plain TCP, only meant for a local test server. The real server refuses logins over
        // an unencrypted connection ("insecure").
        connect(m_socket, &QSslSocket::connected, this, [this] {
            m_ready = true;
            emit connected();
        });
        Log::info(QStringLiteral("connecting to tcp://%1:%2 (unencrypted)").arg(server.host).arg(server.port));
        m_socket->connectToHost(server.host, server.port);
    }
}

void LobbyClient::disconnectFromServer()
{
    m_ready = false;
    if (m_socket) {
        m_socket->disconnect(this);
        m_socket->abort();
        m_socket->deleteLater();
        m_socket = nullptr;
    }
}

void LobbyClient::send(const QJsonObject &message)
{
    if (!isConnected() || m_socket->state() != QAbstractSocket::ConnectedState)
        return;
    const QByteArray line = QJsonDocument(message).toJson(QJsonDocument::Compact) + '\n';
    Log::net(">>", line);
    m_socket->write(line);
}

void LobbyClient::send(const QString &type, QJsonObject fields)
{
    fields.insert("t", type);
    send(fields);
}

void LobbyClient::onReadyRead()
{
    while (m_socket && m_socket->canReadLine()) {
        const QByteArray line = m_socket->readLine();
        Log::net("<<", line);
        const QJsonObject obj = QJsonDocument::fromJson(line).object();
        if (!obj.isEmpty())
            emit message(obj);
    }
}
