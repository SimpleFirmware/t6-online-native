#pragma once

#include <QHostAddress>
#include <QString>

namespace NetUtil {

struct ServerAddress {
    QString host;
    quint16 port = 7700;
    bool tls = true;
};

// The lobby server: T6_LOBBY_SERVER if set (e.g. "tls://myhost:7700" or "tcp://127.0.0.1:7700"
// for your own test server), otherwise the original launcher's server.
ServerAddress lobbyServer();

// Resolves the lobby host to an IPv4 address (it is also the UDP rendezvous server).
QHostAddress resolveIPv4(const QString &host);

// This PC's LAN IPv4 address, sent to the server so two players behind the same router can
// connect directly. "127.0.0.1" if none is found.
QString localIPv4();

// True if the network interface used to reach `server` is Wi-Fi (shown as a lag warning).
bool connectedOverWifi(const QHostAddress &server);

// True for 10.x, 172.16-31.x, 192.168.x and 100.64/10 (CGNAT) addresses.
bool isPrivateIPv4(const QString &address);

// True when running under Wine/Proton (the original sends "linux": true then).
bool runningUnderWine();

}
