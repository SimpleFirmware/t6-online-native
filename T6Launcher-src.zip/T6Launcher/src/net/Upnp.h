#pragma once

#include <QObject>
#include <QStringList>
#include <QUrl>

#include <functional>

class QNetworkAccessManager;
class QNetworkReply;
class QUdpSocket;

// Asks the home router (UPnP "Internet Gateway Device") to forward the game's UDP port to this
// PC, so the opponent's packets get through without the player touching router settings.
//   1. SSDP discovery: multicast M-SEARCH to 239.255.255.250:1900, routers answer with the URL
//      of their description XML;
//   2. read the XML, find the WANIPConnection / WANPPPConnection service's control URL;
//   3. SOAP calls GetExternalIPAddress and AddPortMapping.
// The mapping is removed again (DeletePortMapping) when the launcher closes.
// Set T6_NO_UPNP to skip all of this.
class Upnp : public QObject {
    Q_OBJECT
public:
    explicit Upnp(QObject *parent = nullptr);
    ~Upnp() override;

    void forward(quint16 udpPort);
    void removeMapping();   // blocking for at most ~1.5 s; called on exit

    bool done() const { return m_done; }
    QString summary() const { return m_summary; }   // one line for the log / status bar

signals:
    void finished(bool ok, const QString &summary);

private:
    void onSsdpReply();
    void tryNextLocation();
    void onDescription(const QUrl &location, const QByteArray &xml);
    QNetworkReply *soap(const QString &action, const QString &args,
                        std::function<void(int httpStatus, const QByteArray &body)> done);
    void finish(bool ok, const QString &summary);
    QString localAddressTowards(const QString &host) const;

    QNetworkAccessManager *m_http;
    QUdpSocket *m_ssdp = nullptr;
    QStringList m_locations;
    int m_devicesSeen = 0;
    quint16 m_port = 0;
    QUrl m_controlUrl;
    QString m_serviceType;
    QString m_internalClient;
    QString m_externalIp;
    bool m_mapped = false;
    bool m_done = false;
    QString m_summary;
};
