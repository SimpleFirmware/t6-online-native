#include "net/NetUtil.h"

#include <QHostInfo>
#include <QNetworkInterface>
#include <QUdpSocket>

#ifdef Q_OS_WIN
#include <windows.h>
#endif

namespace NetUtil {

ServerAddress lobbyServer()
{
    ServerAddress out;
    QString spec = qEnvironmentVariable("T6_LOBBY_SERVER");
    if (spec.isEmpty())
        spec = QStringLiteral("tls://130.61.213.14:7700");

    out.tls = spec.startsWith("tls://");
    if (out.tls)
        spec = spec.mid(6);
    else if (spec.startsWith("tcp://"))
        spec = spec.mid(6);

    const int colon = spec.lastIndexOf(':');
    if (colon > 0) {
        out.host = spec.left(colon);
        out.port = spec.mid(colon + 1).toUShort();
    } else {
        out.host = spec;
    }
    return out;
}

QHostAddress resolveIPv4(const QString &host)
{
    QHostAddress direct(host);
    if (!direct.isNull())
        return direct;
    for (const QHostAddress &a : QHostInfo::fromName(host).addresses())
        if (a.protocol() == QAbstractSocket::IPv4Protocol)
            return a;
    return {};
}

QString localIPv4()
{
    for (const QNetworkInterface &iface : QNetworkInterface::allInterfaces()) {
        const auto flags = iface.flags();
        if (!(flags & QNetworkInterface::IsUp) || !(flags & QNetworkInterface::IsRunning) ||
            (flags & QNetworkInterface::IsLoopBack))
            continue;
        for (const QNetworkAddressEntry &entry : iface.addressEntries()) {
            const QHostAddress ip = entry.ip();
            if (ip.protocol() == QAbstractSocket::IPv4Protocol && !ip.isLoopback() &&
                !ip.isLinkLocal())
                return ip.toString();
        }
    }
    return QStringLiteral("127.0.0.1");
}

bool connectedOverWifi(const QHostAddress &server)
{
    // "Connecting" a UDP socket sends nothing; it only makes the OS pick the outgoing interface.
    QUdpSocket probe;
    probe.connectToHost(server, 7701);
    const QHostAddress local = probe.localAddress();
    if (local.isNull())
        return false;
    for (const QNetworkInterface &iface : QNetworkInterface::allInterfaces())
        for (const QNetworkAddressEntry &entry : iface.addressEntries())
            if (entry.ip().isEqual(local))
                return iface.type() == QNetworkInterface::Wifi;
    return false;
}

bool isPrivateIPv4(const QString &address)
{
    bool ok = false;
    const quint32 ip = QHostAddress(address).toIPv4Address(&ok);
    if (!ok || ip == 0)
        return true;
    return (ip >> 24) == 10 || (ip >> 20) == 0xAC1 || (ip >> 16) == 0xC0A8 || (ip >> 22) == 0x191;
}

bool runningUnderWine()
{
#ifdef Q_OS_WIN
    static const bool wine = [] {
        HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
        return ntdll && GetProcAddress(ntdll, "wine_get_version") != nullptr;
    }();
    return wine;
#else
    return false;
#endif
}

}
