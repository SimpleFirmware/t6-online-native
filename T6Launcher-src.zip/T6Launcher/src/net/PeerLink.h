#pragma once

#include <QElapsedTimer>
#include <QHostAddress>
#include <QJsonObject>
#include <QObject>
#include <QTimer>
#include <QVector>

class QUdpSocket;

// The UDP handshake between the two players right after the server pairs them ("start").
//
// Both launchers bind the game's UDP port and:
//  1. send {"t":"punch","token":...} to the server's UDP port, so the server learns the public
//     address/port their router uses ("seen" comes back) and can tell each side where the
//     other one is ("peer" over the TCP connection);
//  2. send {"t":"hi","match":id,"role":n} to every candidate address of the opponent (public
//     and, behind the same router, LAN) - this opens the routers on both sides (hole punching);
//  3. once a "hi" from the opponent arrives, measure the ping with "pp"/"pq" packets and report
//     it to the server ("ping_report"). The server then asks both players to accept ("confirm").
// Before the match the socket is closed again so the game itself can bind the port.
class PeerLink : public QObject {
    Q_OBJECT
public:
    explicit PeerLink(QObject *parent = nullptr);

    struct Options {
        quint16 gamePort = 0;
        int role = 0;                 // 1 or 2, from the server
        QString matchId;
        QString token;
        QHostAddress server;          // lobby server = UDP rendezvous
        quint16 serverUdpPort = 7701;
        bool queue = false;           // matchmaking queue (max ping applies) vs. lobby
        int maxPing = 0;
        bool wifi = false;
        bool underWine = false;
    };

    void start(const Options &options);
    void stop();
    bool isActive() const { return m_socket != nullptr; }

    // From the server's "peer" message: [ip, port] pairs, local one only if same_nat.
    void setCandidates(const QVector<QPair<QHostAddress, quint16>> &candidates);

    int bestPingMs() const { return m_ping; }          // -1 = not measured
    int seenPublicPort() const { return m_seenPort; }  // our port as the server saw it, -1 = none
    bool opponentReachable() const { return m_peerSeen; }
    bool opponentOnWifi() const { return m_peerWifi; }
    bool opponentOnLinux() const { return m_peerLinux; }
    QHostAddress opponentAddress() const { return m_peerAddress; }
    quint16 opponentPort() const { return m_peerPort; }

signals:
    void opponentSeen();
    void pingReported(int pingMs, bool ok);
    void failed(const QString &reason);  // port in use / nothing got through
    void sendToServer(const QJsonObject &message);

private:
    void tick();
    void onReadyRead();
    void sendJson(const QJsonObject &obj, const QHostAddress &to, quint16 port);

    Options m_opt;
    QUdpSocket *m_socket = nullptr;
    bool m_bound = false;
    QTimer m_timer;
    QElapsedTimer m_clock;
    int m_ticks = 0;
    int m_ticksSinceSeen = 0;
    QVector<QPair<QHostAddress, quint16>> m_candidates;
    bool m_candidatesKnown = false;
    bool m_peerSeen = false;
    bool m_reported = false;
    bool m_peerWifi = false;
    bool m_peerLinux = false;
    QHostAddress m_peerAddress;
    quint16 m_peerPort = 0;
    int m_ping = -1;
    int m_samples = 0;
    int m_seenPort = -1;
};
